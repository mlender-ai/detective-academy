// 후보 SVG 를 PNG 로 굽고, 한 장에 모은다: node render.mjs [이름 일부...]
import { createRequire } from "node:module";
import { readFileSync, readdirSync } from "node:fs";
const { chromium } = createRequire(new URL("../../package.json", import.meta.url))("@playwright/test");
const DIR = new URL("../../docs/compare/characters/", import.meta.url).pathname;
const only = process.argv.slice(2);

const INFO = {
  "char-A-halftone": ["A · 망점 누아르", "붉은 바탕, 먹, 흰 외투의 망점. 펄프 만화의 인쇄 느낌", "직접 짠 망점 생성기"],
  "char-B-linocut": ["B · 판화", "칼자국이 남은 옆모습. 먹판과 붉은 판을 어긋나게 찍은 느낌", "직접 짠 칼자국 선 생성기"],
  "char-C-stipple": ["C · 점묘 카툰", "각진 얼굴과 긴 목. 분무한 듯한 점묘 그늘", "직접 짠 점묘 생성기"],
  "char-D-crayon": ["D · 크레용", "회색 면과 거친 선, 빛을 받아 하얗게 뜬 안경", "SVG 거친 가장자리 필터"],
  "char-E-drybrush": ["E · 마른 붓", "먹 한 가지. 붓 자국만으로 세운 사람, 얼굴은 거의 비움", "perfect-freehand (오픈소스)"],
  "char-F-marker": ["F · 마커 낙서", "굵은 펜 몇 획과 점 하나의 눈", "perfect-freehand (오픈소스)"],
  "char-G-pencil": ["G · 연필 스케치", "겹쳐 그은 선과 빗금, 붉은 색연필 한 가지", "Rough.js (오픈소스)"],
};

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 600, height: 760 }, deviceScaleFactor: 2 });
const names = readdirSync(DIR).filter((f) => f.endsWith(".svg")).map((f) => f.replace(".svg", "")).sort();
for (const name of names) {
  if (only.length && !only.some((k) => name.includes(k))) continue;
  await page.setContent(`<body style="margin:0">${readFileSync(`${DIR}${name}.svg`, "utf8")}</body>`);
  await page.waitForTimeout(150);
  await page.screenshot({ path: `${DIR}${name}.png` });
  console.log("png", name);
}
const img = (name) => `data:image/png;base64,${readFileSync(`${DIR}${name}.png`).toString("base64")}`;
const cards = names
  .filter((nm) => INFO[nm])
  .map((nm) => {
    const [title, desc, tool] = INFO[nm];
    const src = img(nm);
    return `<figure><div class="art"><img src="${src}"><span class="id"><img src="${src}"></span></div><figcaption><b>${title}</b><p>${desc}</p><i>${tool}</i></figcaption></figure>`;
  })
  .join("");
await page.setViewportSize({ width: 1400, height: 900 });
await page.setContent(`<meta charset="utf-8"><style>
*{box-sizing:border-box}body{margin:0;background:#1b1c1e;color:#f2f2f2;font-family:-apple-system,"Apple SD Gothic Neo",sans-serif;padding:30px 32px 34px;width:1400px}
h1{margin:0 0 6px;font-size:27px;letter-spacing:-.02em}.lead{margin:0 0 22px;font-size:15px;line-height:1.55;color:#c4c5c8;max-width:900px}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:26px 22px}
figure{margin:0}.art{position:relative}.art>img{display:block;width:100%;box-shadow:0 0 0 1px rgba(255,255,255,.18)}
.id{position:absolute;right:10px;bottom:10px;width:66px;height:78px;overflow:hidden;box-shadow:0 0 0 2px #fff,0 4px 10px rgba(0,0,0,.6)}
.id img{display:block;width:150%;margin:-8% 0 0 -25%}
figcaption{margin-top:10px}b{font-size:17px}p{margin:4px 0 3px;font-size:13.5px;line-height:1.5;color:#c4c5c8}i{font-style:normal;font-size:12px;color:#8e9095}
.note{align-self:center;padding:18px;border:1px dashed #55575b;font-size:13.5px;line-height:1.65;color:#c4c5c8}
</style>
<h1>탐정 캐릭터 그림체 후보 7종</h1>
<p class="lead">같은 탐정을 일곱 가지 그림체로 그렸습니다. 분위기와 색은 일부러 서로 다르게 잡았습니다. 각 그림 오른쪽 아래의 작은 칸은 신분증 사진 크기로 줄였을 때의 모습입니다. 웹의 이미지나 AI 생성 이미지는 쓰지 않았고, 모두 코드로 직접 그렸습니다.</p>
<div class="grid">${cards}<div class="note">고르신 그림체로 주인공·학생 초상·배경을 다시 그리고, 그 다음에 B안(픽셀)과 C안(누아르) 가운데 어느 쪽에 얹을지 정합니다. 두 가지를 섞는 것도 됩니다(예: A의 색과 망점 + C의 각진 얼굴).</div></div>`);
await page.waitForTimeout(400);
await page.screenshot({ path: `${DIR}characters-sheet.png`, fullPage: true });
console.log("sheet ok");
await browser.close();
