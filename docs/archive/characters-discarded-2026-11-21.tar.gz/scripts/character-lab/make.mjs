// 탐정 캐릭터 그림체 후보를 만든다 (2026-11-21). 앱과는 무관한 실험실이다.
//   cd scripts/character-lab && node make.mjs        → docs/compare/characters/char-*.svg
//   node render.mjs                                   → 같은 폴더에 PNG 와 모음 그림
// 도구: Rough.js(MIT, 연필 스케치), perfect-freehand(MIT, 붓·마커 획), 나머지는 직접 짠 망점·점묘·판화 선 생성기와 SVG 필터.
// 웹의 이미지나 AI 생성 이미지를 쓰지 않는다. 모든 형태는 이 파일의 좌표로 그린다.
import { mkdirSync, writeFileSync } from "node:fs";
import rough from "roughjs";
import { getStroke } from "perfect-freehand";

const OUT = new URL("../../docs/compare/characters/", import.meta.url);
mkdirSync(OUT, { recursive: true });
const W = 600;
const H = 760;

/* ───────── 공용 도구 ───────── */
function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}
const n = (v) => Math.round(v * 10) / 10;
const P = (list) => list.map(([x, y]) => `${n(x)},${n(y)}`).join(" ");
const poly = (list, attrs = "") => `<polygon points="${P(list)}" ${attrs}/>`;
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/** 망점: 45도로 기운 격자에 점을 찍고, 어두울수록 점을 키운다 */
function halftone({ box: [x0, y0, x1, y1], shade, pitch = 9, color = "#0a0a0a", clip }) {
  const out = [];
  const c = Math.SQRT1_2;
  const span = Math.hypot(x1 - x0, y1 - y0);
  const cx = (x0 + x1) / 2;
  const cy = (y0 + y1) / 2;
  for (let u = -span; u <= span; u += pitch) {
    for (let v = -span; v <= span; v += pitch) {
      const x = cx + (u - v) * c;
      const y = cy + (u + v) * c;
      if (x < x0 || x > x1 || y < y0 || y > y1) continue;
      const s = clamp(shade(x, y));
      if (s < 0.06) continue;
      out.push(`<circle cx="${n(x)}" cy="${n(y)}" r="${n(Math.sqrt(s) * pitch * 0.62)}"/>`);
    }
  }
  return `<g fill="${color}" ${clip ? `clip-path="url(#${clip})"` : ""}>${out.join("")}</g>`;
}

/** 점묘: 어두운 곳일수록 촘촘하게 흩뿌린다 */
function stipple({ box: [x0, y0, x1, y1], shade, count, color, r = [0.7, 1.5], clip, seed = 1 }) {
  const rand = rng(seed);
  const out = [];
  for (let i = 0; i < count; i++) {
    const x = x0 + rand() * (x1 - x0);
    const y = y0 + rand() * (y1 - y0);
    if (rand() > clamp(shade(x, y))) continue;
    out.push(`<circle cx="${n(x)}" cy="${n(y)}" r="${n(r[0] + rand() * (r[1] - r[0]))}"/>`);
  }
  return `<g fill="${color}" ${clip ? `clip-path="url(#${clip})"` : ""}>${out.join("")}</g>`;
}

/** 판화의 칼자국: 굵기가 들쭉날쭉한 평행선 */
function carve({ box: [x0, y0, x1, y1], angle = 90, gap = 12, width = () => 4, color, clip, seed = 1, wobble = 2 }) {
  const rand = rng(seed);
  const a = (angle * Math.PI) / 180;
  const dx = Math.cos(a);
  const dy = Math.sin(a);
  const cx = (x0 + x1) / 2;
  const cy = (y0 + y1) / 2;
  const span = Math.hypot(x1 - x0, y1 - y0) / 2;
  const out = [];
  let i = 0;
  for (let t = -span; t <= span; t += gap, i++) {
    const px = cx - dy * t;
    const py = cy + dx * t;
    const w = width(t / span, i, rand);
    if (w <= 0.2) continue;
    const j = () => (rand() - 0.5) * wobble;
    const ax = px - dx * span + j();
    const ay = py - dy * span + j();
    const bx = px + dx * span + j();
    const by = py + dy * span + j();
    const mx = px + j() * 3;
    const my = py + j() * 3;
    out.push(`<path d="M${n(ax)},${n(ay)} Q${n(mx)},${n(my)} ${n(bx)},${n(by)}" stroke-width="${n(w)}"/>`);
  }
  return `<g fill="none" stroke="${color}" stroke-linecap="round" ${clip ? `clip-path="url(#${clip})"` : ""}>${out.join("")}</g>`;
}

/** perfect-freehand 의 외곽선을 SVG 경로로 */
function strokePath(points, opts) {
  const s = getStroke(points, { simulatePressure: points[0].length < 3, ...opts });
  if (!s.length) return "";
  const d = s.reduce(
    (acc, [x0, y0], i, arr) => {
      const [x1, y1] = arr[(i + 1) % arr.length];
      acc.push(n(x0), n(y0), n((x0 + x1) / 2), n((y0 + y1) / 2));
      return acc;
    },
    ["M", n(s[0][0]), n(s[0][1]), "Q"],
  );
  return `${d.join(" ")} Z`;
}
/** 점 사이를 잘게 나누고 손떨림을 준다 */
function jitterLine(pts, rand, amp = 2, step = 14) {
  const out = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const [x0, y0] = pts[i];
    const [x1, y1] = pts[i + 1];
    const k = Math.max(1, Math.round(Math.hypot(x1 - x0, y1 - y0) / step));
    for (let j = 0; j < k; j++) {
      const t = j / k;
      out.push([x0 + (x1 - x0) * t + (rand() - 0.5) * amp, y0 + (y1 - y0) * t + (rand() - 0.5) * amp]);
    }
  }
  out.push(pts[pts.length - 1]);
  return out;
}

const FILTERS = `
  <filter id="inkedge" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed="4"/><feDisplacementMap in="SourceGraphic" scale="5"/></filter>
  <filter id="inkedge-s" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.06" numOctaves="2" seed="9"/><feDisplacementMap in="SourceGraphic" scale="2.6"/></filter>
  <filter id="dropout" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="11" result="t"/><feColorMatrix in="t" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -9 5.6" result="m"/><feComposite in="SourceGraphic" in2="m" operator="in"/></filter>
  <filter id="crayon" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.5" numOctaves="3" seed="6" result="t"/><feDisplacementMap in="SourceGraphic" in2="t" scale="6" result="d"/><feColorMatrix in="t" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -5 4.3" result="m"/><feComposite in="d" in2="m" operator="in"/></filter>
  <filter id="crayonline" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency="0.7" numOctaves="3" seed="8" result="t"/><feDisplacementMap in="SourceGraphic" in2="t" scale="5" result="d"/><feColorMatrix in="t" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -6 4.3" result="m"/><feComposite in="d" in2="m" operator="in"/></filter>
  <filter id="dry-v" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.075 0.004" numOctaves="2" seed="5" result="t"/><feColorMatrix in="t" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -10 6.9" result="m"/><feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="2" seed="2" result="w"/><feDisplacementMap in="SourceGraphic" in2="w" scale="7" result="d"/><feComposite in="d" in2="m" operator="in"/></filter>
  <filter id="dry-h" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.004 0.075" numOctaves="2" seed="7" result="t"/><feColorMatrix in="t" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -10 6.9" result="m"/><feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="2" seed="3" result="w"/><feDisplacementMap in="SourceGraphic" in2="w" scale="7" result="d"/><feComposite in="d" in2="m" operator="in"/></filter>
  <filter id="marker" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="2" seed="12" result="w"/><feDisplacementMap in="SourceGraphic" in2="w" scale="3.4"/></filter>
  <filter id="graphite" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="1.1" numOctaves="2" seed="14" result="t"/><feColorMatrix in="t" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -5 3.5" result="m"/><feComposite in="SourceGraphic" in2="m" operator="in"/></filter>
  <filter id="paper" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3" seed="21"/><feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.6 1.02"/></filter>`;

const wrap = (body, defs = "") =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}"><defs>${FILTERS}${defs}</defs>${body}</svg>`;
/** 종이 결: 화면 전체에 옅은 얼룩을 얹는다 */
const paperGrain = (color = "#000", opacity = 0.16) => `<rect width="${W}" height="${H}" fill="${color}" opacity="${opacity}" filter="url(#paper)"/>`;

/* ───────── A. 망점 누아르: 붉은 바탕, 먹, 흰 외투의 망점 ───────── */
function halftoneNoir() {
  const RED = "#e2231c";
  const K = "#0b0a0a";
  const WH = "#f6f1e6";
  const coat = "M70,760 L96,560 C112,500 172,470 236,452 L300,520 L372,446 C440,462 500,496 520,560 L560,760 Z";
  const o = [];
  o.push(`<rect width="${W}" height="${H}" fill="${RED}"/>`);
  // 블라인드 그림자
  for (let i = 0; i < 6; i++) {
    const y = 20 + i * 64;
    o.push(poly([[0, y + 96], [600, y], [600, y + 30], [0, y + 126]], `fill="${K}"`));
  }
  o.push(`<g filter="url(#inkedge-s)">`);
  o.push(`<path d="${coat}" fill="${WH}" stroke="${K}" stroke-width="7" stroke-linejoin="round"/>`);
  o.push(`</g>`);
  // 외투의 망점: 왼쪽과 아래로 갈수록 어둡다
  o.push(
    halftone({
      box: [70, 440, 560, 760],
      clip: "a-coat",
      pitch: 9,
      color: K,
      shade: (x, y) => 0.95 - (x - 110) / 300 + Math.max(0, (y - 640) / 260) - Math.max(0, (x - 430) / 400),
    }),
  );
  o.push(`<g filter="url(#inkedge-s)">`);
  // 접힌 그늘
  o.push(poly([[96, 560], [152, 516], [176, 640], [128, 760], [70, 760]], `fill="${K}"`));
  o.push(poly([[236, 452], [300, 520], [266, 660], [206, 548]], `fill="${K}"`));
  o.push(poly([[372, 446], [300, 520], [332, 664], [408, 550]], `fill="${WH}" stroke="${K}" stroke-width="6" stroke-linejoin="round"`));
  o.push(poly([[470, 520], [520, 560], [560, 760], [520, 760], [492, 640]], `fill="${K}"`));
  o.push(poly([[268, 484], [300, 520], [336, 480], [320, 466], [284, 468]], `fill="${K}"`));
  o.push(poly([[300, 520], [284, 562], [300, 708], [318, 562]], `fill="${RED}" stroke="${K}" stroke-width="5" stroke-linejoin="round"`));
  // 세운 깃
  o.push(poly([[226, 458], [248, 376], [294, 470]], `fill="${WH}" stroke="${K}" stroke-width="6" stroke-linejoin="round"`));
  o.push(poly([[382, 452], [358, 374], [310, 468]], `fill="${WH}" stroke="${K}" stroke-width="6" stroke-linejoin="round"`));
  // 목과 얼굴: 그늘은 먹, 빛 받은 면만 흰색
  o.push(poly([[262, 396], [342, 396], [334, 472], [270, 472]], `fill="${K}"`));
  o.push(`<path d="M246,292 L250,372 C256,412 286,438 316,438 C346,434 368,404 370,362 L368,292 Z" fill="${K}"/>`);
  o.push(poly([[300, 300], [368, 296], [370, 362], [354, 410], [318, 436], [298, 424], [306, 386], [286, 378], [304, 342]], `fill="${WH}"`));
  o.push(poly([[312, 326], [356, 317], [357, 328], [314, 338]], `fill="${K}"`));
  o.push(`<path d="M312,404 L348,397" stroke="${K}" stroke-width="5.5" stroke-linecap="round"/>`);
  o.push(`<path d="M346,340 L352,372 L338,378" fill="none" stroke="${K}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>`);
  // 중절모
  o.push(`<path d="M230,252 C226,170 262,126 310,122 C364,120 398,160 394,248 Z" fill="${K}"/>`);
  o.push(`<path d="M372,148 C390,176 392,206 390,228 L379,228 C381,200 377,172 364,152 Z" fill="${WH}"/>`);
  o.push(poly([[230, 234], [394, 228], [394, 250], [230, 258]], `fill="${RED}"`));
  o.push(poly([[146, 288], [230, 250], [394, 244], [474, 258], [486, 278], [422, 298], [300, 308], [188, 306]], `fill="${K}"`));
  o.push(`<path d="M396,246 L470,261" stroke="${WH}" stroke-width="5" stroke-linecap="round"/>`);
  o.push(`</g>`);
  o.push(paperGrain("#3a0705", 0.22));
  return wrap(o.join("\n"), `<clipPath id="a-coat"><path d="${coat}"/></clipPath>`);
}

/* ───────── B. 판화: 칼자국이 남은 옆모습, 먹과 붉은 판 ───────── */
function linocut() {
  const CREAM = "#ead9b2";
  const K = "#17120f";
  const RED = "#b3271f";
  const face = "M262,256 L250,300 L222,352 L246,362 L240,380 L252,390 L244,404 L256,430 C280,454 322,454 352,430 L398,330 L402,256 Z";
  const coat = "M130,760 L170,570 C196,506 268,474 330,458 L356,440 L424,432 C474,472 506,544 526,624 L548,760 Z";
  const crown = "M250,214 C246,128 300,96 356,100 C412,104 442,140 438,196 Z";
  const o = [];
  o.push(`<rect width="${W}" height="${H}" fill="${CREAM}"/>`);
  o.push(`<rect x="34" y="46" width="524" height="676" fill="${RED}" filter="url(#inkedge)"/>`);
  // 붉은 판 위의 세로 칼자국 (막의 주름)
  o.push(
    carve({
      box: [40, 40, 560, 720],
      angle: 90,
      gap: 15,
      clip: "b-block",
      color: K,
      seed: 5,
      wobble: 3,
      width: (t, i, r) => 1.2 + r() * 5 + (Math.abs(t) > 0.6 ? 4 : 0),
    }),
  );
  o.push(`<g filter="url(#inkedge-s)">`);
  o.push(`<path d="${coat}" fill="${K}"/>`);
  o.push(`<path d="${face}" fill="${CREAM}"/>`);
  o.push(poly([[258, 256], [402, 256], [400, 300], [300, 288], [254, 282]], `fill="${K}"`));
  o.push(poly([[360, 256], [404, 256], [402, 362], [372, 398], [356, 330]], `fill="${K}"`));
  o.push(`<path d="${crown}" fill="${K}"/>`);
  o.push(`<path d="M146,238 C200,214 262,206 332,204 C404,202 474,206 524,228 C472,252 380,258 300,258 C238,258 188,252 146,238 Z" fill="${K}"/>`);
  o.push(`<path d="M246,362 L262,366 M252,390 L270,392" stroke="${K}" stroke-width="4" stroke-linecap="round"/>`);
  o.push(`</g>`);
  // 뺨 아래의 빗금 그늘
  o.push(carve({ box: [256, 340, 400, 450], angle: -38, gap: 9, clip: "b-face", color: K, seed: 2, wobble: 1.5, width: (t) => (t > -0.1 ? 1 + (t + 0.1) * 4.5 : 0) }));
  // 모자와 외투에 파낸 선
  o.push(carve({ box: [250, 96, 440, 214], angle: 8, gap: 13, clip: "b-crown", color: CREAM, seed: 7, wobble: 2, width: (t, i) => (i % 2 ? 2.4 : 1.2) }));
  o.push(poly([[250, 190], [438, 176], [438, 190], [250, 206]], `fill="${CREAM}" clip-path="url(#b-crown)"`));
  o.push(carve({ box: [130, 440, 548, 760], angle: 68, gap: 17, clip: "b-coat", color: CREAM, seed: 9, wobble: 3, width: (t, i, r) => (t < -0.05 ? 0 : 1 + r() * 3.2) }));
  o.push(`<path d="M330,458 L304,566 L352,650 M356,440 L392,528" fill="none" stroke="${CREAM}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" filter="url(#inkedge-s)"/>`);
  // 덜 찍힌 자리
  o.push(`<rect width="${W}" height="${H}" fill="${CREAM}" opacity="0.5" filter="url(#paper)"/>`);
  return wrap(
    o.join("\n"),
    `<clipPath id="b-block"><rect x="38" y="50" width="516" height="668"/></clipPath><clipPath id="b-face"><path d="${face}"/></clipPath><clipPath id="b-crown"><path d="${crown}"/></clipPath><clipPath id="b-coat"><path d="${coat}"/></clipPath>`,
  );
}

/* ───────── C. 점묘 카툰: 각진 얼굴과 긴 목, 분무한 듯한 그늘 ───────── */
function stippleToon() {
  const BG = "#e7b529";
  const K = "#141210";
  const WH = "#f5efe0";
  const RED = "#d2302a";
  const head = [[220, 172], [380, 150], [398, 300], [332, 404], [270, 404], [212, 300]];
  const suit = [[50, 760], [116, 566], [240, 500], [300, 566], [360, 500], [486, 566], [552, 760]];
  const neck = [[276, 380], [326, 380], [332, 484], [268, 484]];
  const o = [];
  o.push(`<rect width="${W}" height="${H}" fill="${BG}"/>`);
  o.push(stipple({ box: [0, 0, W, H], count: 30000, color: "#9a6a0c", r: [0.7, 1.6], seed: 3, shade: (x, y) => clamp((Math.hypot(x - 420, y - 250) - 260) / 520) * 0.8 }));
  o.push(stipple({ box: [0, 0, W, H], count: 9000, color: "#fff3c4", r: [0.7, 1.5], seed: 8, shade: (x, y) => clamp(1 - Math.hypot(x - 440, y - 210) / 250) * 0.7 }));
  o.push(poly(suit, `fill="${K}"`));
  o.push(poly([[240, 500], [300, 626], [360, 500], [332, 470], [268, 470]], `fill="${WH}"`));
  o.push(poly([[286, 502], [314, 502], [323, 624], [300, 664], [277, 624]], `fill="${RED}"`));
  o.push(poly([[240, 500], [300, 626], [268, 660], [214, 540]], `fill="#262220"`));
  o.push(poly([[360, 500], [300, 626], [332, 660], [386, 540]], `fill="#262220"`));
  o.push(poly([[404, 604], [452, 592], [448, 618], [408, 626]], `fill="${WH}"`));
  o.push(poly(neck, `fill="${WH}"`));
  o.push(poly(head, `fill="${WH}"`));
  o.push(poly([[212, 250], [196, 262], [200, 300], [214, 306]], `fill="${WH}"`));
  o.push(poly([[396, 244], [412, 252], [410, 292], [398, 300]], `fill="${WH}"`));
  // 그늘: 왼쪽 뺨, 모자 아래, 목
  o.push(stipple({ box: [196, 150, 400, 410], clip: "c-head", count: 26000, color: K, r: [0.7, 1.5], seed: 5, shade: (x, y) => clamp(1.0 - (x - 200) / 92) * 0.9 + clamp(1 - (y - 160) / 56) * 0.9 }));
  o.push(stipple({ box: [266, 380, 334, 486], clip: "c-neck", count: 7000, color: K, r: [0.7, 1.4], seed: 6, shade: (x, y) => clamp(0.85 - (x - 268) / 44) * 0.8 + clamp(1 - (y - 380) / 40) * 0.75 }));
  o.push(stipple({ box: [50, 500, 552, 760], clip: "c-suit", count: 22000, color: WH, r: [0.6, 1.3], seed: 7, shade: (x, y) => clamp((x - 400) / 150) * clamp(1 - (y - 540) / 240) * 0.85 }));
  // 눈썹과 눈, 코, 입
  o.push(poly([[236, 232], [292, 248], [292, 260], [234, 250]], `fill="${K}"`));
  o.push(poly([[316, 248], [372, 228], [374, 246], [316, 260]], `fill="${K}"`));
  o.push(`<ellipse cx="268" cy="268" rx="15" ry="10" fill="${WH}"/><ellipse cx="342" cy="266" rx="15" ry="10" fill="${WH}"/>`);
  o.push(`<circle cx="270" cy="268" r="8.5" fill="${K}"/><circle cx="340" cy="266" r="8.5" fill="${K}"/><circle cx="273" cy="265" r="2.6" fill="${WH}"/><circle cx="343" cy="263" r="2.6" fill="${WH}"/>`);
  o.push(poly([[302, 252], [322, 334], [288, 334]], `fill="${WH}" stroke="${K}" stroke-width="3" stroke-linejoin="round"`));
  o.push(poly([[302, 252], [303, 334], [288, 334]], `fill="${K}"`));
  o.push(`<path d="M284,366 L328,358" stroke="${K}" stroke-width="5.5" stroke-linecap="round"/>`);
  // 모자
  o.push(poly([[228, 62], [382, 40], [398, 150], [212, 174]], `fill="${K}"`));
  o.push(poly([[214, 150], [397, 126], [398, 150], [212, 174]], `fill="${RED}"`));
  o.push(poly([[124, 188], [212, 168], [398, 144], [484, 150], [494, 170], [402, 180], [214, 204], [136, 208]], `fill="${K}"`));
  o.push(stipple({ box: [228, 40, 400, 150], clip: "c-crown", count: 6000, color: WH, r: [0.6, 1.3], seed: 9, shade: (x, y) => clamp((x - 330) / 70) * 0.8 }));
  return wrap(
    o.join("\n"),
    `<clipPath id="c-head"><polygon points="${P(head)}"/></clipPath><clipPath id="c-neck"><polygon points="${P(neck)}"/></clipPath><clipPath id="c-suit"><polygon points="${P(suit)}"/></clipPath><clipPath id="c-crown"><polygon points="${P([[228, 62], [382, 40], [398, 150], [212, 174]])}"/></clipPath>`,
  );
}

/* ───────── D. 크레용: 회색 면과 거친 선, 둥근 안경 ───────── */
function crayon() {
  const BG = "#37322f";
  const MID = "#8f8882";
  const LIGHT = "#ddd6cc";
  const WH = "#ece7de";
  const K = "#191614";
  const o = [];
  o.push(`<rect width="${W}" height="${H}" fill="${BG}"/>`);
  o.push(`<g filter="url(#crayon)">`);
  o.push(`<path d="M30,760 L84,524 C126,472 208,452 268,442 L332,442 C402,454 474,476 516,524 L572,760 Z" fill="${MID}"/>`);
  o.push(poly([[266, 440], [300, 526], [334, 440]], `fill="${WH}"`));
  o.push(poly([[300, 470], [316, 502], [300, 612], [284, 502]], `fill="${K}"`));
  o.push(`<rect x="262" y="356" width="76" height="96" fill="#b1a9a1"/>`);
  o.push(`<path d="M230,196 C230,150 370,150 370,196 L370,332 C370,396 230,396 230,332 Z" fill="${LIGHT}"/>`);
  o.push(`<path d="M318,196 L370,196 L370,332 C370,372 340,386 318,384 Z" fill="#b1a9a1"/>`);
  o.push(`<path d="M220,196 C220,84 380,84 380,196 Z" fill="${K}"/>`);
  o.push(`<rect x="184" y="186" width="232" height="24" rx="10" fill="${K}"/>`);
  o.push(`<rect x="222" y="162" width="156" height="14" fill="#5d5652"/>`);
  o.push(`<circle cx="268" cy="254" r="27" fill="${WH}"/><circle cx="338" cy="254" r="27" fill="${WH}"/>`);
  o.push(poly([[392, 586], [442, 576], [438, 604], [396, 612]], `fill="${WH}"`));
  o.push(`</g>`);
  o.push(`<g filter="url(#crayonline)" fill="none" stroke="${K}" stroke-linecap="round" stroke-linejoin="round">`);
  o.push(`<circle cx="268" cy="254" r="27" stroke-width="7"/><circle cx="338" cy="254" r="27" stroke-width="7"/>`);
  o.push(`<path d="M295,252 L311,252 M241,248 L226,240 M365,248 L374,242" stroke-width="6"/>`);
  o.push(`<path d="M303,268 L296,306 L312,308" stroke-width="5"/>`);
  o.push(`<path d="M276,340 C292,352 316,352 332,338" stroke-width="6"/>`);
  o.push(`<path d="M268,442 L246,566 L300,646 M332,442 L356,566 L300,646" stroke-width="7"/>`);
  o.push(`<path d="M150,560 L136,760 M452,560 L468,640" stroke-width="6"/>`);
  o.push(`</g>`);
  o.push(paperGrain("#000", 0.2));
  return wrap(o.join("\n"));
}

/* ───────── E. 마른 붓: 먹 한 가지, 붓 자국으로만 그린 사람 ───────── */
function dryBrush() {
  const PAPER = "#e9e1d1";
  const K = "#0f0d0c";
  const rand = rng(17);
  const S = (pts, size, extra = {}) => `<path d="${strokePath(jitterLine(pts, rand, 3, 22), { size, thinning: 0.55, smoothing: 0.6, streamline: 0.5, start: { taper: size * 1.2 }, end: { taper: size * 2.2 }, ...extra })}"/>`;
  const o = [];
  o.push(`<rect width="${W}" height="${H}" fill="${PAPER}"/>`);
  // 세로 획: 모자 윗부분, 몸통
  o.push(`<g fill="${K}" filter="url(#dry-v)">`);
  [[250, 104, 196], [270, 86, 200], [291, 78, 200], [312, 80, 200], [333, 88, 198], [352, 108, 194]].forEach(([x, y0, y1]) => o.push(S([[x, y0], [x + 2, (y0 + y1) / 2], [x, y1]], 19)));
  [[214, 470, 748], [252, 520, 752], [292, 560, 756], [332, 548, 752], [372, 500, 750], [400, 460, 746]].forEach(([x, y0, y1]) => o.push(S([[x, y0], [x - 3, (y0 + y1) / 2], [x + 2, y1]], 58)));
  // 어깨에서 팔로 내려오는 큰 획
  o.push(S([[292, 330], [214, 352], [160, 430], [140, 560], [132, 720]], 76));
  o.push(S([[308, 330], [386, 352], [440, 430], [462, 560], [470, 720]], 76));
  // 깃
  o.push(S([[296, 318], [262, 420], [236, 520]], 30));
  o.push(S([[304, 318], [340, 420], [366, 520]], 30));
  o.push(S([[300, 336], [301, 380], [299, 440]], 10));
  o.push(`</g>`);
  // 가로 획: 모자 챙
  o.push(`<g fill="${K}" filter="url(#dry-h)">`);
  o.push(S([[150, 214], [230, 204], [330, 198], [452, 206]], 30));
  o.push(`</g>`);
  // 턱선과 얼굴: 거의 비워 둔다
  o.push(`<g fill="${K}" filter="url(#inkedge-s)">`);
  o.push(S([[262, 222], [266, 268], [300, 300], [336, 268], [340, 222]], 7, { thinning: 0.7 }));
  o.push(S([[286, 250], [296, 252]], 7));
  o.push(S([[316, 250], [326, 252]], 7));
  [[92, 690, 5], [78, 640, 3], [520, 706, 4], [540, 668, 2.4], [110, 740, 2.6]].forEach(([x, y, r]) => o.push(`<circle cx="${x}" cy="${y}" r="${r}"/>`));
  o.push(`</g>`);
  // 낙관
  o.push(`<g filter="url(#inkedge-s)"><rect x="476" y="610" width="54" height="54" fill="#c2281f"/><path d="M490,624 h26 M490,637 h26 M503,624 v26 M490,650 h26" stroke="${PAPER}" stroke-width="4" fill="none"/></g>`);
  o.push(paperGrain("#5a4a36", 0.2));
  return wrap(o.join("\n"));
}

/* ───────── F. 마커 낙서: 굵은 펜 몇 획과 점 하나의 눈 ───────── */
function marker() {
  const PAPER = "#f6f4ee";
  const K = "#131313";
  const rand = rng(23);
  const S = (pts, size = 17, amp = 3) => `<path d="${strokePath(jitterLine(pts, rand, amp, 16), { size, thinning: 0.12, smoothing: 0.55, streamline: 0.4 })}"/>`;
  const zig = (x0, x1, y0, y1, step) => {
    const pts = [];
    let left = true;
    for (let y = y0; y <= y1; y += step) {
      pts.push([left ? x0 + rand() * 10 : x1 - rand() * 10, y + rand() * 5]);
      left = !left;
    }
    return pts;
  };
  const o = [];
  o.push(`<rect width="${W}" height="${H}" fill="${PAPER}"/>`);
  o.push(`<g fill="${K}" fill-opacity="0.9" filter="url(#marker)" style="mix-blend-mode:multiply">`);
  // 모자: 윤곽 한 번, 속은 마구 칠한다
  o.push(S([[112, 304], [200, 290], [330, 284], [486, 300]], 22));
  o.push(S([[206, 290], [212, 176], [252, 142], [384, 148], [410, 184], [404, 290]], 18));
  o.push(S(zig(224, 398, 164, 284, 15), 17, 6));
  o.push(S(zig(232, 392, 172, 280, 27), 15, 8));
  // 옆얼굴
  o.push(S([[250, 300], [238, 362], [172, 436], [232, 444], [226, 472], [244, 488], [236, 514], [262, 546], [330, 548], [394, 474], [404, 300]], 16));
  o.push(S([[262, 344], [312, 352]], 15));
  o.push(S([[236, 490], [272, 486]], 13));
  o.push(S([[378, 378], [362, 402], [380, 424]], 12));
  // 외투: 깃과 빗금
  o.push(S([[262, 546], [206, 644], [142, 760]], 18));
  o.push(S([[330, 548], [424, 604], [524, 760]], 18));
  o.push(S([[262, 546], [302, 632], [342, 552]], 15));
  [[214, 684, 286, 640], [200, 724, 318, 652], [236, 752, 372, 668], [318, 756, 430, 690], [400, 760, 470, 716]].forEach(([x0, y0, x1, y1]) => o.push(S([[x0, y0], [x1, y1]], 13, 5)));
  o.push(`</g>`);
  // 눈: 점 하나
  o.push(`<circle cx="288" cy="384" r="13" fill="${K}" filter="url(#marker)"/>`);
  o.push(paperGrain("#6b6558", 0.12));
  return wrap(o.join("\n"));
}

/* ───────── G. 연필 스케치: 겹쳐 그은 선과 빗금 (Rough.js) ───────── */
function pencil() {
  const PAPER = "#efebe2";
  const G = "#242220";
  const RED = "#c0392b";
  const gen = rough.generator();
  const draw = (drawable, extra = "") =>
    gen
      .toPaths(drawable)
      .map((p) => `<path d="${p.d}" stroke="${p.stroke}" stroke-width="${p.strokeWidth}" fill="${p.fill || "none"}" ${extra}/>`)
      .join("");
  const line = { stroke: G, strokeWidth: 3, roughness: 1.7, bowing: 1.4 };
  const hatch = (gap, angle, weight = 1.3) => ({ stroke: "none", fill: G, fillStyle: "hachure", hachureGap: gap, hachureAngle: angle, fillWeight: weight, roughness: 2.2 });
  const o = [];
  o.push(`<rect width="${W}" height="${H}" fill="${PAPER}"/>`);
  o.push(`<g filter="url(#graphite)" stroke-linecap="round">`);
  // 밑그림 선
  o.push(draw(gen.ellipse(300, 300, 176, 222, { stroke: G, strokeWidth: 1, roughness: 2.6, seed: 3 }), `opacity="0.45"`));
  o.push(draw(gen.line(300, 150, 300, 430, { stroke: G, strokeWidth: 0.9, roughness: 2.4, seed: 4 }), `opacity="0.35"`));
  o.push(draw(gen.line(214, 286, 386, 286, { stroke: G, strokeWidth: 0.9, roughness: 2.4, seed: 5 }), `opacity="0.35"`));
  // 외투: 그늘 빗금 → 윤곽
  const coat = "M64,760 L112,560 C140,506 214,478 262,464 L300,540 L338,464 C386,478 460,506 488,560 L536,760 Z";
  o.push(draw(gen.path("M64,760 L112,560 C140,506 214,478 262,464 L300,540 L272,760 Z", { ...hatch(9, 62), seed: 11 })));
  o.push(draw(gen.path("M338,464 C386,478 460,506 488,560 L536,760 L420,760 Z", { ...hatch(15, 62, 1), seed: 12 })));
  o.push(draw(gen.path(coat, { ...line, strokeWidth: 2.6, seed: 13 })));
  o.push(draw(gen.path("M262,464 L238,360 L300,470 L362,360 L338,464", { ...line, seed: 14 })));
  o.push(draw(gen.path("M262,464 L244,600 L300,680 M338,464 L356,600 L300,680", { ...line, strokeWidth: 1.8, seed: 15 })));
  // 얼굴
  o.push(draw(gen.path("M222,270 C218,350 250,410 300,414 C350,410 382,350 378,270", { ...line, strokeWidth: 2.4, seed: 21 })));
  o.push(draw(gen.path("M222,262 L378,262 L378,306 C330,318 270,318 222,306 Z", { ...hatch(8, -40, 1.5), seed: 22 })));
  o.push(draw(gen.path("M330,300 C352,330 356,372 342,400 C366,372 378,330 378,290 Z", { ...hatch(7, -40, 1.1), seed: 23 })));
  o.push(draw(gen.path("M250,292 L288,296 M312,296 L350,292", { ...line, strokeWidth: 3.6, roughness: 1, seed: 24 })));
  o.push(draw(gen.ellipse(270, 306, 15, 11, { stroke: G, strokeWidth: 2, roughness: 0.8, fill: G, fillStyle: "solid", seed: 27 })));
  o.push(draw(gen.ellipse(332, 306, 15, 11, { stroke: G, strokeWidth: 2, roughness: 0.8, fill: G, fillStyle: "solid", seed: 28 })));
  o.push(draw(gen.path("M302,304 L294,352 L310,356", { ...line, strokeWidth: 2.8, roughness: 1.1, seed: 25 })));
  o.push(draw(gen.path("M276,382 C290,388 312,388 326,380", { ...line, strokeWidth: 3.2, roughness: 1, seed: 26 })));
  // 중절모
  o.push(draw(gen.path("M214,246 C206,166 250,118 300,116 C352,118 394,166 386,246 Z", { ...hatch(6, -38, 1.5), seed: 31 })));
  o.push(draw(gen.path("M214,246 C206,166 250,118 300,116 C352,118 394,166 386,246", { ...line, strokeWidth: 2.6, seed: 32 })));
  o.push(draw(gen.path("M122,268 C180,238 420,238 478,268 C420,292 180,292 122,268 Z", { ...hatch(4.5, 30, 1.6), seed: 33 })));
  o.push(draw(gen.path("M122,268 C180,238 420,238 478,268 C420,292 180,292 122,268 Z", { ...line, strokeWidth: 2.6, seed: 34 })));
  o.push(`</g>`);
  // 붉은 색연필: 넥타이와 밑줄
  o.push(`<g filter="url(#graphite)" stroke-linecap="round">`);
  o.push(draw(gen.path("M300,540 L286,580 L300,700 L314,580 Z", { stroke: RED, strokeWidth: 2, roughness: 1.6, fill: RED, fillStyle: "hachure", hachureGap: 4, hachureAngle: 70, fillWeight: 1.6, seed: 41 })));
  o.push(draw(gen.path("M214,236 C270,226 330,226 386,236", { stroke: RED, strokeWidth: 5, roughness: 1.4, seed: 42 })));
  o.push(`</g>`);
  o.push(paperGrain("#6b6558", 0.16));
  return wrap(o.join("\n"));
}

const SET = {
  "char-A-halftone": halftoneNoir,
  "char-B-linocut": linocut,
  "char-C-stipple": stippleToon,
  "char-D-crayon": crayon,
  "char-E-drybrush": dryBrush,
  "char-F-marker": marker,
  "char-G-pencil": pencil,
};
const only = process.argv.slice(2);
for (const [name, fn] of Object.entries(SET)) {
  if (only.length && !only.some((k) => name.includes(k))) continue;
  const svg = fn();
  writeFileSync(new URL(`${name}.svg`, OUT), svg);
  console.log("wrote", name, `${(svg.length / 1024).toFixed(0)}KB`);
}
