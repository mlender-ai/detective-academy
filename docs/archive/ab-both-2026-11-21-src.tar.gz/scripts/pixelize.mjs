// 그림을 저해상도 픽셀 그림으로 바꾼다 (B안 배경용).
//   node scripts/pixelize.mjs <in> <out.png> <cropX,cropY,cropW,cropH> <outW>x<outH> [colors=20] [dither=0.5] [contrast=1.12] [saturation=1.1]
// 잘라 낸 영역을 작은 크기로 줄이고, 그 그림에서 뽑은 적은 수의 색(중앙값 분할)으로 바꾼 뒤
// 격자 무늬 디더링을 넣는다. 90년대·DS 시절 배경처럼 색 띠 사이가 점묘로 이어진다.
import { chromium } from "@playwright/test";
import { readFileSync, writeFileSync } from "node:fs";
import { extname } from "node:path";

const [input, output, cropArg, sizeArg, colorsArg = "20", ditherArg = "0.5", contrastArg = "1.12", satArg = "1.1"] = process.argv.slice(2);
const crop = cropArg.split(",").map(Number);
const [outW, outH] = sizeArg.split("x").map(Number);
const mime = { ".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg" }[extname(input)];
const dataUrl = `data:${mime};base64,${readFileSync(input).toString("base64")}`;

const browser = await chromium.launch();
const page = await browser.newPage();
const base64 = await page.evaluate(
  async ({ dataUrl, crop, outW, outH, colors, dither, contrast, saturation }) => {
    const img = new Image();
    img.src = dataUrl;
    await img.decode();
    const canvas = document.createElement("canvas");
    canvas.width = outW;
    canvas.height = outH;
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingQuality = "high";
    ctx.filter = `contrast(${contrast}) saturate(${saturation})`;
    ctx.drawImage(img, crop[0], crop[1], crop[2], crop[3], 0, 0, outW, outH);
    const image = ctx.getImageData(0, 0, outW, outH);
    const d = image.data;

    // 중앙값 분할로 대표 색을 뽑는다
    const pixels = [];
    for (let i = 0; i < d.length; i += 4) pixels.push([d[i], d[i + 1], d[i + 2]]);
    let boxes = [pixels];
    while (boxes.length < colors) {
      let best = -1;
      let bestRange = -1;
      let bestChannel = 0;
      boxes.forEach((box, index) => {
        if (box.length < 2) return;
        for (let c = 0; c < 3; c++) {
          let lo = 255;
          let hi = 0;
          for (const p of box) {
            if (p[c] < lo) lo = p[c];
            if (p[c] > hi) hi = p[c];
          }
          // 눈은 초록·빨강의 차이에 더 민감하다
          const range = (hi - lo) * [1, 1.2, 0.8][c] * Math.sqrt(box.length);
          if (range > bestRange) {
            bestRange = range;
            best = index;
            bestChannel = c;
          }
        }
      });
      if (best < 0) break;
      const box = boxes[best].slice().sort((a, b) => a[bestChannel] - b[bestChannel]);
      const mid = box.length >> 1;
      boxes.splice(best, 1, box.slice(0, mid), box.slice(mid));
    }
    const palette = boxes.map((box) => {
      const sum = [0, 0, 0];
      for (const p of box) for (let c = 0; c < 3; c++) sum[c] += p[c];
      return sum.map((v) => Math.round(v / box.length));
    });

    const bayer = [
      [0, 8, 2, 10],
      [12, 4, 14, 6],
      [3, 11, 1, 9],
      [15, 7, 13, 5],
    ];
    const nearest = (r, g, b) => {
      let bestIndex = 0;
      let bestDistance = Infinity;
      for (let i = 0; i < palette.length; i++) {
        const p = palette[i];
        const dist = (p[0] - r) ** 2 * 0.9 + (p[1] - g) ** 2 * 1.2 + (p[2] - b) ** 2 * 0.7;
        if (dist < bestDistance) {
          bestDistance = dist;
          bestIndex = i;
        }
      }
      return palette[bestIndex];
    };
    const spread = 34 * dither;
    for (let y = 0; y < outH; y++) {
      for (let x = 0; x < outW; x++) {
        const i = (y * outW + x) * 4;
        const t = (bayer[y & 3][x & 3] / 16 - 0.47) * spread;
        const p = nearest(d[i] + t, d[i + 1] + t, d[i + 2] + t);
        d[i] = p[0];
        d[i + 1] = p[1];
        d[i + 2] = p[2];
        d[i + 3] = 255;
      }
    }
    ctx.filter = "none";
    ctx.putImageData(image, 0, 0);
    return canvas.toDataURL("image/png").split(",")[1];
  },
  { dataUrl, crop, outW, outH, colors: Number(colorsArg), dither: Number(ditherArg), contrast: Number(contrastArg), saturation: Number(satArg) },
);
writeFileSync(output, Buffer.from(base64, "base64"));
console.log(`${output} ${outW}x${outH} ${(Buffer.from(base64, "base64").length / 1024).toFixed(1)}KB`);
await browser.close();
