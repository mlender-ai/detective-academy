// 비교 문서용 캡처: 장면 전환의 중간 프레임과 그림 에셋 조각.
//   node scripts/capture-compare.mjs <out-dir> [ink|pixel]   (개발 서버 5183 이 떠 있어야 한다)
import { chromium } from "@playwright/test";

const out = process.argv[2];
const art = process.argv[3] ?? "ink";
const browser = await chromium.launch();
const context = await browser.newContext({
  viewport: { width: 390, height: 844 },
  deviceScaleFactor: 2,
  hasTouch: true,
  isMobile: true,
  locale: "ko-KR",
  timezoneId: "Asia/Seoul",
});
const page = await context.newPage();
page.on("pageerror", (e) => console.log("[pageerror]", e.message));

async function preset(id) {
  await page.goto(`http://localhost:5183/?demo=1&art=${art}`);
  await page.getByTestId("demo-toggle").click();
  await page.getByTestId(`demo-${id}`).click();
  await page.addStyleTag({ content: ".demo{display:none!important}" });
  await page.evaluate(() => document.fonts.ready.then(() => undefined));
  await page.waitForTimeout(1300);
}
// 화풍에 따라 없는 물건(예: B안의 연필)은 건너뛴다
const crop = async (selector, name, nth = 0) => {
  const target = page.locator(selector).nth(nth);
  if ((await target.count()) === 0 || !(await target.isVisible())) return;
  await target.screenshot({ path: `${out}/obj-${name}.png` });
};

/* ── 그림 조각: 홈 ── */
await preset("daily-unsolved");
await crop(".hall__sign", "crest");
await crop(".hall__rank", "rank");
await crop(".promoslip__env", "envelope");
await crop(".ledge__art", "key", 0);
await crop(".ledge__art", "id", 1);
await crop(".ledge__art", "coins", 2);
await crop(".posting__date", "date");

/* ── 전환: 홈 → 책상 ── */
const cta = await page.getByTestId("daily-file-cta").boundingBox();
await page.mouse.click(cta.x + cta.width / 2, cta.y + cta.height / 2);
let i = 1;
for (const t of [120, 150, 130]) {
  await page.waitForTimeout(t);
  await page.screenshot({ path: `${out}/m${i++}.png` });
}
await page.waitForTimeout(900);
await crop(".lock", "lock");
await crop(".desk__pencil", "pencil");

/* ── 전환: 정답 → 결과 ── */
for (const [index, digit] of [[0, 4], [1, 2], [2, 6]]) {
  for (let k = 0; k < 9; k++) {
    if (Number(await page.getByTestId(`dial-${index}`).getAttribute("aria-valuenow")) === digit) break;
    await page.getByTestId(`dial-${index}-next`).click();
    await page.waitForTimeout(40);
  }
}
await page.waitForTimeout(400);
await page.getByTestId("submit").click();
for (const t of [520, 860, 2300]) {
  await page.waitForTimeout(t);
  await page.screenshot({ path: `${out}/m${i++}.png` });
}
await crop(".graded__stamp", "stamp");
await browser.close();
console.log("captured");
