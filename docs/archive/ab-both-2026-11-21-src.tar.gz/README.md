# 탐정학원 · DETECTIVE ACADEMY

탐정학원에 입학해 추리 문제를 풀고, 수사 크레딧을 모아 승급 시험에 합격하는 모바일 추론 게임의 플레이 가능한 프로토타입입니다.

입학 → 오늘의 추리(암호 해독) → 연습실(거짓 진술 찾기) → 승급 시험(발표 순서 재구성) → F급에서 D급 승급까지 실제로 플레이됩니다.

## 리디자인 진행 상태 (2026-11-21)

처음의 남색·금색 카드 화면(V1)은 제외했고, 같은 게임을 두 가지 화풍으로 비교하는 중입니다. 문제·정답·보상 로직은 그대로입니다.

| 안 | 화풍 | 여는 방법 |
|---|---|---|
| A안 | 수채 드로잉 — 펜선과 덜 채운 수채화, 오래된 종이 | 기본값, 또는 주소 끝에 `?art=ink` |
| B안 | 픽셀 아트 — 닌텐도 DS 와 90년대 어드벤처 게임의 감성 | 주소 끝에 `?art=pixel` |

- 두 안 모두 **입학부터 신분증까지 전 화면**에 적용되어 있습니다: 입학, 메인 홈, 암호 해독, 연습실, 진술 추리, 채점 결과, 승급 시험(봉투·풀이·승급 증서·합격 기록), 탐정 신분증. V1 화면은 코드에서 걷어냈습니다.
- 어느 안으로 갈지는 아직 정해지지 않았습니다. 정해지면 다른 안을 걷어냅니다.
- 두 안 나란히 조작해 보기: 개발 서버를 켠 뒤 <http://localhost:5183/compare.html> (위쪽 장면 단추로 두 화면을 같은 장면으로 엽니다)
- 비교 문서: `docs/compare/DETECTIVE_ACADEMY_AB_Compare.html` (단일 파일본은 `docs/DETECTIVE_ACADEMY_AB_Compare.html`)
- V1 보관: `docs/v1/screenshots/`(캡처), `docs/v1/app/`(빌드본)

## 실행

```bash
npm install
```

```bash
npm run dev
```

브라우저에서 <http://localhost:5183> 을 엽니다. 같은 와이파이의 휴대폰에서 확인하려면 `npm run dev:lan` 을 실행한 뒤 터미널에 표시되는 Network 주소로 접속합니다.

| 명령 | 내용 |
|---|---|
| `npm run dev` | 개발 서버 (포트 5183) |
| `npm run build` | 타입 검사 후 `dist/` 에 빌드 |
| `npm run preview` | 빌드 결과 미리보기 (포트 4183) |
| `npm test` | 엔진 단위 테스트 (Vitest) — 정답 유일성 포함 |
| `npm run test:e2e` | 주요 플레이 흐름·화면 크기별 테스트 (Playwright) |
| `npm run verify` | 타입 검사 + 단위 테스트 + E2E 한 번에 |

E2E 테스트를 처음 돌리는 기기에서는 `npx playwright install chromium` 이 한 번 필요합니다.

### 그림 작업용 스크립트

| 명령 | 내용 |
|---|---|
| `node scripts/render-art.ts [desk\|examroom]` | 직접 그린 배경(추리 책상, 시험실)을 SVG 필터로 그려 `src/assets/art/*.webp` 로 굽기 |
| `node scripts/pixelize.mjs <in> <out.png> <x,y,w,h> <W>x<H> [색 수]` | 그림을 저해상도·적은 색·점묘의 픽셀 배경으로 변환 (B안) |
| `node scripts/shot.mjs <out.png> <프리셋> ["#/경로"] [--w 390 --h 844] [--click a,b] [--art pixel]` | 개발 서버 화면 캡처 (검수용) |
| `node scripts/capture-compare.mjs <폴더> [ink\|pixel]` | 비교 문서용 전환 프레임과 그림 조각 캡처 |
| `node scripts/capture-rooms.mjs <폴더> [ink\|pixel] [--h 664] [--only 이름,…]` | 입학·연습실·진술 추리·승급 시험·신분증 19장을 한 번에 캡처 |
| `node scripts/to-webp.mjs <폴더> <폭> 이름=파일.png ...` | 캡처를 WebP 로 변환 |

## 상태별 화면 확인 (QA)

주소 끝에 `?demo=1` 을 붙이면 화면 왼쪽 가장자리에 `QA` 손잡이가 나타납니다. 일반 사용자 화면에는 나오지 않습니다.

- 첫 실행 상태로 초기화
- 오늘의 문제 미해결
- 오늘의 문제 해결
- 승급 시험 가능
- 승급 완료

프리셋은 손으로 짜 맞춘 상태가 아니라 실제 엔진 함수를 순서대로 호출해 만듭니다.

## 구조

```text
src/
  app/        앱 조립 — App, 해시 라우터, 저장소(localStorage), 효과음, 다음 행동 판단, 화풍 전환(art.ts), QA 패널
  engine/     화면과 무관한 순수 로직
    types.ts            문제·입력·저장 상태 타입
    puzzleValidator.ts  전수 탐색 정답 검증, 답안 채점, 힌트·해설 점검
    progressEngine.ts   입학·힌트·제출·보상·승급 (GameState → GameState)
    creditEngine.ts     크레딧 정책과 계산
    time.ts             Asia/Seoul 날짜, 시간 표기
  data/
    puzzles.ts          문제 3종 (규칙·힌트·해설·선언 정답)
    ranks.ts            등급, 승급 조건
  art/        그림 재료 — A안: sketch.ts(손그림 펜선), Art.tsx(수채 필터·물감 면·펜선·빨간 펜), objects.tsx(엠블럼·봉투·열쇠 등)
              B안: pixel.tsx(격자에 점을 찍어 만든 스프라이트와 점 표시)
              portraits.tsx(학생 초상: 화풍에 따라 펜 스케치 또는 스프라이트)
  assets/art/ 배경 그림 — corridor·desk·examroom .webp(A안), corridor-px·desk-px·examroom-px .png(B안)
  games/      퍼즐별 조작 화면 — CodeBreaker, TruthDeduction, SchedulePuzzle
  screens/    입학(복도), 홈(복도), 연습실·풀이(DeskPlay)·채점 결과(DeskResult)·신분증(책상), 승급 시험(시험실)
              usePlaySession.ts 가 풀이 진행(입력·시간·제출·판정)을 맡고 화면은 그리기만 한다
  components/ 신분증, 인장, 시험 봉투, 힌트 서랍, 크레딧 꼬리표
  styles/     디자인 토큰과 스타일 — art.css·hall.css·desk.css·rooms.css 가 A안, pixel.css·pixel-rooms.css 가 B안
  tests/      Vitest 단위 테스트
e2e/          Playwright 테스트
scripts/      그림 굽기와 화면 캡처
docs/screenshots/  E2E 테스트가 찍은 주요 화면
docs/compare/      기존·신규 비교 문서
docs/v1/           V1 캡처와 빌드본
```

## 정답 검증 방식

문제 데이터에 적힌 `solution` 을 그대로 믿지 않습니다.

- **풀이**: 가능한 모든 경우를 만들어 규칙을 적용합니다. 암호는 504개, 진술은 범인 후보 4명, 순서는 24개를 전부 검사합니다.
- **유일성**: 조건을 만족하는 답이 정확히 1개이고 선언된 정답과 같은지 확인합니다. 문제 데이터를 고쳐 답이 0개 또는 2개 이상이 되면 `npm test` 가 실패합니다.
- **채점**: 플레이어 답안은 선언된 정답과 비교하지 않고 문제의 규칙으로 채점합니다.
- **힌트·해설**: 글과 함께 기계가 검사할 수 있는 사실(`facts`)을 적어 두고, 실제 정답과 모순되지 않는지, 힌트만으로 후보가 하나로 줄어 정답이 드러나지 않는지 점검합니다.

개발 서버에서는 같은 검사를 시작할 때 한 번 더 돌려 문제가 있으면 콘솔에 오류를 남깁니다.

## 바꾸기 쉬운 값

| 바꿀 것 | 위치 |
|---|---|
| 최초 지급 크레딧, 힌트 비용 | `src/engine/creditEngine.ts` 의 `CREDIT_POLICY` |
| 문제별 보상, 단서, 힌트, 해설 | `src/data/puzzles.ts` |
| 등급 이름, 승급 조건, 시험 문제 | `src/data/ranks.ts` 의 `RANKS`, `PROMOTION_RULES` |
| 날짜별 오늘의 문제 배정 | `src/data/puzzles.ts` 의 `getDailyPuzzle(dateKey)` |
| 색, 서체, 모션 곡선 | `src/styles/tokens.css` (아래쪽 V2 블록) |
| 손그림 선의 흔들림, 수채 번짐 | `src/art/sketch.ts`, `src/art/Art.tsx` 의 필터 |

승급 조건(오늘의 추리 1개 + 연습실 1개)과 크레딧 수치는 데모 전용입니다.

## 저장

진행 상태는 브라우저 `localStorage` 의 `detective-academy:v1` 키에 저장됩니다. 입학 여부, 닉네임, 등급, 크레딧, 문제별 상태·입력값·힌트 단계·풀이 시간·제출 횟수·보상 수령 여부, 승급 기록, 효과음 설정이 들어갑니다. 서버·계정은 없습니다.

## 이번 버전에 없는 것

스토리 모드, 서버·계정·순위표, 결제·광고, 푸시 알림, AI 문제 생성, 날짜별 문제 배정 시스템, D급 이후의 승급 시험.
