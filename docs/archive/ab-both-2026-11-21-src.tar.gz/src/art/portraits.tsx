import type { ReactNode } from "react";
import { useArt } from "../app/art";
import type { Person } from "../engine/types";
import { PX, Sprite, type Hair, type HairTone, type PortraitSpec, type Tone } from "./pixel";

/**
 * 학생 초상. 학생부에 붙은 증명사진처럼 그린다.
 * 사람마다 머리 모양과 교복 색이 달라, 색을 구분하기 어려워도 실루엣으로 알아볼 수 있다.
 * 장식용이므로 스크린리더에는 숨기고, 이름은 곁에 글자로 둔다.
 */

export const PORTRAITS: Record<string, PortraitSpec> = {
  hana: { hair: "bob", hairTone: "dark", tone: "green" },
  junho: { hair: "short", hairTone: "brown", tone: "brass", glasses: true },
  sera: { hair: "long", hairTone: "auburn", tone: "wine" },
  daon: { hair: "curly", hairTone: "dark", tone: "steel" },
  doyun: { hair: "side", hairTone: "dark", tone: "brass" },
  minjae: { hair: "crop", hairTone: "brown", tone: "steel", glasses: true },
  sea: { hair: "pony", hairTone: "brown", tone: "wine" },
  harin: { hair: "braid", hairTone: "sand", tone: "green" },
};

/** 신분증 사진: 학원 모자를 쓴 견습 탐정 */
export const CADET: PortraitSpec = { hair: "cap", hairTone: "dark", tone: "navy" };

const FALLBACK: Record<Person["mark"], PortraitSpec> = {
  circle: { hair: "bob", hairTone: "dark", tone: "green" },
  shield: { hair: "short", hairTone: "brown", tone: "brass" },
  hex: { hair: "long", hairTone: "auburn", tone: "wine" },
  diamond: { hair: "crop", hairTone: "dark", tone: "steel" },
};

export function specOf(person: Person): PortraitSpec {
  return PORTRAITS[person.id] ?? FALLBACK[person.mark];
}

const HAIR_TINT: Record<HairTone, string> = {
  dark: "#2f2622",
  brown: "#6b4630",
  auburn: "#8a4632",
  sand: "#b08a4e",
};

const TONE_TINT: Record<Tone, string> = {
  green: "#3a715e",
  brass: "#a5823c",
  wine: "#8a3f4b",
  steel: "#4f6486",
  navy: "#2d3a4f",
};

const LINE = {
  fill: "none",
  stroke: "var(--ink)",
  strokeWidth: 1.25,
  strokeLinecap: "round",
  strokeLinejoin: "round",
} as const;

const HEAD = "M20.500 29C20.500 19 26 14.500 32 14.500C38 14.500 43.500 19 43.500 29C43.500 39 38 46 32 46C26 46 20.500 39 20.500 29Z";
const SHOULDERS = "M5 78C5 63 14 58 25 55.500L39 55.500C50 58 59 63 59 78Z";

interface HairShape {
  /** 물감을 채울 모양 */
  fill: string;
  /** 펜으로 덧그리는 결 */
  strokes?: string;
  /** 어깨 뒤로 넘어가는 부분 (어깨보다 먼저 그린다) */
  behind?: string;
}

const BRAID =
  "M21.500 33C18.500 37 22 40 19.800 44C17.600 48 21.500 51 19.800 55C18.600 58 20.800 60.500 20.200 63.500L24.600 63C25.400 60 23.200 58 24.400 54.500C25.800 50.500 22.800 48 24.200 44C25.400 40.500 23.200 38 23.800 34.500Z";

const HAIR: Record<Hair, HairShape> = {
  short: {
    fill: "M20 29.500C18.300 17 25 11.500 32 11.500C39 11.500 45.700 17 44 29.500C42.700 24.500 39.500 21 35 20.600C30.500 22.600 25.500 22 23 20.800C21.400 23.200 20.600 26.500 20 29.500Z",
    strokes: "M24 19.500C27 16.500 31 15.500 35 16.200M36.500 14.500C39.500 15.500 41.500 18 42.500 21",
  },
  bob: {
    fill: "M19 33C17 16.500 25 10.800 32 10.800C39 10.800 47 16.500 45 33C45.600 40 45 46 43 49.500L41.200 36C41 27 38 22 32 22.500C26 22 23 27 22.800 36L21 49.500C19 46 18.400 40 19 33Z",
    strokes: "M24 23.500C27 20 31 19 35 20C38 20.600 40 22.500 41 25M20.500 30C20.500 37 20.800 43 21.500 47M43.500 30C43.500 37 43.200 43 42.500 47",
  },
  long: {
    fill: "M19 33C17 16.500 25 10.800 32 10.800C39 10.800 47 16.500 45 33C45 36 44.500 38 43.800 39.500L41.200 36C41 27 38 22 32.500 22.500L31 16.500L29.500 22.600C25 23 23 28 22.800 36L20.200 39.500C19.500 38 19 36 19 33Z",
    behind:
      "M19.500 30C17.500 44 16 56 13.500 67L25 64C24 54 23.500 44 23.500 36ZM44.500 30C46.500 44 48 56 50.500 67L39 64C40 54 40.500 44 40.500 36Z",
    strokes: "M31 16.500C28 18.500 25.500 21.500 24 25M32.500 16.500C36 18 39 21 40.500 25M17.500 50C17 56 16 61 15 65M46.500 50C47 56 48 61 49 65",
  },
  pony: {
    fill: "M20 29.500C18.300 17 25 11.500 32 11.500C39 11.500 45.700 17 44 29.500C42.700 24.500 40.500 21.500 37.500 20.500C32 23 26 22.500 23 20.800C21.400 23.200 20.600 26.500 20 29.500ZM43.500 19.500C52 18.500 57.500 29 53.500 43C52.800 48 50.800 52 48 54C49.700 46 49.200 38 46.700 32C45.700 28.500 44.700 25 43.500 19.500Z",
    strokes: "M24 19.500C27.500 16.500 32 15.500 36.500 17M47.500 23C51.500 28 52.500 36 50.500 46M43 18.500L45.500 21.500",
  },
  curly: {
    fill: "M19.500 30C16.500 27 16.500 22 19.500 20C19 15.500 23 12.500 26.500 13.500C28.500 10 34.500 9.800 37 13C41 11.800 45 15 44.500 19.500C47.500 21.500 47.800 26.500 44.800 29.500C44.500 25.500 42 23 38.500 22.800C35.500 24.500 30.500 24.800 27 23C23.500 23.200 20.500 26 19.500 30Z",
    strokes:
      "M21.500 18.500a2.400 2.400 0 1 0 4.400 1.200M28.500 14.800a2.400 2.400 0 1 0 4.400 .9M35.800 16a2.400 2.400 0 1 0 4.400 1.300M40.500 22a2.100 2.100 0 1 0 3.400 1.700M19.500 24.500a2 2 0 1 0 3.400 1.200",
  },
  side: {
    fill: "M20.200 30C18 17 25.500 11 33 11C40.500 11 46 17 44 30C43 25.500 41.500 22.800 39.500 21.500C34 22.500 28 21 25 18.500C22.500 21.500 21 25.500 20.200 30Z",
    strokes: "M25 18.500C29 15.500 35 14.800 40.500 17.500M27.500 16C31 14 35.500 13.800 39 15",
  },
  crop: {
    fill: "M20.800 26.500C20 17 26 13 32 13C38 13 44 17 43.200 26.500C41.500 22.800 38 20.500 32 20.500C26 20.500 22.500 22.800 20.800 26.500Z",
    strokes: "M24.500 17.500l1 2M28 15.500l.800 2.200M32 14.800v2.300M36 15.500l-.800 2.200M39.500 17.500l-1 2",
  },
  braid: {
    fill: `M20 29.500C18.300 17 25 11.500 32 11.500C39 11.500 45.700 17 44 29.500C42.500 24.500 39 21.500 32.500 21.500L32 16L31.500 21.500C25 21.500 21.500 24.500 20 29.500Z${BRAID}M42.500 33C45.500 37 42 40 44.200 44C46.400 48 42.500 51 44.200 55C45.400 58 43.200 60.500 43.800 63.500L39.400 63C38.600 60 40.800 58 39.600 54.500C38.200 50.500 41.200 48 39.800 44C38.600 40.500 40.800 38 40.200 34.500Z`,
    strokes:
      "M19.800 39.500l4.200-1.500M20.200 44.500l4-1.500M19.800 50l4.200-1.500M20.200 55.500l4-1.500M44.200 39.500l-4.200-1.500M43.800 44.500l-4-1.500M44.200 50l-4.200-1.500M43.800 55.500l-4-1.500",
  },
  cap: {
    fill: "M20.500 31C19.500 26 20.500 23 22 21.500L42 21.500C43.500 23 44.500 26 43.500 31C42.500 28 41.500 26.500 40 25.500L24 25.500C22.500 26.500 21.500 28 20.500 31Z",
  },
};

function Wash({ children, opacity = 1 }: { children: ReactNode; opacity?: number }) {
  return (
    <g filter="url(#wash-fine)" opacity={opacity} style={{ mixBlendMode: "multiply" }} transform="translate(.8 .6)">
      {children}
    </g>
  );
}

function InkPortrait({ spec, size, className }: { spec: PortraitSpec; size: number; className?: string }) {
  const hair = HAIR[spec.hair];
  const hairTint = HAIR_TINT[spec.hairTone];
  const cap = spec.hair === "cap";

  return (
    <svg
      className={["art portrait", className].filter(Boolean).join(" ")}
      width={size}
      height={(size * 78) / 64}
      viewBox="0 0 64 78"
      aria-hidden="true"
      focusable="false"
    >
      {hair.behind && (
        <>
          <Wash opacity={0.9}>
            <path d={hair.behind} fill={hairTint} />
          </Wash>
          <path d={hair.behind} {...LINE} strokeWidth={1} filter="url(#rough)" />
        </>
      )}

      {/* 교복 */}
      <path d={SHOULDERS} fill="var(--leaf)" />
      <Wash opacity={0.92}>
        <path d={SHOULDERS} fill={TONE_TINT[spec.tone]} />
      </Wash>
      <path d="M25 55.500L32 67L39 55.500Z" fill="var(--leaf)" />
      <path d="M30.600 61H33.400L34.600 70.500L32 74L29.400 70.500Z" fill={spec.tone === "wine" ? "#b9954f" : "var(--wine)"} opacity=".9" />
      <g filter="url(#rough)">
        <path d={SHOULDERS} {...LINE} />
        <path d="M25 55.500L32 67L39 55.500M25 55.500L28.500 72M39 55.500L35.500 72" {...LINE} strokeWidth={1} />
      </g>

      {/* 목과 얼굴 */}
      <path d="M27.200 44V56.500L32 62L36.800 56.500V44Z" fill="var(--leaf)" />
      <path d={HEAD} fill="var(--leaf)" />
      <Wash opacity={0.85}>
        <path d="M27.200 44V56.500L32 62L36.800 56.500V44Z" fill="#c99b78" />
        <path d={HEAD} fill="#e3b892" />
      </Wash>
      <g filter="url(#rough)">
        <path d="M27.200 46.500V55.500M36.800 46.500V55.500" {...LINE} strokeWidth={1} />
        <path d={HEAD} {...LINE} />
      </g>
      <path d="M26 31.200h2.800M35.200 31.200h2.800" {...LINE} strokeWidth={1.9} />
      <path d="M25 27.600Q27.200 26.200 29.600 27.200M34.400 27.200Q36.800 26.200 39 27.600" {...LINE} strokeWidth={0.9} />
      <path d="M32 32.500L30.800 37.400H32.800" {...LINE} strokeWidth={0.9} />
      <path d="M29 40.800Q32 42.400 35 40.800" {...LINE} strokeWidth={1} />

      {/* 머리 */}
      <Wash opacity={0.95}>
        <path d={hair.fill} fill={hairTint} />
      </Wash>
      <g filter="url(#rough)">
        <path d={hair.fill} {...LINE} strokeWidth={1.1} />
        {hair.strokes && <path d={hair.strokes} {...LINE} strokeWidth={0.8} opacity={0.75} />}
      </g>

      {cap && (
        <>
          <path d="M19 21.500C19 9.500 45 9.500 45 21.500Z" fill="var(--leaf)" />
          <Wash>
            <path d="M19 21.500C19 9.500 45 9.500 45 21.500Z" fill="#2d3a4f" />
            <path d="M18.500 21.500H45.500V25.800H18.500Z" fill="#8e3a42" />
            <path d="M14.500 25.800C22 24 42 24 49.500 25.800C46.500 30 17.500 30 14.500 25.800Z" fill="#221b1a" />
          </Wash>
          <g filter="url(#rough)">
            <path d="M19 21.500C19 9.500 45 9.500 45 21.500ZM18.500 21.500H45.500V25.800H18.500ZM14.500 25.800C22 24 42 24 49.500 25.800C46.500 30 17.500 30 14.500 25.800Z" {...LINE} strokeWidth={1.1} />
          </g>
          <circle cx="32" cy="16.500" r="2.300" fill="#c9a23f" stroke="var(--ink)" strokeWidth=".7" />
        </>
      )}

      {spec.glasses && (
        <g filter="url(#rough)">
          <path d="M23 31.300a4.300 4 0 1 0 8.600 0a4.300 4 0 1 0-8.600 0ZM32.400 31.300a4.300 4 0 1 0 8.600 0a4.300 4 0 1 0-8.600 0ZM31.600 30.800h.8M23 30.600l-2.200-.8M41 30.600l2.200-.8" {...LINE} strokeWidth={1.1} />
        </g>
      )}
    </svg>
  );
}

interface Props {
  /** 문제 속 인물. 없으면 spec 을 쓴다. */
  person?: Person;
  spec?: PortraitSpec;
  /** 그림의 너비(px) */
  size?: number;
  className?: string;
}

/** 초상. A안은 펜과 물감, B안은 점으로 찍는다. */
export function Portrait({ person, spec, size = 44, className }: Props) {
  const pixel = useArt() === "pixel";
  const resolved = spec ?? (person ? specOf(person) : CADET);
  if (pixel) {
    // 점 크기를 정수로 맞춘다 (초상 격자의 너비는 20점 안팎)
    const scale = Math.max(PX, Math.round(size / 20 / PX) * PX);
    return <Sprite name="portrait" portrait={resolved} scale={scale} className={["portrait", className].filter(Boolean).join(" ")} />;
  }
  return <InkPortrait spec={resolved} size={size} className={className} />;
}
