import { useMemo, type ReactNode } from "react";
import { useArt } from "../app/art";
import { SHAPES } from "../components/DetectiveBadge";
import type { RankId } from "../engine/types";
import { Sprite } from "./pixel";
import * as sketch from "./sketch";

/**
 * 손으로 그린 물건들. 펜선(sketch) 위에 수채 물감(#wash-fine)을 살짝 어긋나게 얹는다.
 * 전부 장식용이므로 스크린리더에는 숨기고, 이름은 감싸는 버튼·문단이 갖는다.
 */

const INK = {
  fill: "none",
  stroke: "var(--ink)",
  strokeWidth: 1.15,
  strokeLinecap: "round",
  strokeLinejoin: "round",
} as const;

function Tint({ children, opacity = 1, broad = false }: { children: ReactNode; opacity?: number; broad?: boolean }) {
  return (
    <g filter={`url(#${broad ? "wash" : "wash-fine"})`} opacity={opacity} style={{ mixBlendMode: "multiply" }}>
      {children}
    </g>
  );
}

interface ArtProps {
  size?: number;
  className?: string;
}

function Art({
  w,
  h,
  width,
  className,
  children,
}: {
  w: number;
  h: number;
  width: number;
  className?: string;
  children: ReactNode;
}) {
  return (
    <svg
      className={["art", className].filter(Boolean).join(" ")}
      width={width}
      height={(width * h) / w}
      viewBox={`0 0 ${w} ${h}`}
      aria-hidden="true"
      focusable="false"
    >
      {children}
    </svg>
  );
}

/* ───────── 학원 엠블럼: 방패 안의 돋보기와 열쇠 구멍 ───────── */

function InkCrest({ size = 44, className }: ArtProps) {
  const d = useMemo(
    () => ({
      top: sketch.line(8, 9, 56, 9, { seed: 11, over: 3, wobble: 0.6 }),
      left: sketch.curve(
        [
          [9, 9],
          [9, 37],
          [13, 49],
          [21, 58],
          [32, 67],
        ],
        { seed: 12, wobble: 0.7 },
      ),
      right: sketch.curve(
        [
          [55, 9],
          [55, 37],
          [51, 49],
          [43, 58],
          [32, 67],
        ],
        { seed: 13, wobble: 0.7 },
      ),
      glass: sketch.ellipse(29, 31, 11.5, 11.5, { seed: 14, wobble: 0.9, passes: 2 }),
      shade: sketch.hatch(40, 14, 12, 26, { seed: 15, gap: 3.2, wobble: 0.5 }),
    }),
    [],
  );

  return (
    <Art w={64} h={72} width={size} className={className}>
      <Tint>
        <path d="M10.2 10.4H56.2V38.4C56.2 54.4 45.2 63.4 33.2 68.4C21.2 63.400 10.2 54.4 10.2 38.4Z" fill="#8e3a42" opacity=".88" />
      </Tint>
      <path d={d.shade} {...INK} strokeWidth={0.7} opacity={0.5} />
      <circle cx="29" cy="31" r="11" fill="var(--leaf)" />
      <path d={d.top + d.left + d.right} {...INK} strokeWidth={1.5} />
      <path d="M13.5 13.5H50.5V36.500C50.5 49.500 41.500 57 32 61.5C22.5 57 13.5 49.500 13.5 36.500Z" {...INK} strokeWidth={0.6} opacity={0.55} />
      <path d={d.glass} {...INK} strokeWidth={1.5} />
      <path d="M37.800 39.800L47.5 49.800" {...INK} strokeWidth={3.6} />
      <circle cx="29" cy="28.300" r="3.300" fill="var(--ink)" />
      <path d="M27.200 30.500H30.800L32.200 37.200H25.800Z" fill="var(--ink)" />
    </Art>
  );
}

/* ───────── 등급 표식: 등급마다 실루엣이 다르다 ───────── */

const RANK_TINT: Record<RankId, string> = {
  F: "#8f9195",
  D: "#b46c3c",
  C: "#6f8498",
  B: "#b3bac1",
  A: "#c9a23f",
  S: "#5a2c36",
};

function InkRankMark({ rank, size = 40, className }: ArtProps & { rank: RankId }) {
  const shape = SHAPES[rank];
  return (
    <Art w={96} h={96} width={size} className={className}>
      <Tint>
        <path d={shape} fill={RANK_TINT[rank]} transform="translate(2.5 2)" />
      </Tint>
      <g filter="url(#rough)">
        <path d={shape} {...INK} strokeWidth={3} />
        <path d={shape} {...INK} strokeWidth={1.2} opacity={0.55} transform="translate(48 48) scale(.8) translate(-48 -48)" />
      </g>
      <text
        x="48"
        y={rank === "S" ? 66 : rank === "D" || rank === "B" ? 58 : 60}
        textAnchor="middle"
        fontFamily="Cinzel, serif"
        fontWeight="700"
        fontSize="34"
        fill={rank === "S" ? "#f3e6c4" : "var(--ink)"}
      >
        {rank}
      </text>
    </Art>
  );
}

/* ───────── 압정 ───────── */

function InkPushpin({ size = 20, className, tone = "#8e3a42" }: ArtProps & { tone?: string }) {
  const ring = useMemo(() => sketch.ellipse(10, 9, 6.2, 6.2, { seed: 31, wobble: 0.5, passes: 1 }), []);
  return (
    <Art w={22} h={24} width={size} className={className}>
      <ellipse cx="12.500" cy="14.500" rx="6" ry="4" fill="var(--ink)" opacity=".22" />
      <Tint>
        <circle cx="10.400" cy="9.300" r="6.200" fill={tone} />
      </Tint>
      <path d={ring} {...INK} strokeWidth={1} />
      <path d="M6.800 7.400C7.800 5.600 9.400 4.900 11 5" {...INK} stroke="var(--leaf)" strokeWidth={1.3} opacity={0.85} />
    </Art>
  );
}

/* ───────── 시험 봉투 ───────── */

function InkEnvelopeArt({ size = 96, className, open = false }: ArtProps & { open?: boolean }) {
  const d = useMemo(
    () => ({
      body: sketch.rect(5, 12, 94, 54, { seed: 41, over: 3, wobble: 0.8 }),
      flap: sketch.line(5, 12, 52, 42, { seed: 42, over: 1, wobble: 0.7 }) + sketch.line(99, 12, 52, 42, { seed: 43, over: 1, wobble: 0.7 }),
      folds:
        sketch.line(5, 66, 39, 38, { seed: 44, over: 0, wobble: 0.6, passes: 1 }) +
        sketch.line(99, 66, 65, 38, { seed: 45, over: 0, wobble: 0.6, passes: 1 }),
      openFlap: sketch.line(5, 12, 52, -12, { seed: 46, over: 1, wobble: 0.7 }) + sketch.line(99, 12, 52, -12, { seed: 47, over: 1, wobble: 0.7 }),
      letter: sketch.rect(15, -2, 74, 40, { seed: 48, over: 2, wobble: 0.6 }),
      seal: sketch.ellipse(52, 42, 9.5, 9.5, { seed: 49, wobble: 0.9, passes: 1 }),
      hatch: sketch.hatch(62, 44, 34, 20, { seed: 50, gap: 4, wobble: 0.6 }),
    }),
    [],
  );

  return (
    <Art w={104} h={72} width={size} className={className}>
      {open && (
        <>
          <path d="M5 12L52-12L99 12Z" fill="var(--leaf-shade)" />
          <path d={d.openFlap} {...INK} />
          <rect x="15" y="-2" width="74" height="40" fill="var(--leaf)" />
          <path d={d.letter} {...INK} strokeWidth={0.9} />
          <path d="M24 8H80M24 16H72M24 24H76" {...INK} strokeWidth={0.8} opacity={0.5} />
        </>
      )}
      <rect x="5" y="12" width="94" height="54" fill="var(--leaf)" />
      <Tint>
        <rect x="6.500" y="13.500" width="94" height="54" fill="#b7aa93" opacity=".8" />
        {!open && <path d="M6 13L52 43L100 13Z" fill="#8f8372" opacity=".55" />}
      </Tint>
      <path d={d.hatch} {...INK} strokeWidth={0.6} opacity={0.4} />
      <path d={d.body} {...INK} />
      <path d={d.folds} {...INK} strokeWidth={0.8} opacity={0.6} />
      {!open && (
        <>
          <path d={d.flap} {...INK} />
          <Tint>
            <circle cx="52.600" cy="42.600" r="10" fill="#8e3a42" />
          </Tint>
          <path d={d.seal} {...INK} strokeWidth={1} />
          <circle cx="52" cy="40.300" r="2" fill="var(--ink)" opacity=".8" />
          <path d="M50.900 41.500H53.100L54 46.200H50Z" fill="var(--ink)" opacity=".8" />
        </>
      )}
    </Art>
  );
}

/* ───────── 연습실 열쇠 ───────── */

function InkKeyArt({ size = 84, className }: ArtProps) {
  const d = useMemo(
    () => ({
      bow: sketch.ellipse(18, 38, 11, 12.500, { seed: 61, wobble: 0.9, passes: 2 }) + sketch.ellipse(18, 38, 4.6, 5.4, { seed: 62, wobble: 0.6, passes: 1 }),
      shaft:
        sketch.line(29, 35, 70, 35, { seed: 63, over: 1.5, wobble: 0.6 }) +
        sketch.line(29, 41, 70, 41, { seed: 64, over: 1.5, wobble: 0.6 }) +
        sketch.line(70, 35, 70, 41, { seed: 65, over: 1, wobble: 0.4, passes: 1 }),
      teeth: sketch.poly(
        [
          [54, 41],
          [54, 50],
          [58, 50],
          [58, 45],
          [62, 45],
          [62, 51],
          [67, 51],
          [67, 41],
        ],
        { seed: 66, over: 0.8, wobble: 0.5, passes: 1 },
      ),
      string: sketch.curve(
        [
          [18, 25.500],
          [24, 13],
          [38, 9],
          [52, 13],
        ],
        { seed: 67, wobble: 0.8, passes: 1 },
      ),
      tag: sketch.rect(0, 0, 34, 19, { seed: 68, over: 2, wobble: 0.6 }),
    }),
    [],
  );

  return (
    <Art w={92} h={60} width={size} className={className}>
      <Tint>
        <path d="M19 26a11 12.500 0 1 0 0 25a11 12.500 0 1 0 0-25ZM19 33.600a4.600 5.400 0 1 1 0 10.800a4.600 5.400 0 1 1 0-10.800Z" fill="#c39a52" fillRule="evenodd" />
        <path d="M30 36H71V42H68V52H55V42H30Z" fill="#c39a52" />
      </Tint>
      <path d={d.bow + d.shaft + d.teeth} {...INK} />
      <path d={d.string} {...INK} strokeWidth={0.9} opacity={0.75} />
      <g transform="translate(50 4) rotate(9)">
        <rect width="34" height="19" fill="var(--leaf)" />
        <path d={d.tag} {...INK} strokeWidth={0.95} />
        <circle cx="4.500" cy="9.500" r="1.700" {...INK} strokeWidth={0.9} />
        <path d="M10 7H29M10 12.500H24" {...INK} strokeWidth={0.8} opacity={0.45} />
      </g>
    </Art>
  );
}

/* ───────── 신분증 (작은 그림) ───────── */

function InkIdArt({ size = 84, className, rank }: ArtProps & { rank: RankId }) {
  const d = useMemo(
    () => ({
      card: sketch.rect(4, 6, 80, 50, { seed: 71, over: 2.5, wobble: 0.7 }),
      photo: sketch.rect(11, 22, 21, 27, { seed: 72, over: 1.5, wobble: 0.5 }),
      head: sketch.ellipse(21.500, 31.500, 4.6, 5.2, { seed: 73, wobble: 0.5, passes: 1 }),
      body: sketch.curve(
        [
          [13.500, 48],
          [15.500, 41],
          [21.500, 39],
          [27.500, 41],
          [29.500, 48],
        ],
        { seed: 74, wobble: 0.5, passes: 1 },
      ),
      lines:
        sketch.line(39, 25, 76, 25, { seed: 75, over: 0, wobble: 0.5, passes: 1 }) +
        sketch.line(39, 33, 70, 33, { seed: 76, over: 0, wobble: 0.5, passes: 1 }) +
        sketch.line(39, 41, 60, 41, { seed: 77, over: 0, wobble: 0.5, passes: 1 }),
      band: sketch.line(4, 16, 84, 16, { seed: 78, over: 1, wobble: 0.5, passes: 1 }),
    }),
    [],
  );

  return (
    <Art w={90} h={62} width={size} className={className}>
      <rect x="6" y="9" width="80" height="50" fill="var(--ink)" opacity=".16" rx="2" />
      <rect x="4" y="6" width="80" height="50" fill="var(--leaf)" rx="2" />
      <Tint>
        <rect x="5" y="7" width="80" height="10" fill="#8e3a42" opacity=".85" />
        <rect x="12" y="23" width="21" height="27" fill="#a49584" opacity=".6" />
        <circle cx="72.500" cy="44.500" r="6.500" fill={RANK_TINT[rank]} />
      </Tint>
      <path d={d.card} {...INK} />
      <path d={d.band} {...INK} strokeWidth={0.8} opacity={0.6} />
      <path d={d.photo + d.head + d.body} {...INK} strokeWidth={0.9} />
      <path d={d.lines} {...INK} strokeWidth={0.95} opacity={0.6} />
      <text x="72" y="48" textAnchor="middle" fontFamily="Cinzel, serif" fontWeight="700" fontSize="10" fill="var(--ink)">
        {rank}
      </text>
    </Art>
  );
}

/* ───────── 수사 크레딧 주화 ───────── */

function InkCoinsArt({ size = 56, className, count = 3 }: ArtProps & { count?: 1 | 2 | 3 }) {
  const coins = useMemo(() => {
    const out: { y: number; top: string; side: string }[] = [];
    for (let i = 0; i < count; i++) {
      const y = 40 - i * 8.500;
      const x = 31 + (i === 1 ? 2.5 : i === 2 ? -1.5 : 0);
      out.push({
        y,
        top: sketch.ellipse(x, y, 20, 7, { seed: 81 + i, wobble: 0.7, passes: 1 }),
        side:
          sketch.line(x - 20, y, x - 20, y + 6, { seed: 85 + i, over: 0.5, wobble: 0.4, passes: 1 }) +
          sketch.line(x + 20, y, x + 20, y + 6, { seed: 88 + i, over: 0.5, wobble: 0.4, passes: 1 }) +
          sketch.curve(
            [
              [x - 20, y + 6],
              [x - 10, y + 12],
              [x + 10, y + 12],
              [x + 20, y + 6],
            ],
            { seed: 91 + i, wobble: 0.5, passes: 1 },
          ),
      });
    }
    return out;
  }, [count]);

  return (
    <Art w={62} h={56} width={size} className={className}>
      <ellipse cx="33" cy="50" rx="23" ry="4.500" fill="var(--ink)" opacity=".16" />
      {coins.map((coin, i) => {
        const x = 31 + (i === 1 ? 2.5 : i === 2 ? -1.5 : 0);
        return (
          <g key={i}>
            <path d={`M${x - 20} ${coin.y}v6a20 7 0 0 0 40 0v-6a20 7 0 0 1-40 0Z`} fill="var(--leaf)" />
            <ellipse cx={x} cy={coin.y} rx="20" ry="7" fill="var(--leaf)" />
            <Tint>
              <path d={`M${x - 19} ${coin.y + 1}v6a20 7 0 0 0 40 0v-6a20 7 0 0 1-40 0Z`} fill="#a9833f" />
              <ellipse cx={x + 1} cy={coin.y + 0.800} rx="20" ry="7" fill="#d2ad62" />
            </Tint>
            <path d={coin.top + coin.side} {...INK} strokeWidth={1} />
          </g>
        );
      })}
      {coins.length > 0 && (
        <g transform={`translate(${31 + (coins.length === 3 ? -1.5 : coins.length === 2 ? 2.5 : 0)} ${coins[coins.length - 1].y})`}>
          <ellipse cx="0" cy="-0.800" rx="2.400" ry="1.300" fill="var(--ink)" opacity=".75" />
          <path d="M-1.300 0H1.300L2.200 2.600H-2.200Z" fill="var(--ink)" opacity=".75" />
        </g>
      )}
    </Art>
  );
}

/* ───────── 연필 ───────── */

function InkPencilArt({ size = 150, className }: ArtProps) {
  const d = useMemo(
    () => ({
      body: sketch.rect(22, 3, 104, 10, { seed: 101, over: 1.5, wobble: 0.6 }),
      mid: sketch.line(22, 8, 126, 8, { seed: 102, over: 0, wobble: 0.5, passes: 1 }),
      tip: sketch.poly(
        [
          [126, 3],
          [146, 8],
          [126, 13],
        ],
        { seed: 103, over: 0.8, wobble: 0.5, passes: 1 },
      ),
      ferrule: sketch.rect(12, 3, 10, 10, { seed: 104, over: 1, wobble: 0.5, passes: 1 }),
      eraser: sketch.rect(3, 3.500, 9, 9, { seed: 105, over: 1, wobble: 0.5, passes: 1 }),
    }),
    [],
  );
  return (
    <Art w={150} h={16} width={size} className={className}>
      <path d="M22 3H126L146 8L126 13H22Z" fill="var(--leaf)" />
      <rect x="3" y="3" width="19" height="10" fill="var(--leaf)" />
      <Tint>
        <rect x="23" y="4" width="104" height="10" fill="#8e3a42" />
        <path d="M127 4L147 9L127 14Z" fill="#d6b784" />
        <rect x="13" y="4" width="10" height="10" fill="#9a9a94" />
        <rect x="4" y="4.500" width="9" height="9" fill="#c98e86" />
      </Tint>
      <path d={d.body + d.tip + d.ferrule + d.eraser} {...INK} strokeWidth={1} />
      <path d={d.mid} {...INK} strokeWidth={0.7} opacity={0.45} />
      <path d="M140 6.500L146 8L140 9.500Z" fill="var(--ink)" />
    </Art>
  );
}

/* ───────── 종이 클립 ───────── */

function InkClipArt({ size = 20, className }: ArtProps) {
  return (
    <Art w={22} h={50} width={size} className={className}>
      <g filter="url(#rough)">
        <path d="M6 14v24a5 5 0 0 0 10 0V10a7.500 7.500 0 0 0-15 0v29a10 10 0 0 0 20 0V15" {...INK} strokeWidth={1.7} />
      </g>
    </Art>
  );
}

/* ───────── 화풍에 따라 그림을 고른다 ─────────
   A안(ink)은 위의 펜선·수채 그림, B안(pixel)은 pixel.tsx 의 스프라이트다.
   스프라이트는 점 크기를 지키기 위해 size 를 따르지 않고 정해진 크기로 그린다. */

export function Crest(props: ArtProps) {
  return useArt() === "pixel" ? <Sprite name="crest" className={props.className} /> : <InkCrest {...props} />;
}

export function RankMark(props: ArtProps & { rank: RankId }) {
  if (useArt() === "pixel") {
    return (
      <span className={["pxrank", props.className].filter(Boolean).join(" ")} data-rank={props.rank} aria-hidden="true">
        {props.rank}
      </span>
    );
  }
  return <InkRankMark {...props} />;
}

/** 큰 등급 휘장 (신분증·승급 증서·등급표) */
export function RankMedal(props: ArtProps & { rank: RankId; scale?: number }) {
  if (useArt() === "pixel") {
    return (
      <span className={["pxmedal", props.className].filter(Boolean).join(" ")} data-rank={props.rank} aria-hidden="true">
        <Sprite name="medal" rank={props.rank} scale={props.scale ?? 2} />
        <b>{props.rank}</b>
      </span>
    );
  }
  return <InkRankMark {...props} />;
}

export function Pushpin(props: ArtProps & { tone?: string }) {
  return useArt() === "pixel" ? <Sprite name="pin" className={props.className} /> : <InkPushpin {...props} />;
}

export function EnvelopeArt(props: ArtProps & { open?: boolean }) {
  return useArt() === "pixel" ? (
    <Sprite name={props.open ? "envelope-open" : "envelope"} className={props.className} />
  ) : (
    <InkEnvelopeArt {...props} />
  );
}

export function KeyArt(props: ArtProps) {
  return useArt() === "pixel" ? <Sprite name="key" className={props.className} /> : <InkKeyArt {...props} />;
}

export function IdArt(props: ArtProps & { rank: RankId }) {
  return useArt() === "pixel" ? <Sprite name="id" rank={props.rank} className={props.className} /> : <InkIdArt {...props} />;
}

export function CoinsArt(props: ArtProps & { count?: 1 | 2 | 3 }) {
  if (useArt() === "pixel") {
    return <Sprite name={props.count === 1 ? "coin" : "coins"} className={props.className} />;
  }
  return <InkCoinsArt {...props} />;
}

export function PencilArt(props: ArtProps) {
  return useArt() === "pixel" ? <Sprite name="pencil" className={props.className} /> : <InkPencilArt {...props} />;
}

export function ClipArt(props: ArtProps) {
  return useArt() === "pixel" ? null : <InkClipArt {...props} />;
}
