import { useMemo, type CSSProperties, type ReactNode } from "react";
import { useArt } from "../app/art";
import { PALETTE, PixelMark } from "./pixel";
import * as sketch from "./sketch";
import { useBox } from "./useBox";

/**
 * 그림 재료.
 * - ArtDefs: 수채 물감·연필·인주 필터 (앱에 한 번만 둔다)
 * - Wash: 요소 뒤에 깔리는 수채 물감 면
 * - Ink: 요소 둘레에 긋는 펜선
 * - PenMark: 빨간 펜 동그라미·체크·가위표·밑줄
 */

export function ArtDefs() {
  return (
    <svg className="artdefs" width="0" height="0" aria-hidden="true" focusable="false">
      <defs>
        {/* 수채 물감: 가장자리가 울고, 안쪽이 얼룩지고, 테두리에 물감이 고인다 */}
        <filter id="wash" x="-12%" y="-12%" width="124%" height="124%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="3" seed="4" result="warp" />
          <feDisplacementMap in="SourceGraphic" in2="warp" scale="8" xChannelSelector="R" yChannelSelector="G" result="shape" />
          <feGaussianBlur in="shape" stdDeviation="2.4" result="soft" />
          <feComponentTransfer in="soft" result="core">
            <feFuncA type="linear" slope="2.8" intercept="-1.62" />
          </feComponentTransfer>
          <feComposite in="shape" in2="core" operator="out" result="rim" />
          <feTurbulence type="fractalNoise" baseFrequency="0.014 0.022" numOctaves="3" seed="11" result="blot" />
          <feColorMatrix in="blot" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  1.7 0 0 0 -0.02" result="blotA" />
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="1" seed="5" result="grain" />
          <feColorMatrix in="grain" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0.55 0 0 0 0.58" result="grainA" />
          <feComposite in="shape" in2="blotA" operator="in" result="b1" />
          <feComposite in="b1" in2="grainA" operator="in" result="body" />
          <feComponentTransfer in="rim" result="rimA">
            <feFuncA type="linear" slope="0.42" />
          </feComponentTransfer>
          <feMerge>
            <feMergeNode in="body" />
            <feMergeNode in="rimA" />
          </feMerge>
        </filter>

        {/* 작은 물건용: 번짐이 작다 */}
        <filter id="wash-fine" x="-14%" y="-14%" width="128%" height="128%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.07" numOctaves="2" seed="9" result="warp" />
          <feDisplacementMap in="SourceGraphic" in2="warp" scale="3.6" xChannelSelector="R" yChannelSelector="G" result="shape" />
          <feGaussianBlur in="shape" stdDeviation="1.1" result="soft" />
          <feComponentTransfer in="soft" result="core">
            <feFuncA type="linear" slope="2.6" intercept="-1.5" />
          </feComponentTransfer>
          <feComposite in="shape" in2="core" operator="out" result="rim" />
          <feTurbulence type="fractalNoise" baseFrequency="0.04 0.06" numOctaves="2" seed="21" result="blot" />
          <feColorMatrix in="blot" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  1.5 0 0 0 0.08" result="blotA" />
          <feComposite in="shape" in2="blotA" operator="in" result="body" />
          <feComponentTransfer in="rim" result="rimA">
            <feFuncA type="linear" slope="0.4" />
          </feComponentTransfer>
          <feMerge>
            <feMergeNode in="body" />
            <feMergeNode in="rimA" />
          </feMerge>
        </filter>

        {/* 손으로 그은 흔들림: 반듯한 도형의 윤곽을 살짝 운다 */}
        <filter id="rough" x="-6%" y="-6%" width="112%" height="112%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.055" numOctaves="2" seed="13" result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale="2.4" xChannelSelector="R" yChannelSelector="G" />
        </filter>

        {/* 연필·마른 펜: 선이 군데군데 끊긴다 */}
        <filter id="dry" x="-6%" y="-6%" width="112%" height="112%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3" result="n" />
          <feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  2.4 0 0 0 -0.35" result="mask" />
          <feComposite in="SourceGraphic" in2="mask" operator="in" />
        </filter>

        {/* 인주: 가장자리가 번지고 군데군데 덜 찍힌다 */}
        <filter id="inkpad" x="-10%" y="-10%" width="120%" height="120%" colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="7" result="noise" />
          <feDisplacementMap in="SourceGraphic" in2="noise" scale="2.2" result="displaced" />
          <feTurbulence type="fractalNoise" baseFrequency=".035 .5" numOctaves="1" seed="3" result="streak" />
          <feColorMatrix in="streak" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 -3.2 2.6" result="mask" />
          <feComposite in="displaced" in2="mask" operator="in" />
        </filter>
      </defs>
    </svg>
  );
}

type Inset = number | [number, number, number, number];

function insets(inset: Inset): [number, number, number, number] {
  return typeof inset === "number" ? [inset, inset, inset, inset] : inset;
}

interface WashProps {
  color: string;
  /** 요소 안쪽으로 들어가는 여백. 음수면 밖으로 번진다. [위, 오른쪽, 아래, 왼쪽] */
  inset?: Inset;
  radius?: number;
  /** 같은 크기의 면이 똑같이 번지지 않게 한다 */
  seed?: number;
  opacity?: number;
  fine?: boolean;
  className?: string;
  style?: CSSProperties;
}

/** 요소 뒤에 깔리는 수채 물감 면. 부모는 position: relative 여야 한다. (픽셀 화풍에서는 그리지 않는다) */
export function Wash(props: WashProps) {
  return useArt() === "pixel" ? null : <InkWash {...props} />;
}

function InkWash({ color, inset = 0, radius = 5, seed = 1, opacity = 1, fine = false, className, style }: WashProps) {
  const [ref, box] = useBox<HTMLSpanElement>();
  const [t, r, b, l] = insets(inset);
  const pad = 14;
  const ox = (seed * 137) % 600;
  const oy = (seed * 71) % 600;
  const w = Math.max(0, box.w - l - r);
  const h = Math.max(0, box.h - t - b);

  return (
    <span ref={ref} className={["wash", className].filter(Boolean).join(" ")} style={style} aria-hidden="true">
      {box.w > 0 && (
        <svg
          width={box.w + pad * 2}
          height={box.h + pad * 2}
          viewBox={`${ox - pad} ${oy - pad} ${box.w + pad * 2} ${box.h + pad * 2}`}
          style={{ left: -pad, top: -pad }}
          focusable="false"
        >
          <rect
            x={ox + l}
            y={oy + t}
            width={w}
            height={h}
            rx={radius}
            fill={color}
            opacity={opacity}
            filter={`url(#${fine ? "wash-fine" : "wash"})`}
          />
        </svg>
      )}
    </span>
  );
}

interface InkProps {
  seed?: number;
  inset?: Inset;
  weight?: number;
  color?: string;
  over?: number;
  wobble?: number;
  passes?: number;
  opacity?: number;
  className?: string;
  /** 사각형 대신 그릴 것: 크기를 받아 path d 를 돌려준다 */
  draw?: (w: number, h: number) => string;
}

/** 요소 둘레(또는 draw 가 정한 모양)에 긋는 펜선. 부모는 position: relative 여야 한다. (픽셀 화풍에서는 그리지 않는다) */
export function Ink(props: InkProps) {
  return useArt() === "pixel" ? null : <InkLine {...props} />;
}

function InkLine({
  seed = 1,
  inset = 0,
  weight = 1.1,
  color = "var(--ink)",
  over = 4,
  wobble = 0.9,
  passes = 2,
  opacity = 0.86,
  className,
  draw,
}: InkProps) {
  const [ref, box] = useBox<HTMLSpanElement>();
  const [t, r, b, l] = insets(inset);
  const d = useMemo(() => {
    if (box.w === 0) return "";
    if (draw) return draw(box.w, box.h);
    return sketch.rect(l, t, box.w - l - r, box.h - t - b, { seed, over, wobble, passes });
    // draw 는 호출부에서 크기에만 의존하는 함수로 넘긴다.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [box.w, box.h, seed, over, wobble, passes, t, r, b, l]);

  return (
    <span ref={ref} className={["inkline", className].filter(Boolean).join(" ")} aria-hidden="true">
      {d && (
        <svg width={box.w} height={box.h} viewBox={`0 0 ${box.w} ${box.h}`} focusable="false">
          <path d={d} fill="none" stroke={color} strokeWidth={weight} strokeLinecap="round" strokeLinejoin="round" opacity={opacity} />
        </svg>
      )}
    </span>
  );
}

interface PenMarkProps {
  kind: "circle" | "check" | "cross" | "underline";
  seed?: number;
  /** 그려지는 모습을 보여 줄지 */
  draw?: boolean;
  delayMs?: number;
  weight?: number;
  color?: string;
  className?: string;
  children?: ReactNode;
}

/** 빨간 펜으로 친 표시. 부모 크기에 맞춰 그린다. 픽셀 화풍에서는 같은 표시를 점으로 찍는다. */
export function PenMark(props: PenMarkProps) {
  if (useArt() === "pixel") {
    return (
      <PixelMark
        kind={props.kind}
        className={props.className}
        draw={props.draw}
        delayMs={props.delayMs}
        color={props.color ? PALETTE.k : PALETTE.E}
      />
    );
  }
  return <InkPenMark {...props} />;
}

function InkPenMark({
  kind,
  seed = 3,
  draw = false,
  delayMs = 0,
  weight = 1.8,
  color = "var(--pen)",
  className,
}: PenMarkProps) {
  const [ref, box] = useBox<HTMLSpanElement>();
  const d = useMemo(() => {
    const { w, h } = box;
    if (w === 0) return "";
    switch (kind) {
      case "circle":
        return sketch.ellipse(w / 2, h / 2, w / 2 - 1.5, h / 2 - 1.5, { seed, wobble: 1.6, passes: 1, turns: 1.12 });
      case "check":
        return sketch.check(w * 0.12, h * 0.1, Math.min(w, h) * 0.8, { seed });
      case "cross":
        return sketch.cross(w * 0.16, h * 0.16, Math.min(w, h) * 0.68, { seed });
      case "underline":
        return sketch.underline(1, h - 2.5, w - 2, { seed, wobble: 1.1 });
    }
  }, [box, kind, seed]);

  return (
    <span
      ref={ref}
      className={["penmark", className].filter(Boolean).join(" ")}
      data-kind={kind}
      data-draw={draw}
      style={{ "--pen-delay": `${delayMs}ms` } as CSSProperties}
      aria-hidden="true"
    >
      {d && (
        <svg width={box.w} height={box.h} viewBox={`0 0 ${box.w} ${box.h}`} focusable="false">
          <path d={d} pathLength={1} fill="none" stroke={color} strokeWidth={weight} strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )}
    </span>
  );
}
