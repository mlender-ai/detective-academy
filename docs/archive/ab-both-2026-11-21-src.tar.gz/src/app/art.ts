/**
 * 화풍(아트 디렉션) 전환. 같은 게임을 두 가지 그림으로 비교해 보기 위한 것이다.
 *  - ink:   A안 · 펜선과 덜 채운 수채화 (Illustrated Mystery Academy)
 *  - pixel: B안 · 픽셀 아트, 닌텐도 DS 와 90년대 어드벤처 게임의 감성
 * 주소의 ?art=ink|pixel 이 가장 우선이고(비교 화면에서 두 안을 동시에 띄울 수 있다),
 * 없으면 마지막에 고른 값을 쓴다.
 */
import { useSyncExternalStore } from "react";

export type ArtMode = "ink" | "pixel";

const ART_KEY = "detective-academy:art";
const isArt = (value: unknown): value is ArtMode => value === "ink" || value === "pixel";

function initial(): ArtMode {
  if (typeof window === "undefined") return "ink";
  const fromUrl = new URLSearchParams(window.location.search).get("art");
  if (isArt(fromUrl)) return fromUrl;
  try {
    const saved = window.localStorage.getItem(ART_KEY);
    if (isArt(saved)) return saved;
  } catch {
    // 저장소를 못 써도 기본 화풍으로 진행한다
  }
  return "ink";
}

let current: ArtMode = initial();
const listeners = new Set<() => void>();

function apply() {
  if (typeof document !== "undefined") document.documentElement.dataset.art = current;
}
apply();

export function getArt(): ArtMode {
  return current;
}

export function setArt(mode: ArtMode) {
  if (mode === current) return;
  current = mode;
  apply();
  try {
    window.localStorage.setItem(ART_KEY, mode);
  } catch {
    // 무시
  }
  listeners.forEach((listener) => listener());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function useArt(): ArtMode {
  return useSyncExternalStore(subscribe, getArt, getArt);
}

export const ART_LABEL: Record<ArtMode, string> = {
  ink: "A안 · 수채 드로잉",
  pixel: "B안 · 픽셀 아트",
};
