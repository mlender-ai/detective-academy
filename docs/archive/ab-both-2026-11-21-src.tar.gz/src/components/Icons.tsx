/** 선 아이콘. 한 가지 굵기(1.75)와 둥근 끝으로 통일한다. */
import type { ReactNode, SVGProps } from "react";

type IconProps = { size?: number } & Omit<SVGProps<SVGSVGElement>, "children">;

function Base({ size = 22, children, ...rest }: IconProps & { children: ReactNode }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {children}
    </svg>
  );
}

export const IconBack = (p: IconProps) => (
  <Base {...p}>
    <path d="M14.5 5.5 8 12l6.5 6.5" />
  </Base>
);

export const IconChevronRight = (p: IconProps) => (
  <Base {...p}>
    <path d="m9.5 5.5 6.5 6.5-6.5 6.5" />
  </Base>
);

export const IconChevronUp = (p: IconProps) => (
  <Base {...p}>
    <path d="m6 14.5 6-6 6 6" />
  </Base>
);

export const IconChevronDown = (p: IconProps) => (
  <Base {...p}>
    <path d="m6 9.5 6 6 6-6" />
  </Base>
);

export const IconClose = (p: IconProps) => (
  <Base {...p}>
    <path d="M6.5 6.5 17.5 17.5M17.5 6.5 6.5 17.5" />
  </Base>
);

export const IconCheck = (p: IconProps) => (
  <Base {...p}>
    <path d="m5.5 12.5 4.2 4.2 8.8-9.4" />
  </Base>
);

export const IconClock = (p: IconProps) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8" />
    <path d="M12 7.5V12l3 2" />
  </Base>
);

/** 수사 지원(힌트): 등불 */
export const IconLantern = (p: IconProps) => (
  <Base {...p}>
    <path d="M10.200 4.600a1.900 1.900 0 0 1 3.600 0" />
    <path d="M8 9.200 9.600 5.600h4.800L16 9.200" />
    <path d="M7.500 9.200h9v10.300h-9Z" />
    <path d="M12 11.800c1 1.100 1.400 1.900 1.400 2.700a1.400 1.400 0 0 1-2.800 0c0-.8.400-1.600 1.400-2.700Z" />
    <path d="M6 19.500h12" />
  </Base>
);

export const IconLock = (p: IconProps) => (
  <Base {...p}>
    <rect x="5.500" y="10.500" width="13" height="9.500" rx="2" />
    <path d="M8.500 10.500V8a3.500 3.500 0 0 1 7 0v2.500" />
    <path d="M12 14.200v2.300" />
  </Base>
);

export const IconUndo = (p: IconProps) => (
  <Base {...p}>
    <path d="M8.500 5 4.500 9l4 4" />
    <path d="M5 9h8.500a5.500 5.500 0 0 1 0 11H9" />
  </Base>
);

export const IconReset = (p: IconProps) => (
  <Base {...p}>
    <path d="M5.200 9.500A7.300 7.300 0 1 1 4.700 12" />
    <path d="M5 4.500v5h5" />
  </Base>
);

export const IconPencil = (p: IconProps) => (
  <Base {...p}>
    <path d="m5 19 .900-3.900L15.700 5.300a1.900 1.900 0 0 1 2.700 0l.300.300a1.900 1.900 0 0 1 0 2.700L8.900 18.100Z" />
    <path d="m14 7 3 3" />
  </Base>
);

/** 연습실: 펼친 책 */
export const IconBook = (p: IconProps) => (
  <Base {...p}>
    <path d="M12 6.500C10.300 5.300 8 4.800 4.500 5v13c3.500-.2 5.800.300 7.500 1.500 1.700-1.200 4-1.700 7.500-1.500V5c-3.500-.2-5.800.300-7.500 1.500Z" />
    <path d="M12 6.500v13" />
  </Base>
);

/** 신분증 */
export const IconIdCard = (p: IconProps) => (
  <Base {...p}>
    <rect x="3.500" y="5.500" width="17" height="13" rx="2.200" />
    <circle cx="9" cy="11" r="1.900" />
    <path d="M6.300 15.700c.5-1.400 1.500-2 2.700-2s2.200.600 2.700 2M14.500 10h3.500M14.500 13.500h3.500" />
  </Base>
);

export const IconSoundOn = (p: IconProps) => (
  <Base {...p}>
    <path d="M4.500 9.800v4.400h3l4 3.300v-11l-4 3.300Z" />
    <path d="M15 9.300a3.800 3.800 0 0 1 0 5.400M17.300 7a7 7 0 0 1 0 10" />
  </Base>
);

export const IconSoundOff = (p: IconProps) => (
  <Base {...p}>
    <path d="M4.500 9.800v4.400h3l4 3.300v-11l-4 3.300Z" />
    <path d="m15.500 9.800 4.400 4.400M19.900 9.800l-4.400 4.400" />
  </Base>
);

export const IconInfo = (p: IconProps) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8" />
    <path d="M12 11v5.200M12 7.800v.2" />
  </Base>
);

export const IconAlert = (p: IconProps) => (
  <Base {...p}>
    <path d="M12 4.500 3.800 18.700h16.400Z" />
    <path d="M12 10v4.200M12 16.300v.2" />
  </Base>
);

/** 승급 시험: 봉랍 봉투 */
export const IconEnvelope = (p: IconProps) => (
  <Base {...p}>
    <rect x="3.500" y="6" width="17" height="12.500" rx="1.800" />
    <path d="m4 7 8 6.300L20 7" />
    <circle cx="12" cy="14.800" r="1.700" fill="currentColor" stroke="none" />
  </Base>
);

/** 수사 크레딧 주화 */
export function CoinIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <circle cx="12" cy="12" r="10.500" fill="#8a6f3a" />
      <circle cx="12" cy="11.300" r="10" fill="#d9c28c" />
      <circle cx="12" cy="11.300" r="7.600" fill="#b59760" />
      <circle cx="12" cy="11.300" r="7.600" fill="none" stroke="#8a6f3a" strokeWidth=".8" />
      {/* 열쇠 구멍 */}
      <circle cx="12" cy="9.700" r="2.100" fill="#3d3015" />
      <path d="M10.800 10.600h2.400l.800 4.500h-4Z" fill="#3d3015" />
      <path d="M5.600 6.800a8.300 8.300 0 0 1 5-3.300" stroke="#f6ecd0" strokeWidth="1.100" fill="none" strokeLinecap="round" opacity=".8" />
    </svg>
  );
}
