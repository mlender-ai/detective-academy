import { useArt } from "../app/art";
import { Sprite } from "../art/pixel";

interface Props {
  /** sealed: 봉인됨 · opening: 뜯는 중 · locked: 응시 조건 미달 */
  state: "sealed" | "opening" | "locked";
  /** 시험지 머리에 보이는 글자 (예: F급 → D급) */
  letterTitle: string;
}

const LINE = {
  fill: "none",
  stroke: "var(--ink)",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round",
} as const;

function Tint({ d, fill, opacity = 1 }: { d: string; fill: string; opacity?: number }) {
  return (
    <g filter="url(#wash-fine)" opacity={opacity} style={{ mixBlendMode: "multiply" }} transform="translate(1.2 1)">
      <path d={d} fill={fill} />
    </g>
  );
}

/* A안: 펜과 물감으로 그린 봉투. 뒷면·젖혀진 덮개·앞주머니·닫힌 덮개를 따로 그려 겹친다. */

function InkBack() {
  return (
    <svg className="envelope__back art" width="220" height="152" viewBox="0 0 220 152" focusable="false">
      <rect x="1" y="1" width="218" height="150" fill="var(--leaf-shade)" />
      <Tint d="M1 1H219V151H1Z" fill="#8f8372" opacity={0.75} />
      <g filter="url(#rough)">
        <rect x="1" y="1" width="218" height="150" {...LINE} />
      </g>
    </svg>
  );
}

function InkLid() {
  return (
    <svg className="envelope__lid art" width="220" height="88" viewBox="0 0 220 88" focusable="false">
      <path d="M1 88L110 3L219 88Z" fill="var(--leaf-shade)" />
      <Tint d="M1 88L110 3L219 88Z" fill="#a89a82" opacity={0.7} />
      <g filter="url(#rough)">
        <path d="M1 88L110 3L219 88" {...LINE} />
        <path d="M22 86L110 18L198 86" {...LINE} strokeWidth={0.8} opacity={0.5} />
      </g>
    </svg>
  );
}

function InkFront() {
  const pocket = "M1 2L110 82L219 2V151H1Z";
  return (
    <svg className="envelope__front art" width="220" height="152" viewBox="0 0 220 152" focusable="false">
      <path d={pocket} fill="var(--leaf)" />
      <Tint d={pocket} fill="#b7aa93" opacity={0.7} />
      <Tint d="M1 151L88 68L110 82L132 68L219 151Z" fill="#8f8372" opacity={0.4} />
      <g filter="url(#rough)">
        <path d={pocket} {...LINE} />
        <path d="M1 151L90 66M219 151L130 66" {...LINE} strokeWidth={1} opacity={0.6} />
        <path d="M150 118l44 20M158 110l38 17M168 104l28 12" {...LINE} strokeWidth={0.7} opacity={0.35} />
      </g>
    </svg>
  );
}

function InkFlap() {
  const flap = "M1 1H219L118 93Q110 99 102 93Z";
  return (
    <svg className="envelope__flap art" width="220" height="124" viewBox="0 0 220 124" focusable="false">
      <g className="envelope__flap-paper">
        <path d={flap} fill="var(--leaf)" />
        <Tint d={flap} fill="#c2b59c" opacity={0.6} />
        <g filter="url(#rough)">
          <path d={flap} {...LINE} />
          <path d="M20 8H200L112 82Q110 84 108 82Z" {...LINE} strokeWidth={0.8} opacity={0.45} />
        </g>
      </g>
      <g className="envelope__seal">
        <path
          d="M110 71c7-1 11 3 16 6 5 3 8 7 8 13 1 6 0 11-4 16-4 5-9 8-16 8-6 1-12 1-17-3-5-3-9-8-10-14-1-6 0-12 4-17 4-5 12-9 19-9Z"
          fill="var(--leaf)"
        />
        <Tint
          d="M110 71c7-1 11 3 16 6 5 3 8 7 8 13 1 6 0 11-4 16-4 5-9 8-16 8-6 1-12 1-17-3-5-3-9-8-10-14-1-6 0-12 4-17 4-5 12-9 19-9Z"
          fill="#8e3a42"
        />
        <g filter="url(#rough)">
          <path
            d="M110 71c7-1 11 3 16 6 5 3 8 7 8 13 1 6 0 11-4 16-4 5-9 8-16 8-6 1-12 1-17-3-5-3-9-8-10-14-1-6 0-12 4-17 4-5 12-9 19-9Z"
            {...LINE}
            strokeWidth={1.3}
          />
          <circle cx="110" cy="93" r="14.500" {...LINE} strokeWidth={0.9} opacity={0.7} />
        </g>
        <circle cx="110" cy="89.500" r="4.200" fill="var(--ink)" opacity=".85" />
        <path d="M107.800 91.500H112.200L114 102H106Z" fill="var(--ink)" opacity=".85" />
        <path d="M97 84c2-4 5-6 9-7" {...LINE} stroke="var(--leaf)" strokeWidth={1.6} opacity={0.75} />
      </g>
    </svg>
  );
}

/** 학원 인장으로 봉한 시험 봉투. 열면 봉랍이 떨어지고 덮개가 젖혀지며 시험지가 올라온다. */
export function ExamEnvelope({ state, letterTitle }: Props) {
  const pixel = useArt() === "pixel";

  return (
    <div className="envelope" data-state={state} aria-hidden="true">
      {pixel ? <Sprite name="env-lid" untrimmed className="envelope__lid" /> : <InkLid />}
      {pixel ? <Sprite name="env-back" untrimmed className="envelope__back" /> : <InkBack />}

      <div className="envelope__letter leaf">
        <span className="envelope__letter-title">승급 시험</span>
        <span className="envelope__letter-rank">{letterTitle}</span>
        <i />
        <i />
      </div>

      {pixel ? <Sprite name="env-front" untrimmed className="envelope__front" /> : <InkFront />}
      {pixel ? <Sprite name="env-flap" untrimmed className="envelope__flap" /> : <InkFlap />}
    </div>
  );
}
