import { useId } from "react";
import { RANK_BY_ID } from "../data/ranks";
import type { RankId } from "../engine/types";

interface Material {
  light: string;
  mid: string;
  dark: string;
  face: string;
  faceDeep: string;
  letter: string;
}

/** 등급마다 실루엣과 재질이 다르다. 같은 아이콘의 색만 바꾸지 않는다. */
const MATERIALS: Record<RankId, Material> = {
  F: { light: "#b4bbc6", mid: "#666d79", dark: "#2a2e36", face: "#454b55", faceDeep: "#2e333b", letter: "#dfe4eb" },
  D: { light: "#e9b98a", mid: "#b6763f", dark: "#6a3d1d", face: "#96592b", faceDeep: "#6f3f1c", letter: "#fbe6cf" },
  C: { light: "#d2dbe6", mid: "#8695a8", dark: "#404d5b", face: "#5f6f81", faceDeep: "#44505e", letter: "#f1f5f9" },
  B: { light: "#fbfcfd", mid: "#c3cad2", dark: "#7a838e", face: "#dfe4ea", faceDeep: "#b4bcc6", letter: "#2c3440" },
  A: { light: "#fbeab0", mid: "#d6ad4c", dark: "#8a681c", face: "#c2982f", faceDeep: "#9a7620", letter: "#fff8e1" },
  S: { light: "#ecd79c", mid: "#b59760", dark: "#6e5a2e", face: "#191c24", faceDeep: "#0c0e13", letter: "#ecd79c" },
};

function starPath(cx: number, cy: number, outer: number, inner: number, points: number): string {
  const step = Math.PI / points;
  let d = "";
  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 === 0 ? outer : inner;
    const a = i * step - Math.PI / 2;
    d += `${i === 0 ? "M" : "L"}${(cx + r * Math.cos(a)).toFixed(2)} ${(cy + r * Math.sin(a)).toFixed(2)}`;
  }
  return `${d}Z`;
}

/** viewBox 0 0 96 96 기준 실루엣 */
export const SHAPES: Record<RankId, string> = {
  // F: 둥근 무쇠 표
  F: "M48 9a39 39 0 1 0 0 78a39 39 0 1 0 0-78Z",
  // D: 방패
  D: "M13 12h70v35c0 23-15 34-35 42C28 81 13 70 13 47Z",
  // C: 육각 강철
  C: "M48 5l37 21.500v43L48 91 11 69.500v-43Z",
  // B: 어깨가 솟은 방패
  B: "M48 5l13 9h23v33c0 23-15 35-36 43C27 82 12 70 12 47V14h23Z",
  // A: 여덟 갈래 별
  A: starPath(48, 48, 44, 33, 8),
  // S: 왕관을 쓴 문장
  S: "M17 31l11-17 10 11 10-18 10 18 10-11 11 17v25c0 19-13 29-31 35C30 85 17 75 17 56Z",
};

interface Props {
  rank: RankId;
  size?: number;
  /** 아직 얻지 못한 등급: 윤곽만 보여 준다 */
  locked?: boolean;
  className?: string;
  /** 스크린리더용 이름을 붙일지 */
  labelled?: boolean;
}

export function DetectiveBadge({ rank, size = 64, locked = false, className, labelled = false }: Props) {
  const uid = useId().replace(/:/g, "");
  const m = MATERIALS[rank];
  const shape = SHAPES[rank];
  const rim = `bd-rim-${uid}`;
  const face = `bd-face-${uid}`;
  const sheen = `bd-sheen-${uid}`;
  const clip = `bd-clip-${uid}`;
  const label = `${rank}급 ${RANK_BY_ID[rank].title} 배지`;

  if (locked) {
    return (
      <svg
        className={className}
        width={size}
        height={size}
        viewBox="0 0 96 96"
        role={labelled ? "img" : undefined}
        aria-label={labelled ? `${label} (미획득)` : undefined}
        aria-hidden={labelled ? undefined : true}
        focusable="false"
      >
        <path d={shape} fill="rgba(51,68,91,.35)" stroke="#4a5c75" strokeWidth="1.600" strokeDasharray="3.500 3.500" strokeLinejoin="round" />
        <text
          x="48"
          y={rank === "S" ? 63 : 59}
          textAnchor="middle"
          fontFamily="Cinzel, serif"
          fontWeight="700"
          fontSize="30"
          fill="#8090a8"
        >
          {rank}
        </text>
      </svg>
    );
  }

  const letterY = rank === "S" ? 66 : rank === "D" || rank === "B" ? 58 : 59.500;

  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 96 96"
      role={labelled ? "img" : undefined}
      aria-label={labelled ? label : undefined}
      aria-hidden={labelled ? undefined : true}
      focusable="false"
    >
      <defs>
        <linearGradient id={rim} x1="14" y1="6" x2="82" y2="92" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor={m.light} />
          <stop offset=".45" stopColor={m.mid} />
          <stop offset=".8" stopColor={m.dark} />
          <stop offset="1" stopColor={m.mid} />
        </linearGradient>
        <linearGradient id={face} x1="24" y1="14" x2="72" y2="86" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor={m.face} />
          <stop offset="1" stopColor={m.faceDeep} />
        </linearGradient>
        <linearGradient id={sheen} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity={rank === "F" ? 0.16 : 0.42} />
          <stop offset=".5" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <clipPath id={clip}>
          <path d={shape} />
        </clipPath>
      </defs>

      {/* 바닥 그림자 */}
      <path d={shape} fill="#000" opacity=".35" transform="translate(0 2.500)" />
      {/* 테 */}
      <path d={shape} fill={`url(#${rim})`} />
      {/* 안쪽 면 */}
      <path d={shape} fill={`url(#${face})`} transform="translate(48 48) scale(.82) translate(-48 -48)" />
      <path
        d={shape}
        fill="none"
        stroke={m.dark}
        strokeOpacity=".7"
        strokeWidth="1.200"
        transform="translate(48 48) scale(.82) translate(-48 -48)"
      />

      {/* 등급별 세부 */}
      {rank === "F" && (
        <g fill={m.dark}>
          {[45, 135, 225, 315].map((deg) => (
            <circle key={deg} cx="48" cy="12.800" r="1.900" transform={`rotate(${deg} 48 48)`} />
          ))}
          <circle cx="48" cy="48" r="24" fill="none" stroke={m.dark} strokeWidth="1" opacity=".8" />
          <circle cx="48" cy="48" r="25.200" fill="none" stroke={m.light} strokeWidth=".7" opacity=".45" />
        </g>
      )}
      {rank === "D" && (
        <g fill="none" stroke={m.light} strokeLinecap="round" strokeLinejoin="round">
          <path d="M35 68.500 48 75l13-6.500" strokeWidth="2.200" opacity=".85" />
          <path d="M24.500 22.500h47" strokeWidth="1.400" opacity=".55" />
        </g>
      )}
      {rank === "C" && (
        <path d="M48 17v10M48 69v10M21 32.500l8.500 5M66.500 58.500l8.500 5M21 63.500l8.500-5M66.500 37.500l8.500-5" stroke={m.light} strokeWidth="1.600" strokeLinecap="round" opacity=".7" />
      )}
      {rank === "B" && (
        <g fill="none" stroke={m.dark} strokeLinecap="round">
          <path d="M26 67c7 5 14 8 22 11 8-3 15-6 22-11" strokeWidth="1.600" opacity=".7" />
          <path d="M28 24h40" strokeWidth="1.300" opacity=".5" />
        </g>
      )}
      {rank === "A" && <circle cx="48" cy="48" r="21.500" fill="none" stroke={m.light} strokeWidth="1.500" opacity=".8" />}
      {rank === "S" && (
        <g fill={m.light}>
          <circle cx="28" cy="14" r="2.600" />
          <circle cx="48" cy="7" r="2.900" />
          <circle cx="68" cy="14" r="2.600" />
          <path d="M26 40h44" stroke={m.mid} strokeWidth="1.400" />
        </g>
      )}

      <text
        x="48"
        y={letterY}
        textAnchor="middle"
        fontFamily="Cinzel, serif"
        fontWeight="700"
        fontSize={rank === "S" ? 30 : 32}
        fill={m.letter}
        stroke={m.faceDeep}
        strokeOpacity=".5"
        strokeWidth=".6"
        paintOrder="stroke"
      >
        {rank}
      </text>

      {/* 빛 */}
      <rect x="0" y="0" width="96" height="96" fill={`url(#${sheen})`} clipPath={`url(#${clip})`} />
    </svg>
  );
}
