import { useId, type CSSProperties } from "react";
import { useArt } from "../app/art";

interface Props {
  /** 인장 가운데 글자 (예: 추론 성공, 조사 완료, 합격) */
  label: string;
  /** 둘레 영문 */
  ring?: string;
  size?: number;
  tilt?: number;
  animate?: boolean;
  delayMs?: number;
  className?: string;
}

/** 인주로 찍은 학원 인장. 가장자리가 살짝 번지고 군데군데 덜 찍힌다. */
export function Stamp(props: Props) {
  return useArt() === "pixel" ? <PixelStamp {...props} /> : <InkStamp {...props} />;
}

/** B안: 점으로 찍은 네모 인장. 기울이지 않는다(점이 뭉개지지 않게). */
function PixelStamp({ label, size = 112, animate = false, delayMs = 0, className }: Props) {
  const chars = [...label.replace(/\s+/g, "")];
  const twoRows = chars.length === 4;
  return (
    <span
      className={["pxstamp", className].filter(Boolean).join(" ")}
      style={{ "--stamp-delay": `${delayMs}ms`, "--stamp-size": `${Math.round(size * 0.78)}px` } as CSSProperties}
      data-animate={animate}
      data-rows={twoRows ? 2 : 1}
      role="img"
      aria-label={`${label} 인장`}
    >
      {twoRows ? (
        <>
          <span aria-hidden="true">{chars.slice(0, 2).join("")}</span>
          <span aria-hidden="true">{chars.slice(2).join("")}</span>
        </>
      ) : (
        <span aria-hidden="true">{chars.join("")}</span>
      )}
    </span>
  );
}

function InkStamp({
  label,
  ring = "DETECTIVE ACADEMY",
  size = 112,
  tilt = -9,
  animate = false,
  delayMs = 0,
  className,
}: Props) {
  const uid = useId().replace(/:/g, "");
  const rough = `st-rough-${uid}`;
  const arc = `st-arc-${uid}`;
  const arcLow = `st-arc-low-${uid}`;
  const chars = [...label.replace(/\s+/g, "")];
  // 네 글자는 2×2, 그 외에는 한 줄로 찍는다.
  const twoRows = chars.length === 4;
  const style = {
    "--stamp-tilt": `${tilt}deg`,
    "--stamp-delay": `${delayMs}ms`,
  } as CSSProperties;

  return (
    <svg
      className={["stamp", className].filter(Boolean).join(" ")}
      style={style}
      data-animate={animate}
      width={size}
      height={size}
      viewBox="0 0 120 120"
      role="img"
      aria-label={`${label} 인장`}
      focusable="false"
    >
      <defs>
        <filter id={rough} x="-10%" y="-10%" width="120%" height="120%">
          <feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="7" result="noise" />
          <feDisplacementMap in="SourceGraphic" in2="noise" scale="2.200" result="displaced" />
          <feTurbulence type="fractalNoise" baseFrequency=".035 .5" numOctaves="1" seed="3" result="streak" />
          <feColorMatrix in="streak" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 -3.200 2.600" result="mask" />
          <feComposite in="displaced" in2="mask" operator="in" />
        </filter>
        <path id={arc} d="M 21 60 A 39 39 0 0 1 99 60" fill="none" />
        <path id={arcLow} d="M 17.500 60 A 42.500 42.500 0 0 0 102.500 60" fill="none" />
      </defs>
      <g filter={`url(#${rough})`} fill="none" stroke="currentColor">
        <circle cx="60" cy="60" r="54" strokeWidth="4.200" />
        <circle cx="60" cy="60" r="47.500" strokeWidth="1.300" />
        <circle cx="60" cy="60" r="31.500" strokeWidth="1.300" />
        <g fill="currentColor" stroke="none">
          <text fontFamily="Cinzel, serif" fontWeight="700" fontSize="7.600" letterSpacing="1.500" textAnchor="middle">
            <textPath href={`#${arc}`} startOffset="50%">
              {ring}
            </textPath>
          </text>
          <text fontFamily="Cinzel, serif" fontWeight="700" fontSize="6.600" letterSpacing="3" textAnchor="middle">
            <textPath href={`#${arcLow}`} startOffset="50%">
              VERIFIED
            </textPath>
          </text>
          <circle cx="16.800" cy="60" r="1.700" />
          <circle cx="103.200" cy="60" r="1.700" />
          {twoRows ? (
            <g fontFamily="'Hahmlet Variable', serif" fontWeight="800" fontSize="19" textAnchor="middle">
              <text x="60" y="56">
                {chars.slice(0, 2).join("")}
              </text>
              <text x="60" y="77">
                {chars.slice(2).join("")}
              </text>
            </g>
          ) : (
            <text
              x="60"
              y="68"
              fontFamily="'Hahmlet Variable', serif"
              fontWeight="800"
              fontSize={chars.length <= 2 ? 25 : 17}
              textAnchor="middle"
            >
              {chars.join("")}
            </text>
          )}
        </g>
      </g>
    </svg>
  );
}
