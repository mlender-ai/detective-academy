import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import "pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css";
import "@fontsource-variable/hahmlet/wght.css";
import "@fontsource/cinzel/latin-700.css";
import "@fontsource/nanum-pen-script/korean-400.css";
import "@fontsource/nanum-pen-script/latin-400.css";

import "./styles/tokens.css";
import "./styles/base.css";
import "./styles/components.css";
import "./styles/art.css";
import "./styles/hall.css";
import "./styles/desk.css";
import "./styles/rooms.css";
import "./styles/pixel.css";
import "./styles/pixel-rooms.css";

import { App } from "./app/App";
import { PUZZLES } from "./data/puzzles";
import { verifyGuidance, verifyPuzzle } from "./engine/puzzleValidator";

// 개발 중에는 문제 데이터를 고칠 때마다 정답 유일성과 힌트·해설 일관성을 바로 확인한다.
// (같은 검사를 npm test 가 자동으로 수행한다.)
if (import.meta.env.DEV) {
  for (const puzzle of PUZZLES) {
    const solved = verifyPuzzle(puzzle);
    const guidance = verifyGuidance(puzzle);
    if (!solved.ok) console.error(`[문제 검증 실패] ${puzzle.id}: 정답 ${solved.solutions.length}개`, solved);
    if (!guidance.ok) console.error(`[힌트·해설 검증 실패] ${puzzle.id}`, guidance.issues);
  }
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
