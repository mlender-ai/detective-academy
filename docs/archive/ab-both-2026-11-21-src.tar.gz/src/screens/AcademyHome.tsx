import { useState } from "react";
import { useArt } from "../app/art";
import { nextStep } from "../app/flow";
import { prefersReducedMotion } from "../app/motion";
import { navigate } from "../app/router";
import { playSound } from "../app/sound";
import { useGame } from "../app/store";
import { Ink, PenMark, Wash } from "../art/Art";
import { CoinsArt, Crest, EnvelopeArt, IdArt, KeyArt, Pushpin, RankMark } from "../art/objects";
import corridorPixel from "../assets/art/corridor-px.png";
import corridor from "../assets/art/corridor.webp";
import { Stamp } from "../components/Stamp";
import { getDailyPuzzle, PRACTICE_PUZZLES, PUZZLE_BY_ID } from "../data/puzzles";
import { RANK_BY_ID, rankLabel } from "../data/ranks";
import { examStatus, getProgress } from "../engine/progressEngine";
import { formatElapsed, seoulDateKey, seoulDateLabel } from "../engine/time";
import type { PuzzleProgress } from "../engine/types";

function postingCta(progress: PuzzleProgress): string {
  if (progress.status === "solved") return "채점 기록 보기";
  if (progress.status === "in_progress") return "이어서 풀기";
  return "시험지 펼치기";
}

function postingStatus(progress: PuzzleProgress): string {
  if (progress.status === "solved") return "해결";
  if (progress.status === "in_progress") return `풀이 중 ${formatElapsed(progress.elapsedMs)}`;
  return "미해결";
}

/**
 * 학원 복도. 벽의 게시판에 오늘의 시험 공고가 붙어 있고,
 * 공고를 누르면 그 종이가 그대로 책상 위 시험지로 펼쳐진다.
 */
export function AcademyHome() {
  const game = useGame();
  const pixel = useArt() === "pixel";
  const daily = getDailyPuzzle(seoulDateKey());
  const dailyProgress = getProgress(game, daily.id);
  const exam = examStatus(game);
  const step = nextStep(game);
  const [lifting, setLifting] = useState(false);

  const practiceSolved = PRACTICE_PUZZLES.filter((p) => getProgress(game, p.id).status === "solved").length;
  const examPuzzle = exam.rule ? PUZZLE_BY_ID[exam.rule.examPuzzleIds[0]] : null;
  const examInProgress = examPuzzle ? getProgress(game, examPuzzle.id).status === "in_progress" : false;
  const solved = dailyProgress.status === "solved";

  // 공고를 누르면 압정이 빠지며 종이가 떠오르고, 곧바로 책상 위 시험지로 이어진다.
  const openDaily = () => {
    if (lifting) return;
    if (prefersReducedMotion()) {
      navigate({ name: "daily" });
      return;
    }
    setLifting(true);
    playSound("place");
    window.setTimeout(() => navigate({ name: "daily" }), 150);
  };

  return (
    <div className="screen hall inkworld" data-testid="home-screen" data-next={step}>
      <h1 className="sr-only">탐정학원 복도</h1>

      <div className="hall__scene" aria-hidden="true">
        {pixel ? (
          <img src={corridorPixel} alt="" width={192} height={144} decoding="async" />
        ) : (
          <img src={corridor} alt="" width={1152} height={896} decoding="async" />
        )}
      </div>

      <header className="hall__top">
        <div className="hall__sign">
          <Crest size={44} />
          <p className="hall__name">
            <span>탐정학원</span>
            <span>DETECTIVE ACADEMY</span>
          </p>
        </div>
        <p className="hall__rank leaf">
          <RankMark rank={game.rank} size={30} />
          <span data-testid="home-rank">{rankLabel(game.rank)}</span>
        </p>
      </header>

      <div className="hall__gap" aria-hidden="true" />

      <section className="bulletin" aria-label="시험 게시판">
        <Wash color="#7a5140" radius={3} seed={3} />
        <span className="bulletin__cork" aria-hidden="true" />
        <Wash color="#b98d55" inset={11} radius={2} seed={7} opacity={0.4} />
        <Ink seed={21} inset={1} weight={1.5} over={5} />
        <Ink seed={22} inset={11} weight={1} over={3} opacity={0.7} />

        <button
          type="button"
          className="posting"
          data-status={dailyProgress.status}
          data-primary={step === "daily"}
          data-lifting={lifting}
          data-testid="daily-file"
          onClick={openDaily}
        >
          <Pushpin className="posting__pin" size={26} />
          <span className="posting__leaf leaf" style={{ viewTransitionName: "exam-sheet" }}>
            <span className="posting__head">
              <span className="posting__title">오늘의 추리</span>
              <span className="posting__date num">{seoulDateLabel()}</span>
            </span>
            <span className="posting__subject">
              {daily.title}
              <span className="posting__status hand" data-testid="daily-file-status">
                {postingStatus(dailyProgress)}
              </span>
            </span>

            <span className="posting__meta">
              <span>
                <i>유형</i>
                <b>{daily.typeLabel}</b>
              </span>
              <span>
                <i>난이도</i>
                <b>
                  <span className="diamonds" role="img" aria-label={`5단계 중 ${daily.difficulty}단계`}>
                    {Array.from({ length: 5 }, (_, i) => (
                      <i key={i} data-on={i < daily.difficulty} />
                    ))}
                  </span>
                </b>
              </span>
              {solved ? (
                // 해결한 공고에는 보상 칸 자리에 인장이 찍힌다
                <span className="posting__sealed">
                  <Stamp className="posting__stamp" label="해결" size={78} tilt={-13} />
                </span>
              ) : (
                <span>
                  <i>해결 보상</i>
                  <b className="num">+{daily.reward}</b>
                </span>
              )}
            </span>

            <span className={`inkbtn inkbtn--block posting__cta ${step === "daily" ? "inkbtn--wine" : ""}`} data-testid="daily-file-cta">
              {postingCta(dailyProgress)}
            </span>
          </span>
        </button>

        {exam.rule ? (
          <div className="promoslip" data-state={exam.unlocked ? "ready" : "locked"} data-testid="promo">
            <span className="promoslip__env">
              <EnvelopeArt size={96} />
              <Pushpin className="promoslip__pin" size={18} tone="#c39a52" />
            </span>
            <div className="promoslip__tag leaf">
              <h2 className="promoslip__title">{exam.rule.to}급 승급 시험</h2>
              <p className="sr-only">
                응시 조건 <span data-testid="promo-count">{`${exam.doneCount}/${exam.requirements.length}`}</span> 완료
              </p>
              {exam.unlocked ? (
                <button
                  type="button"
                  className={`inkbtn inkbtn--sm inkbtn--block ${step === "exam" ? "inkbtn--wine" : ""}`}
                  onClick={() => navigate({ name: "exam" })}
                  data-testid="exam-cta"
                >
                  {examInProgress ? "시험 이어서 풀기" : "승급 시험 응시"}
                </button>
              ) : (
                <ul className="promoslip__reqs">
                  {exam.requirements.map((req, i) => (
                    <li key={req.label} data-done={req.done}>
                      <span className="tickbox">{req.done && <PenMark kind="check" seed={5 + i} weight={2} />}</span>
                      {req.label}
                      <span className="sr-only">{req.done ? " 완료" : " 미완료"}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        ) : (
          <div className="promoslip" data-state="passed" data-testid="promo">
            <span className="promoslip__env">
              <EnvelopeArt size={96} open />
            </span>
            <div className="promoslip__tag leaf">
              <h2 className="promoslip__title">{game.rank}급 승급 시험 합격</h2>
              <p className="promoslip__note">{RANK_BY_ID[game.rank].title}이 되었습니다.</p>
              <button
                type="button"
                className="inkbtn inkbtn--sm inkbtn--block"
                onClick={() => navigate({ name: "exam" })}
                data-testid="exam-record"
              >
                합격 기록 보기
              </button>
            </div>
          </div>
        )}
      </section>

      <nav className="ledge" aria-label="학원 안의 물건">
        <span className="ledge__shelf" aria-hidden="true">
          <Wash color="#7a5140" seed={9} radius={1} />
          <Ink seed={31} weight={1.2} over={6} />
        </span>

        <button
          type="button"
          className="ledge__item"
          data-primary={step === "practice"}
          onClick={() => navigate({ name: "practice" })}
          data-testid="practice-entry"
        >
          <span className="ledge__art">
            <KeyArt size={88} />
            {step === "practice" && <PenMark kind="circle" draw delayMs={420} seed={8} className="ledge__mark" />}
          </span>
          <span className="ledge__name">연습실</span>
          <span className="ledge__sub num">
            {step === "practice" ? "다음 과제 · " : ""}해결 {practiceSolved}/{PRACTICE_PUZZLES.length}
          </span>
        </button>

        <button
          type="button"
          className="ledge__item"
          onClick={() => navigate({ name: "profile" })}
          aria-label={`${rankLabel(game.rank)} ${game.nickname}, 탐정 신분증 보기`}
          data-testid="identity"
        >
          <span className="ledge__art">
            <IdArt size={86} rank={game.rank} />
          </span>
          <span className="ledge__name">탐정 신분증</span>
          <span className="ledge__sub">{game.nickname}</span>
        </button>

        <p className="ledge__item ledge__item--coins">
          <span className="ledge__art">
            <CoinsArt size={58} />
          </span>
          <span className="ledge__name num" data-testid="credit-balance" aria-label={`보유 수사 크레딧 ${game.credits}`}>
            <span aria-hidden="true">{game.credits.toLocaleString("ko-KR")}</span>
          </span>
          <span className="ledge__sub">수사 크레딧</span>
        </p>
      </nav>
    </div>
  );
}
