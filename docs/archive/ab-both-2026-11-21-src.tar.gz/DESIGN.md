---
name: 탐정학원 · DETECTIVE ACADEMY
description: 밤의 책상 위에 학원의 물건을 올려놓고 만지는 모바일 추론 게임
colors:
  navy-950: "#0a0f18"
  navy-900: "#111825"
  navy-800: "#1b2635"
  navy-700: "#263447"
  navy-600: "#33445b"
  navy-500: "#4a5c75"
  brass-200: "#ecdcb4"
  brass-300: "#dbc590"
  brass-400: "#c8ad75"
  brass-500: "#b59760"
  brass-600: "#94793f"
  brass-700: "#6e5a2e"
  brass-ink: "#1b1608"
  brass-on-paper: "#75602f"
  ivory-50: "#faf7ee"
  ivory-100: "#f3eee1"
  ivory-200: "#e8e0cb"
  ivory-300: "#d6cbae"
  ink-900: "#1a2030"
  ink-700: "#383d4a"
  ink-500: "#5c5645"
  oxblood-500: "#713b43"
  oxblood-300: "#b8636e"
  oxblood-200: "#dba0a8"
  stamp-ink: "#9a3540"
  verdigris-400: "#77ad96"
  verdigris-600: "#3a715e"
  grey-300: "#b3bac6"
  grey-400: "#9099a7"
  person-brass: "#87692F"
  person-wax: "#8A3F4B"
  person-verdigris: "#3A715E"
  person-steel: "#4F6486"
typography:
  display:
    fontFamily: "'Hahmlet Variable', 'Nanum Myeongjo', AppleMyungjo, 'Noto Serif KR', serif"
    fontSize: "30px"
    fontWeight: 800
    lineHeight: 1.15
    letterSpacing: "-0.03em"
  headline:
    fontFamily: "'Hahmlet Variable', 'Nanum Myeongjo', AppleMyungjo, 'Noto Serif KR', serif"
    fontSize: "25px"
    fontWeight: 800
    lineHeight: 1.25
    letterSpacing: "-0.03em"
  title:
    fontFamily: "'Hahmlet Variable', 'Nanum Myeongjo', AppleMyungjo, 'Noto Serif KR', serif"
    fontSize: "19px"
    fontWeight: 800
    lineHeight: 1.25
    letterSpacing: "0.02em"
  numeral:
    fontFamily: "'Hahmlet Variable', 'Nanum Myeongjo', AppleMyungjo, 'Noto Serif KR', serif"
    fontSize: "38px"
    fontWeight: 800
    lineHeight: 1
  ui-title:
    fontFamily: "'Pretendard Variable', Pretendard, -apple-system, BlinkMacSystemFont, 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', system-ui, sans-serif"
    fontSize: "16px"
    fontWeight: 700
    lineHeight: 1.25
    letterSpacing: "-0.01em"
  body:
    fontFamily: "'Pretendard Variable', Pretendard, -apple-system, BlinkMacSystemFont, 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', system-ui, sans-serif"
    fontSize: "15px"
    fontWeight: 400
    lineHeight: 1.55
    letterSpacing: "-0.01em"
  label:
    fontFamily: "'Pretendard Variable', Pretendard, -apple-system, BlinkMacSystemFont, 'Apple SD Gothic Neo', 'Noto Sans KR', 'Malgun Gothic', system-ui, sans-serif"
    fontSize: "12.5px"
    fontWeight: 700
    lineHeight: 1.3
    letterSpacing: "-0.01em"
  engraved:
    fontFamily: "Cinzel, 'Hahmlet Variable', 'Times New Roman', serif"
    fontSize: "8.5px"
    fontWeight: 700
    letterSpacing: "0.2em"
rounded:
  paper: "5px"
  s: "8px"
  m: "12px"
  l: "18px"
  sheet: "22px"
spacing:
  gutter: "20px"
  stack: "12px"
  section: "26px"
components:
  button-primary:
    backgroundColor: "{colors.brass-500}"
    textColor: "{colors.brass-ink}"
    typography: "{typography.ui-title}"
    rounded: "{rounded.m}"
    padding: "0 20px"
    height: "52px"
  button-primary-active:
    backgroundColor: "#a0844b"
    textColor: "{colors.brass-ink}"
  button-quiet:
    backgroundColor: "{colors.navy-800}"
    textColor: "{colors.ivory-100}"
    rounded: "{rounded.m}"
    padding: "0 20px"
    height: "52px"
  button-quiet-active:
    backgroundColor: "{colors.navy-700}"
  button-outline:
    textColor: "{colors.brass-300}"
    rounded: "{rounded.m}"
    padding: "0 20px"
    height: "52px"
  button-paper:
    backgroundColor: "{colors.ink-900}"
    textColor: "{colors.ivory-100}"
    rounded: "{rounded.m}"
    padding: "0 20px"
    height: "52px"
  button-paper-quiet:
    textColor: "{colors.ink-900}"
    rounded: "{rounded.m}"
    padding: "0 20px"
    height: "52px"
  button-sm:
    rounded: "10px"
    padding: "0 14px"
    height: "44px"
  paper:
    backgroundColor: "{colors.ivory-100}"
    textColor: "{colors.ink-900}"
    rounded: "{rounded.paper}"
  credit-chip:
    backgroundColor: "rgba(10, 15, 24, 0.55)"
    textColor: "{colors.brass-200}"
    rounded: "16px"
    padding: "0 11px 0 7px"
    height: "32px"
  memo-chip:
    backgroundColor: "{colors.navy-800}"
    textColor: "{colors.ivory-100}"
    rounded: "9px"
    height: "44px"
  memo-chip-maybe:
    backgroundColor: "{colors.brass-500}"
    textColor: "{colors.brass-ink}"
  nameplate:
    backgroundColor: "{colors.navy-800}"
    textColor: "{colors.brass-200}"
    rounded: "{rounded.paper}"
    padding: "10px 12px"
    height: "68px"
  nameplate-primary:
    backgroundColor: "{colors.brass-500}"
    textColor: "{colors.brass-ink}"
---

> **전 화면이 V2 다 (2026-11-21).** 입학부터 신분증까지 모든 화면이 아래 "V2 · Illustrated Mystery Academy"를 따르고,
> 같은 화면을 A안(펜과 수채)과 B안(픽셀 아트) 두 화풍으로 그린다. 어느 안으로 갈지는 사용자 확인을 기다리는 중이다.
> 위 머리말의 토큰(밤의 책상)과 문서 뒤쪽의 "Design System" 절은 **V1 의 기록**이며 코드에는 남아 있지 않다(`docs/v1/`).
> 안이 정해지면 이 문서와 `.impeccable/design.json` 을 고른 안 하나로 다시 쓴다.

# V2 · Illustrated Mystery Academy

스케치북 종이 위에 펜으로 긋고 물감을 덜 채운 그림. 기준 그림은 `src/assets/art/corridor.webp`(학원 복도)이고, 모든 물건이 그 화풍을 따른다.

## 색 (src/styles/tokens.css 의 V2 블록)

| 토큰 | 값 | 쓰임 |
|---|---|---|
| `--paper` | `#e8dec6` | 스케치북 종이. 복도 그림의 여백색과 같다 |
| `--leaf` | `#f6f0e0` | 문서 종이: 공고, 시험지, 쪽지, 단추 |
| `--ink` / `--ink-soft` / `--ink-faint` | `#2a221e` / `#55483e` / `#74665a` | 펜선과 글자. 문서 종이 위 대비 13.7 / 7.8 / 4.9 |
| `--wine` / `--wine-deep` | `#7d2c36` / `#5c1e27` | 주 행동 단추, 판정. 화면에 하나만 |
| `--pen` | `#a3323c` | 빨간 펜: 동그라미, 체크, 날짜 도장, 교관의 메모 |
| 물감 | 나무 `#7a5140` · 황동 `#b48d47` · 강철 `#8f979b` · 봉랍 `#8e3a42` | 물건에 얹는 수채. 항상 multiply |

검은 바탕과 금색 테두리는 쓰지 않는다. 강조색은 와인레드 하나다.

## 글자

- 인쇄된 글(공고, 시험지, 단추): Hahmlet. 제목 800, 본문 500~600.
- 손으로 적은 글(메모, 채점 값, 교관의 지적): Nanum Pen Script. 20px 이상으로만 쓴다.
- 작은 기능 라벨(유형, 난이도, 풀이 시간): Pretendard 12.5px 이상.
- 영문 각인: Cinzel. 엠블럼과 등급 글자에만.

## 재료 (src/art)

- **펜선** `sketch.ts`: 끝에서 살짝 더 나가고, 가운데가 휘고, 두 번 겹쳐 긋는다. seed 가 같으면 같은 선이다.
- **물감** `Art.tsx` 의 `#wash` · `#wash-fine`: 가장자리가 울고 안쪽이 얼룩지며 테두리에 물감이 고인다. 선과 1~2px 어긋나게 얹는다.
- **종이 오림**: 책상 위 물건(자물쇠 등)은 밝은 종이 바탕을 깔아 오려 붙인 것처럼 흰 테두리를 갖는다.
- **빨간 펜** `PenMark`: 동그라미(다음 행동, 후보), 체크(조건 충족), 가위표(제외, 연필색), 밑줄.
- **잉크 단추** `.inkbtn`: 바탕만 `#rough` 필터로 흔들리고 글자는 반듯하다. 44px 이상.

## 규칙

1. 화면은 배경 그림 → 물건 → 조작부 → 반응의 네 층이다. 둥근 카드를 쌓아 화면을 만들지 않는다.
2. 정보는 기록물(공고, 시험지, 꼬리표, 쪽지)에 담는다. 앱 부품(알약 칩, 꺾쇠 행, 탭 막대)으로 담지 않는다.
3. 조작부는 그림 한 장이 아니다. 숫자 드럼처럼 손을 따라 움직이는 부분은 따로 구현한다.
4. 엔진에 따라 달라지는 표현(CSS 3D 등)에 조작부를 맡기지 않는다. 숫자 드럼은 원통 투영을 직접 계산한다.
5. 장면 전환은 누른 물건이 이어지게 한다: 공고 → 시험지(`exam-sheet`), 자물쇠(`code-lock`).
6. 높이 740px 이하(주소창이 보이는 모바일 브라우저)에서는 조여진 배치를 쓴다. 시험지·자물쇠·제출 단추가 한 화면에 들어와야 한다.
7. 알림은 조작부를 가리지 않는다. 오답 쪽지는 시험지 머리 위에, 경고 문구는 `pointer-events: none`.

8. 부모에 `filter` 를 걸고 그 밖으로 자식을 움직이지 않는다(사파리 엔진에서 잘린다). 그림자는 따로 깔고, 겹치는 층에는 `z-index` 를 적는다.

## 공간과 화면

공간은 세 곳뿐이다. 화면마다 새 배경을 만들지 않고, 같은 공간에 놓인 물건이 달라진다.

| 공간 | 배경 | 화면 | 놓인 물건 |
|---|---|---|---|
| 학원 복도 | `corridor.webp` | 홈, 입학 | 게시판과 공고, 선반의 열쇠·신분증·주화 / 입학 원서와 신분증 |
| 추리 책상 | `desk.webp` | 연습실, 세 유형의 풀이와 채점 결과, 탐정 신분증 | 과제지 묶음 / 시험지와 자물쇠·진술서·시간표 / 신분증과 학생 기록부 |
| 시험실 | `examroom.webp` + 책상 | 승급 시험의 봉투, 응시 전, 승급 증서, 합격 기록 | 봉랍으로 봉한 봉투, 응시 안내, 증서와 새 신분증 |

승급 시험을 푸는 동안에는 시험실 책상에 녹색 깔개(`.desk__blotter`)가 깔려 평소의 책상과 구분된다.

## 화면별 부품 (src/styles/rooms.css, B안은 pixel-rooms.css)

- **탐정 신분증** `.idcard`: 펜으로 테를 그은 종이 카드. 머리 아래 와인색 물감 띠, 학원 모자를 쓴 견습 탐정 사진, 손글씨 이름, 등급 휘장. 인장은 오른쪽 아래 모서리에 찍힌다.
- **학생 초상** `Portrait`: 증명사진. 사람마다 머리 모양(9가지)과 교복 색(5가지)이 달라 색 없이도 구분된다. 이름은 항상 곁에 글자로 둔다.
- **진술서** `.statement`: 사진, 이름, 진술. 참은 빨간 펜 동그라미, 거짓은 모서리의 작은 가위표(글자를 가리지 않는다). 메모 단추는 46×46.
- **대사 쪽지** `.truth__prompt`: A안은 종이 쪽지, B안은 어두운 대사 창.
- **시간표와 이름표** `.board__slots` · `.pcard`: 이름표를 끌거나, 누른 뒤 시간을 눌러 놓는다. 대기석은 어두운 나무 쟁반.
- **시험 봉투** `.envelope`: 안쪽·젖혀진 덮개·시험지·앞주머니·닫힌 덮개 다섯 층. 봉랍이 떨어지고 덮개가 넘어가고 시험지가 올라온다.
- **승급 증서** `.diploma`: 두 줄 펜 테, 옛 휘장이 물러난 자리에 새 휘장이 찍히고 동그라미가 쳐진다.
- **학생 기록부** `.ledger`: 등급표(현재 등급에 동그라미, 미획득은 흐리게)와 수사 기록(해결하면 체크, 기록은 손글씨).
- **작은 단추** `.minibtn`: 종이 딱지. 44px 이상.

## B안 · 픽셀 아트 (src/styles/pixel.css · pixel-rooms.css, src/art/pixel.tsx)

같은 DOM 을 `:root[data-art="pixel"]` 로 덮어쓴다. 점 하나는 2px 이고 스프라이트는 scale 2 로만 쓴다. 둥근 모서리·흐림·기울임·부드러운 그림자를 쓰지 않고, 움직임은 `steps()` 로 끊는다. 글꼴은 갈무리 14(본문 15px)와 갈무리 11(라벨 12px, 제목·단추 24px). 창틀은 모서리 한 점이 빠진 2px 테두리(`--px-frame`)와 안쪽 음영(`--px-bevel-paper`), 단추는 아래쪽 4px 두께가 눌리며 사라진다. 홈·입학·시험실은 위 화면(장면)과 아래 화면(조작)이 띠로 나뉘는 두 화면 구성이다.

## 확인하지 못한 것

실제 휴대폰 기기. 크롬 엔진과 사파리 엔진(WebKit) 에뮬레이션에서만 확인했다.


# (V1 기록) Design System: 탐정학원 · DETECTIVE ACADEMY

> 아래는 V1(남색·금색 카드)의 기록이다. 이 화면들은 코드에 남아 있지 않다. 캡처와 빌드본은 `docs/v1/`.

> 이 문서는 완성된 빌드(`src/styles/*.css`, `src/components/*.tsx`, `docs/screenshots/*.png`)에서 읽어 낸 값만 적는다. 계획이나 의도가 아니라 실제로 배포된 결과가 기준이다. 값의 원본은 `src/styles/tokens.css` 이고, 위 프런트매터가 그 사본이다.

## Overview

**Creative North Star: "밤의 책상 (The Desk at Night)"**

화면은 불 꺼진 학원의 책상이다. 왼쪽 위에서 램프 하나가 따뜻하게 번지고, 그 위에 수사 파일, 황동 자물쇠, 봉랍 찍힌 봉투, 신분증, 문패 같은 학원의 물건이 놓인다. 사용자는 양식을 채우는 것이 아니라 물건을 만진다. 다이얼을 굴리고, 진술 카드에 핀을 꽂고, 발표 카드를 자리에 끼우고, 봉투의 봉인을 뜯는다.

재질은 넷뿐이다. 바탕은 미드나이트 네이비, 읽을거리는 아이보리 종이, 귀한 것은 앤티크 황동, 판정과 봉인은 옥스블러드 인주다. 녹청은 "참"과 "해결"을 말할 때만 나온다. 어두운 바탕 위의 일반 조작부는 평평하고 조용하며, 질감과 금속 광택은 물건에만 준다. 그래서 화면에서 가장 무거워 보이는 것이 항상 지금 만질 물건이다.

교육용 퀴즈 앱이나 밝은 캐주얼 퍼즐 게임처럼 보이면 안 된다(PRODUCT.md 의 약속). 홈에 히어로 배너가 없고, 가장 먼저 보이는 것은 오늘의 수사 파일이며, 가장 강한 버튼은 언제나 다음 행동 하나다.

**Key Characteristics:**
- 어두운 바탕 한 겹 위에 종이 물건이 올라가는 2층 구조 (바탕 `navy-900`, 종이 `ivory-100`)
- 금속 그라디언트는 물건(엠블럼, 자물쇠 몸체, 등급 배지, 핀, 나사)에만, 버튼과 칩은 단색
- 한국어 UI 는 Pretendard, 제목·숫자·인장은 Hahmlet, 새긴 라틴 문자는 Cinzel
- 사람은 색만으로 구분하지 않는다: 재질색 4종 + 고유 실루엣 + 이름 첫 글자
- 모든 그래픽은 직접 만든 SVG·CSS. 래스터 이미지, 이모지, 아이콘 폰트가 없다
- 모션은 물건의 물리 반응(굴림, 꽂힘, 찍힘, 덮개 넘김, 배지 교체)이고 건너뛸 수 있다
- 최대 폭 480px 의 한 손 모바일 화면, 터치 대상 최소 44px

## Colors

밤의 네이비 바탕에 아이보리 종이가 놓이고, 황동이 "지금 할 일"과 "귀한 것"을 가리키는 팔레트다.

### Primary
- **앤티크 황동** (`brass-500`): 어두운 바탕 위의 주 버튼, 켜진 스위치, 메모 칩의 "후보" 상태, 다음 행동이 된 문패, 신분증 머리띠 아래 선. 글자는 항상 `brass-ink`.
- **밝은 황동** (`brass-200`, `brass-300`, `brass-400`): 어두운 바탕 위의 강조 글자와 테두리. 크레딧 숫자·승급 제목·시간표 숫자는 `brass-200`, 윤곽 버튼 글자·진행 중 상태·포커스 링·선택 테두리는 `brass-300`, 선택된 용의자 테두리·홈 워드마크 영문은 `brass-400`.
- **깊은 황동** (`brass-600`, `brass-700`): 눌린 주 버튼(`#a0844b`, 글자 대비를 지키려고 `brass-600` 보다 한 단계 밝게 둔다), 버튼 아래 모서리 선과 문패 테두리(`brass-700`).
- **황동 잉크** (`brass-ink`): 황동 면 위의 글자와 자물쇠 위 화살표.
- **종이 위 황동** (`brass-on-paper`): 종이 위에서 황동 느낌이 필요한 작은 글자(신분증 하단 각인, 힌트 표시). `brass-500` 은 종이 위에서 읽히지 않아 따로 둔 값이다.

### Secondary
- **옥스블러드** (`oxblood-500`, `oxblood-300`, `oxblood-200`): 봉랍, 오답 알림줄의 바탕과 테두리, 승급 시험 중 상단 바의 붉은 기운, 지목된 범인 카드. `oxblood-200` 은 어두운 바탕 위의 경고 글자(중복 숫자, 크레딧 부족)다.
- **인주** (`stamp-ink`): 인장, 판정 도장 "참", 종이 위 숫자를 지우는 사선, 입력 커서. 종이 위에서만 쓰고 `mix-blend-mode: multiply` 로 종이에 스민다.

### Tertiary
- **녹청** (`verdigris-600`, `verdigris-400`): "참"과 "해결"의 색. 종이 위에서는 `verdigris-600`(참 메모 버튼, 해설의 참 표시, 힌트 미사용 표시), 어두운 바탕에서는 `verdigris-400`(수사 파일의 해결 상태).
- **인물 재질색** (`person-brass`, `person-wax`, `person-verdigris`, `person-steel`): 인물 표식 전용. 글자는 흰색이며 다른 용도로 쓰지 않는다.

### Neutral
- **미드나이트 네이비** (`navy-900`): 앱 바탕. `navy-950` 은 앱 바깥(520px 이상에서 보이는 여백)과 반투명 홈.
- **딥 네이비** (`navy-800`, `navy-700`): 어두운 바탕 위의 조용한 면(조용한 버튼, 메모 칩, 용의자 카드, 바닥 시트, 문패). `navy-700` 은 그 면이 눌리거나 선택된 상태.
- **네이비 선** (`navy-600`, `navy-500`): 조용한 면의 1px 안쪽 테두리(`navy-600`), 빈 자리·슬롯·입력 테두리(`navy-500`).
- **아이보리 종이** (`ivory-100`): 종이의 기본 면이자 어두운 바탕 위의 본문 글자색. `ivory-50` 은 다이얼 숫자와 증명사진 테두리, `ivory-200` 은 파일 탭, `ivory-300` 은 뒤에 겹친 서류와 "언급된 인물" 테두리.
- **잉크** (`ink-900`, `ink-700`, `ink-500`): 종이 위 글자 3단계. 본문과 종이 위 주 버튼은 `ink-900`, 부제와 인용은 `ink-700`, 항목 이름표는 `ink-500`.
- **회색 글자** (`grey-300`, `grey-400`): 어두운 바탕 위의 보조 글자(`grey-300`)와 가장 옅은 안내 글자(`grey-400`).
- **황동 실선**: `rgba(181, 151, 96, 0.22)` 가 어두운 바탕의 기본 구분선, `0.5` 가 윤곽 버튼 테두리다.

### 대비 (이 문서를 쓰면서 토큰 값으로 계산한 WCAG 대비)

| 글자 / 바탕 | 대비 |
|---|---|
| `ivory-100` / `navy-900` | 15.4:1 |
| `grey-300` / `navy-900` | 9.1:1 |
| `grey-400` / `navy-900` · `navy-800` | 6.2:1 · 5.3:1 |
| `brass-200` / `navy-900` | 13.1:1 |
| `ink-900` / `ivory-100` | 14.0:1 |
| `ink-700` / `ivory-100` | 9.4:1 |
| `ink-500` / `ivory-100` | 6.3:1 |
| `brass-on-paper` / `ivory-100` | 5.2:1 |
| `stamp-ink` / `ivory-100` | 6.1:1 |
| `verdigris-600` / `ivory-100` | 4.9:1 |
| `brass-ink` / `brass-500` | 6.5:1 |
| `brass-500` / `ivory-100` | 2.4:1 (글자로 쓰지 않는다) |

### Named Rules
**물건만 금속 규칙 (The Objects-Only Metal Rule).** 금속 그라디언트(`--brass-metal`, 방사형 황동 하이라이트)는 엠블럼, 자물쇠 몸체, 등급 배지, 핀, 나사, 리벳처럼 손에 잡히는 물건에만 쓴다. 버튼, 칩, 스위치는 단색 `brass-500` 이다.

**종이 위 잉크 규칙 (The Ink-on-Paper Rule).** 종이 위의 주 행동 버튼은 황동이 아니라 `ink-900` 이다. 황동은 아이보리 위에서 2.4:1 이라 버튼 면으로도 글자로도 서지 못한다. 종이 위에서 황동 기운이 필요하면 `brass-on-paper` 를 쓴다.

**녹청은 판정 규칙 (The Verdigris-Means-True Rule).** 녹청은 참·해결·깨끗한 기록을 말할 때만 나온다. 장식이나 일반 강조에 쓰지 않는다. 인물 표식의 녹청 재질색은 별개의 인물 전용 값이다.

**인주는 종이에만 규칙 (The Wax-and-Ink Rule).** `stamp-ink` 는 종이 위에 찍히는 것에만 쓴다. 어두운 바탕에서 붉은 기운이 필요하면 `oxblood-200`(글자)과 `oxblood-300`(선)을 쓴다.

## Typography

**Display Font:** Hahmlet Variable (대체: Nanum Myeongjo, AppleMyungjo, Noto Serif KR)
**Body Font:** Pretendard Variable (대체: Apple SD Gothic Neo, Noto Sans KR, Malgun Gothic)
**Label/Mono Font:** Cinzel 700, 라틴 전용 (대체: Hahmlet Variable, Times New Roman)

**Character:** 읽고 조작하는 글자는 전부 Pretendard 로 또렷하게 두고, 학원의 격식은 한글 명조인 Hahmlet 이 제목·숫자·인장에서만 맡는다. Cinzel 은 금속과 인주에 새겨진 라틴 문자 전용이라 글이 아니라 물건의 일부로 읽힌다.

세 글꼴 모두 패키지로 들여와 번들에 포함한다(`pretendard`, `@fontsource-variable/hahmlet`, `@fontsource/cinzel` 의 latin-700). 외부 글꼴 요청이 없다.

### Hierarchy
- **Display** (Hahmlet 800, 30–34px, 행간 1.1–1.2, 자간 -0.03em): 화면당 하나뿐인 물건의 이름. 수사 파일의 "오늘의 추리"(30px), 승급 제목(32px), 입학 화면 워드마크(34px, 자간 0.02em), 보상 금액(34px).
- **Headline** (Hahmlet 800, 25px, 행간 1.25, 자간 -0.03em): 결과 보고서의 사건 제목.
- **Title** (Hahmlet 800, 17–19px, 행간 1.25): 물건에 새겨진 이름. 문패 "연습실"(19px, 자간 0.02em), 신분증 이름(19px), 홈 워드마크(18px), 시간표 시각(19px), 판정 도장(17px).
- **Numeral** (Hahmlet 800, 28–38px, 행간 1): 다이얼 숫자(38px), 정답 숫자판(28px). 숫자에는 `tabular-nums` 를 건다.
- **UI Title** (Pretendard 700–800, 16–19px, 행간 1.25): 화면 이름(16px/700), 버튼(16px/700), 등급 이름·시트 제목(19px/800), 구역 제목(15–17px/700–800).
- **Body** (Pretendard 400–600, 14–15.5px, 행간 1.45–1.6, 자간 -0.01em): 기본 15px/1.55. 문제 설명은 14.5px/500, 진술 인용은 15.5px/700, 보조 설명은 13–14px. `word-break: keep-all` 로 단어 중간에서 끊지 않는다.
- **Label** (Pretendard 600–700, 12.5px, 행간 1.2–1.3): 종이 위 항목 이름표(유형, 난이도, 이름, 학번), 발화자 이름, 기록 분류.
- **Engraved** (Cinzel 700, 8.5–12px, 자간 0.16–0.34em, 대문자): "DETECTIVE ACADEMY", "VERITAS · RATIO", 인장 둘레 글자, 배지의 등급 글자.

### Named Rules
**12.5px 바닥 규칙 (The 12.5px Floor Rule).** 읽어야 하는 한국어 글자는 12.5px 아래로 내려가지 않는다. 그보다 작은 글자는 원 안의 숫자(11.5–12px)와 Cinzel 각인뿐이다.

**명조는 이름과 숫자에만 규칙 (The Serif-Names-Only Rule).** Hahmlet 은 물건의 이름, 큰 숫자, 인장에만 쓴다. 두 줄 넘는 글, 버튼, 안내문, 이름표는 Pretendard 다.

**각인은 장식 규칙 (The Engraving-Is-Ornament Rule).** Cinzel 글자는 읽지 못해도 진행에 지장이 없어야 한다. 같은 정보가 필요하면 한국어 글자로 따로 둔다. 한국어에는 Cinzel 을 쓰지 않는다.

## Layout

한 손으로 쓰는 세로 한 단 구조다. 앱 틀은 `100dvh` 높이, 최대 폭 480px 이고 가운데에 놓인다. 520px 이상에서는 틀 바깥에 `navy-950` 여백과 황동 1px 테두리가 생길 뿐 구성은 바뀌지 않는다.

화면은 세 층으로 고정된다. 위에 상단 바(최소 56px, 좌우 12px, 홈은 좌우 20px), 가운데에 스크롤 영역(좌우 `gutter` 20px, 아래 28px), 아래에 행동 바(위 12px, 좌우 20px, 아래 14px + 안전 영역). 행동 바는 스크롤 밖에 고정되어 다음 행동 버튼이 항상 엄지 닿는 곳에 있다. 행동 바의 버튼은 남는 폭을 나눠 갖고, 보조 버튼은 내용 폭만 차지한다.

간격 리듬은 실제 사용 값 기준으로 4 / 8 / 10–12 / 16–18 / 22–26 / 30px 다. 같은 물건 안의 요소는 8–12px, 물건과 물건 사이는 12px(풀이 화면) 또는 26–30px(홈·신분증 화면)로 벌린다. 종이 물건의 안쪽 여백은 12–14px(쪽지), 20–24px(수사 파일·보고서)다.

반복 격자는 내용의 개수를 그대로 따른다: 용의자 4칸, 시간표 4칸, 등급 6칸, 결과 수치 3칸, 수사 파일 정보 `1.5fr 1fr 1fr`.

반응은 폭이 아니라 높이에 맞춘다. 숫자 메모는 기본 9칸 한 줄(칩 높이 44px)이고, 세로가 880px 이상이면 5칸 두 줄(46px)로 펼친다. 폭 변화(375·390·430px)는 유동 격자가 흡수하고 별도 분기점이 없다. 안전 영역은 상단 바와 행동 바, 바닥 시트에서 `env(safe-area-inset-*)` 로 더한다.

### Named Rules
**44px 손끝 규칙 (The 44px Touch Rule).** 누를 수 있는 것은 모두 44px 이상의 눌림 영역을 가진다. 작게 보여야 하는 조작부는 보이는 크기를 그대로 두고 눌림 영역만 넓힌다(다이얼 화살표는 32px 로 보이지만 위아래 6px 씩 넓혀 44px).

**다음 행동 하나 규칙 (The One Next Action Rule).** 한 화면에서 가장 무거운 버튼은 하나다. 어두운 바탕에서는 황동 주 버튼, 종이 위에서는 잉크 버튼, 홈에서 연습실이 다음 행동일 때는 황동으로 닦인 문패가 그 자리를 맡고 나머지는 조용한 버튼으로 물러난다.

## Elevation & Depth

혼합형이다. 어두운 바탕 위의 조작부는 그림자 없이 1px 안쪽 테두리와 면의 명도 차이로 구분하고, 책상 위에 놓인 물건(종이, 자물쇠, 봉투, 신분증, 문패)만 아래로 떨어지는 그림자를 가진다. 그림자는 번지는 후광이 아니라 음수 확산값으로 물건 바로 밑에 좁게 깔리는 접지 그림자다. 그래서 물건이 떠 있지 않고 책상에 놓여 보인다.

분위기 층은 셋이다. 왼쪽 위 램프의 따뜻한 빛(`rgba(181, 151, 96, 0.16)` 방사형), 창가의 찬 빛(`rgba(74, 92, 117, 0.3)` 방사형), 미세한 밤 입자(`--night-grain`). 종이에는 별도의 종이 결(`--paper-grain`)이 깔린다. 승급 순간에만 램프가 밝아져 화면 전체의 조명이 바뀐다.

### Shadow Vocabulary
- **종이 접지** (`inset 0 1px 0 rgba(255,255,255,0.7), 0 18px 30px -20px rgba(0,0,0,0.85), 0 2px 5px -2px rgba(0,0,0,0.45)`): 모든 종이 면. 위쪽 흰 선은 종이 모서리의 빛이다.
- **주 버튼** (`inset 0 -1px 0 #6e5a2e, 0 10px 20px -12px rgba(0,0,0,0.9)`): 황동 버튼과 닦인 문패. 아래 모서리 1px 선이 두께를 만든다.
- **조용한 면** (`inset 0 0 0 1px #33445b`): 그림자 없이 테두리만. 조용한 버튼, 메모 칩, 용의자 카드, 패널.
- **들어 올림** (`0 0 0 2px #dbc590, 0 18px 22px -12px rgba(0,0,0,0.95)`): 핀 꽂은 진술 카드, 선택하거나 끄는 발표 카드. 황동 테두리와 더 깊은 그림자가 함께 온다.
- **금속 몸체** (`inset 0 1.5px 0 rgba(255,255,255,0.6), inset 0 -3px 0 rgba(74,60,31,0.55), 0 18px 26px -16px rgba(0,0,0,0.9)`): 자물쇠 몸체. 위 하이라이트와 아래 그늘로 두께를 준다.
- **패인 홈** (`inset 0 0 0 1.5px rgba(27,22,8,0.7), inset 0 6px 10px rgba(0,0,0,0.6)`): 다이얼 창. 안쪽 그림자로 들어가 보이게 한다.
- **물건 낙영** (`drop-shadow(0 24px 22px rgba(0,0,0,0.55))`): 봉투, 엠블럼, 승급 배지처럼 윤곽이 네모가 아닌 SVG 물건.
- **바닥 시트** (`inset 0 1px 0 rgba(181,151,96,0.35), 0 -20px 50px -10px rgba(0,0,0,0.7)`): 위 모서리에 황동 실선 하나.

### Named Rules
**놓인 것만 그림자 규칙 (The Grounded-Objects Rule).** 그림자는 책상에 놓인 물건에만 있다. 어두운 바탕의 일반 조작부는 1px 테두리로 구분한다. 물건을 집으면(선택, 끌기) 그림자가 깊어지고 황동 테두리가 생긴다.

**빛은 왼쪽 위 규칙 (The Lamp-From-Upper-Left Rule).** 램프 빛, 금속 하이라이트, 봉랍 광택은 모두 왼쪽 위에서 온다(방사형 중심 약 35% 30%, 금속 그라디언트 168deg).

## Shapes

모서리는 재질을 따른다. 종이는 거의 각지고(5px, 파일 본문은 탭 쪽만 0), 조작부는 부드럽게 둥글고(8–12px), 패널과 자물쇠 몸체는 더 둥글며(16–18px), 바닥 시트는 위쪽만 22px 다. 원형은 동전, 스위치 손잡이, 번호표, 핀처럼 실제로 둥근 물건에만 쓴다. 알약 모양은 크레딧 표시와 작은 상태 표시에 한정한다.

선에도 재질이 있다. 종이 위의 구분은 점선(`1px dashed rgba(26,32,48,0.3)`, 절취선)이나 옅은 실선(`rgba(26,32,48,0.12)`)이고, 어두운 바탕의 구분은 황동 실선 1px 이다. 비어 있는 자리(카드 슬롯, 미획득 배지, 빈 배지 칸)는 점선 윤곽으로 표시한다.

실루엣이 정보를 나른다. 등급 배지는 여섯 등급이 모두 다른 윤곽과 재질이다(F 둥근 무쇠, D 구리 방패, C 육각 강철, B 어깨 솟은 은 방패, A 여덟 갈래 금 별, S 왕관 쓴 흑단 문장). 인물 표식은 원·방패·육각·마름모 네 윤곽이다. 색만 바꾼 같은 모양을 쓰지 않는다.

종이 물건에는 손댄 흔적이 있다: 인장은 -9도, 판정 도장은 -4도, 뒤에 겹친 서류는 1.1도, 핀 꽂은 카드는 -0.6도 기울고, 봉랍은 완전한 원이 아니다.

## Components

조작부는 조용하고 물건은 무겁다. 누르면 1px 내려앉고(`translateY(1px)`), 물건은 저마다의 물리로 반응한다.

### Buttons
- **Shape:** 부드럽게 둥근 모서리(12px), 높이 52px, 좌우 20px, 16px/700. 작은 버튼은 높이 44px, 10px 모서리, 14px.
- **Primary:** 단색 앤티크 황동 면에 황동 잉크 글자. 아래 모서리 1px 깊은 황동 선과 접지 그림자. 어두운 바탕 전용.
- **Paper:** 종이 위의 주 버튼. 잉크 면에 아이보리 글자. 수사 파일의 "문제 풀기"가 이것이다.
- **Quiet:** 딥 네이비 면에 1px 네이비 테두리. 행동 바의 보조 버튼.
- **Outline / Paper-quiet:** 면 없이 테두리만. 어두운 바탕에서는 황동 선과 밝은 황동 글자, 종이 위에서는 잉크 선과 잉크 글자.
- **Text:** 높이 44px 의 글자 버튼(보조 글자색 14px/600).
- **Hover / Focus:** 터치 전용이라 hover 가 없다. 누르면 120ms 로 1px 내려앉고 면이 한 단계 어두워진다(주 버튼은 `scale(0.985)` 까지). 포커스는 밝은 황동 2px 외곽선에 3px 간격, 종이 위에서는 잉크색 외곽선.
- **Disabled:** 불투명도 0.42, 채도 절반.

### Chips
- **크레딧 표시:** 알약 모양(높이 32px), 반투명 네이비 면, 황동 실선, 동전 + 밝은 황동 숫자. 값이 늘면 520ms 동안 한 번 부푼다.
- **숫자 메모 칩:** 높이 44px, 9px 모서리. 누를 때마다 기본 → 제외(면이 비고 옥스블러드 사선) → 후보(황동 면) → 기본 순으로 돈다. 메모는 위쪽 시도 기록의 같은 숫자에도 그대로 반영된다.
- **참/거짓 메모:** 종이 위 44px 토글 한 쌍. 참은 녹청 면, 거짓은 잉크 면.
- **번호표:** 22px 원. 어두운 바탕에서는 황동 면, 종이 위에서는 잉크 면.

### Cards / Containers
- **종이 (공통 면):** 아이보리 면 + 종이 결, 5px 모서리, 종이 접지 그림자, 잉크 글자. 문제 설명, 시도 기록, 조건표, 진술 카드, 보고서, 연 힌트 쪽지가 모두 이 면이다. 안쪽 구분은 점선.
- **수사 파일:** 홈의 주인공. 날짜가 적힌 파일 탭(`ivory-200`, 한쪽만 둥근 8px 14px 모서리), 클립, 뒤에 1.1도 기울어 겹친 서류 한 장, 옅은 엠블럼 비침(불투명도 0.06), Hahmlet 30px 제목, 점선 아래 3칸 정보, 잉크 주 버튼. 해결하면 비침 자리에 인장이 찍힌다.
- **어두운 패널:** 반투명 딥 네이비 면(`rgba(27,38,53,0.75)`) + 1px 네이비 테두리, 16–18px 모서리. 등급 사다리, 설정 줄, 카드 보관함.
- **알림줄:** 12px 모서리. 오답은 옥스블러드 반투명 면에 옥스블러드 선, 안내는 네이비 면. 260ms 로 아래에서 올라온다. 오답을 차분하게 알리고 정답을 드러내지 않는다.
- **바닥 시트(수사 지원):** 딥 네이비, 위쪽 22px 모서리, 40×4px 손잡이, 뒤는 62% 어두운 막. 시트 안의 단계는 카드가 아니라 황동 실선으로 나누고, 연 힌트만 종이 쪽지가 된다.

### Inputs / Fields
- **신분증 이름 칸:** 종이 위에 직접 쓰는 칸. 테두리 상자 없이 아래 잉크 선 1.5px, Hahmlet 19px, 인주색 커서. 포커스되면 선이 진해진다.
- **이름 바꾸기 칸:** 어두운 바탕 위의 44px 칸. 딥 네이비 면, 10px 모서리, 1px 네이비 테두리. 포커스되면 2px 황동 테두리. 글자 16px(iOS 확대 방지).
- **스위치:** 48×28px 궤도에 22px 아이보리 손잡이. 켜지면 궤도가 황동이 된다.

### Navigation
탭 바나 메뉴가 없다. 이동은 물건을 눌러서 한다. 상단 바에는 44px 뒤로가기 아이콘 버튼, 화면 이름(16px/700)과 한 줄 부제(12.5px), 타이머, 크레딧 표시가 놓인다. 홈에서는 엠블럼과 워드마크가 그 자리를 차지한다. 승급 시험 중에는 상단 바에 옥스블러드 기운이 돌아 시험 중임을 알린다. 화면 전환은 280ms 로 6px 떠오르며, View Transitions 를 지원하면 수사 파일이 풀이 화면으로 400ms 에 걸쳐 이어진다.

### 황동 암호 자물쇠 (시그니처)
솔질한 황동 판(`--brass-metal` + 가로 결) 위에 네 귀퉁이 리벳, 강철 고리, 세 개의 다이얼 창이 있다. 창은 위아래가 어두워지는 패인 홈이고 숫자는 Hahmlet 38px 아이보리다. 숫자는 누르거나 위아래로 밀어 240ms 로 굴리며, 가운데 판독선이 현재 값을 잡는다. 중복 숫자는 옥스블러드 빛으로 경고한다. 정답이면 판독선이 밝게 빛나고 고리가 520ms 탄성으로 들린다. 오답이면 자물쇠가 440ms 덜컹거린다.

### 인장
인주로 찍은 원형 도장. 둘레에 Cinzel 각인, 가운데에 Hahmlet 한글(네 글자는 2×2). SVG 필터로 가장자리가 번지고 군데군데 덜 찍힌다. -9도 기울고 종이에 곱해진다. 찍힐 때 2.3배에서 420ms 로 눌려 내려온다.

### 시험 봉투
아이보리 봉투에 옥스블러드 봉랍. 잠긴 동안은 채도와 밝기를 낮춰 식어 보이고, 조건이 채워지면 봉랍이 2.6초 주기로 아주 조금 숨 쉰다. 열면 봉랍이 떨어지고(320ms) 덮개가 넘어가며(460ms) 시험지가 올라온다(520ms). 홈에는 104px 축소판으로 놓이고, 옆의 두 조건은 채워질 때마다 빈 원이 봉랍 자국으로 바뀐다.

### 탐정 신분증
14px 모서리의 종이 카드. 네이비 머리띠 아래 황동 선, 사선 보안 무늬, 4:5 증명사진, 이름표와 값의 쌍, 등급 배지, 하단의 Cinzel 각인과 기계 판독 줄. 발급되면 황동 고리가 한 번 퍼지고, 승급하면 새 배지가 760ms 로 새겨진다.

### 문패
연습실로 가는 문. 5px 모서리의 딥 네이비 판에 깊은 황동 테두리, 안쪽에 새긴 테두리선 한 줄, 양쪽 나사, Hahmlet 19px 이름. 연습실이 다음 행동이 되면 판 전체가 단색 황동으로 바뀌어 주 버튼 역할을 한다.

### 인물 표식
재질색 4종 중 하나 + 고유 윤곽 + 흰색 이름 첫 글자. 아래에 1.8px 어긋난 그늘과 안쪽 흰 테두리선이 있어 얇은 뱃지처럼 보인다.

### 발표 카드와 자리
끌어서 놓는 종이 카드(12px 모서리, 아래 2px 그늘 선). 빈 자리는 점선 윤곽의 패인 홈이고, 카드를 집으면 놓을 수 있는 자리에 황동 테두리가 켜진다. 놓이면 300ms 탄성으로 자리에 끼워지고, 정답이면 카드 전체가 한 번 빛난다. 끌기 대신 눌러서 고르고 자리를 눌러 놓을 수도 있다.

### 모션 문법
물건은 물리로 반응한다. 조작 반응은 120–240ms, 물건의 큰 동작은 300–520ms, 한 번뿐인 의식(엠블럼 등장 820ms, 배지 새김 760ms, 승급 조명 900ms)만 더 길다. 감속은 `cubic-bezier(0.16, 1, 0.3, 1)`, 찍히고 끼워지는 동작은 살짝 넘쳤다 돌아오는 탄성 곡선을 쓴다. 입학 인트로와 풀이 후 연출은 화면을 눌러 건너뛸 수 있다. `prefers-reduced-motion` 이면 모든 애니메이션과 전환이 사실상 0 이 되고 화면 전환 효과도 꺼진다.

## Do's and Don'ts

### Do:
- **Do** 새 화면도 "어두운 바탕 한 겹 + 그 위의 물건" 구조로 만든다. 읽을거리는 종이(`ivory-100` + 종이 결, 5px 모서리) 위에, 조작부는 어두운 바탕 위에 둔다.
- **Do** 어두운 바탕의 주 버튼은 단색 `brass-500` + `brass-ink`, 종이 위의 주 버튼은 `ink-900` + `ivory-100` 으로 쓴다.
- **Do** 한 화면에 가장 무거운 버튼을 하나만 두고 행동 바에 고정한다.
- **Do** 누를 수 있는 모든 것에 44px 이상의 눌림 영역을 준다. 작게 보여야 하면 보이는 크기는 두고 영역만 넓힌다.
- **Do** 읽어야 하는 한국어 글자는 12.5px 이상으로 쓰고, 종이 위의 보조 글자는 `ink-500` 이상, 어두운 바탕의 보조 글자는 `grey-400` 이상으로 쓴다(둘 다 4.5:1 이상).
- **Do** 종이 위의 구분은 점선으로, 어두운 바탕의 구분은 황동 실선 1px(`rgba(181,151,96,0.22)`)으로 긋는다.
- **Do** 사람과 등급은 색 + 실루엣 + 글자를 함께 써서 구분한다.
- **Do** 새 그래픽은 직접 만든 SVG·CSS 로 그리고, 빛은 왼쪽 위에서 오게 한다.
- **Do** 새 모션은 물건의 물리 반응으로 만들고, 건너뛸 수 있게 하고, `prefers-reduced-motion` 을 따른다.
- **Do** 색 값은 `src/styles/tokens.css` 의 토큰으로 쓴다.

### Don't:
- **Don't** 버튼, 칩, 스위치에 금속 그라디언트를 쓰지 않는다. 금속 광택은 물건에만 있다.
- **Don't** 종이 위에 `brass-500` 을 글자나 버튼 면으로 쓰지 않는다(2.4:1). `brass-on-paper` 나 `ink-900` 을 쓴다.
- **Don't** 녹청을 장식이나 일반 강조로 쓰지 않는다. 참·해결·깨끗한 기록에만 쓴다.
- **Don't** `stamp-ink` 를 어두운 바탕에 쓰지 않는다.
- **Don't** Hahmlet 을 본문, 버튼, 안내문에 쓰지 않고, Cinzel 을 한국어나 꼭 읽어야 하는 정보에 쓰지 않는다.
- **Don't** 홈을 히어로 배너로 채우지 않는다. 가장 먼저 보이는 것은 오늘의 수사 파일이다.
- **Don't** 문제를 양식 필드와 균일한 선택지 카드로 만들지 않는다. 문제 유형마다 만지는 물건이 다르다.
- **Don't** 이모지, 아이콘 폰트, 기본 HTML 조작부, 래스터 이미지로 그래픽을 대신하지 않는다.
- **Don't** 바닥 시트 안에 카드를 또 넣지 않는다. 단계는 실선으로 나눈다.
- **Don't** 교육용 퀴즈 앱이나 밝은 캐주얼 퍼즐 게임처럼 보이게 하지 않는다. 밝은 바탕 전환, 원색 강조, 통통 튀는 과한 모션을 들이지 않는다.
- **Don't** 오답을 붉은 화면이나 큰 경고로 처리하지 않는다. 알림줄 하나와 물건의 덜컹거림이면 충분하다.

## Decisions on Record

되돌리기 쉬운 결정이라 근거와 함께 남긴다.

- **콘셉트 롤 미실행.** 이 빌드를 만든 환경에는 Impeccable 런처가 설치되어 있지 않아 콘셉트 롤(concept-seed)을 실행하지 않았다. 방향은 지시서가 고정한 "Premium Mystery Academy / Modern Detective Game" 을 그대로 따랐다. 시드 값은 없다.
- **숫자 메모 한 줄 유지 (375·390 폭).** 지시서는 "문제 조건을 읽으며 조작하기 쉬울 것"을 요구한다. 375×812 와 390×844 에서 시도 기록, 다이얼, 숫자 메모가 스크롤 없이 한 화면에 들어오게 하려고 메모 칩을 9칸 한 줄(칩 약 33~34×44px)로 둔다. 두 줄(5+4)로 펼치면 칩 폭은 44px 를 넘지만 둘째 줄이 제출 버튼 아래로 밀린다. 세로가 880px 이상인 화면에서만 두 줄로 펼친다. 메모는 잘못 눌러도 다시 누르면 되돌아가는 가벼운 조작이라 이 절충을 택했다.
- **다이얼 위아래 버튼.** 보이는 높이는 32px 이고 눌리는 영역만 `::before` 로 44px 까지 넓혔다. 보이는 크기를 키우면 자물쇠가 커져 위 항목의 한 화면 배치가 깨진다.
- **눌린 황동 면.** 주 버튼과 황동 문패가 눌렸을 때의 면은 `#a0844b` 다. `brass-600` 까지 어둡게 하면 `brass-ink` 글자 대비가 4.5:1 아래로 내려간다.

