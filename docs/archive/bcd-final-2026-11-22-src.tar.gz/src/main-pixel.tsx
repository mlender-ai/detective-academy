// B안 · 픽셀 아트(이전 확정안)의 진입점. 2026-11-22 에 D안으로 확정된 뒤 비교용으로만 남아 있다(pixel.html).
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import "./styles/tokens.css";
import "./styles/base.css";
import "./styles/components.css";
import "./styles/art.css";
import "./styles/hall.css";
import "./styles/desk.css";
import "./styles/rooms.css";
import "./styles/pixel.css";
import "./styles/pixel-rooms.css";

import { App } from "./app/App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
