import { DESK, DESK_TILED } from "../app/backdrop";

/** 화면 전체에 깔리는 책상의 나무 면 */
export function DeskWood() {
  if (DESK_TILED) {
    return <span className="desk__wood desk__wood--tile" style={{ backgroundImage: `url(${DESK})` }} aria-hidden="true" />;
  }
  return <img className="desk__wood" src={DESK} alt="" aria-hidden="true" />;
}
