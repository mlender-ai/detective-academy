import { useLayoutEffect, useRef, useState } from "react";

interface Shape {
  d: string;
  corner: [number, number];
}

/**
 * C안(누아르 카툰) 전용: 게시판의 공고 핀과 승급 시험 봉투의 핀을 붉은 실로 잇는다.
 * 실은 종이 위를 지나지 않고, 게시판 왼쪽 여백의 핀 하나를 거쳐 내려간다. 장식이므로 스크린리더에는 숨긴다.
 */
export function RedString() {
  const ref = useRef<SVGSVGElement>(null);
  const [shape, setShape] = useState<Shape | null>(null);

  useLayoutEffect(() => {
    const svg = ref.current;
    const host = svg?.parentElement;
    if (!svg || !host) return;

    const measure = () => {
      const from = host.querySelector<SVGElement>(".posting__pin");
      const to = host.querySelector<SVGElement>(".promoslip__pin");
      if (!from || !to) {
        setShape(null);
        return;
      }
      const hb = svg.getBoundingClientRect();
      const center = (el: Element, dy: number): [number, number] => {
        const b = el.getBoundingClientRect();
        return [b.left - hb.left + b.width / 2, b.top - hb.top + dy];
      };
      const a = center(from, 8);
      const b = center(to, 8);
      const corner: [number, number] = [17, Math.max(14, a[1] - 4)];
      const sagTop = Math.abs(a[0] - corner[0]) * 0.05;
      const midY = (corner[1] + b[1]) / 2;
      const d =
        `M${a[0].toFixed(1)},${a[1].toFixed(1)} ` +
        `Q${((a[0] + corner[0]) / 2).toFixed(1)},${(corner[1] + sagTop + 4).toFixed(1)} ${corner[0]},${corner[1].toFixed(1)} ` +
        `Q${(corner[0] - 7).toFixed(1)},${midY.toFixed(1)} ${b[0].toFixed(1)},${b[1].toFixed(1)}`;
      setShape((prev) => (prev && prev.d === d ? prev : { d, corner }));
    };

    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(host);
    return () => observer.disconnect();
  }, []);

  return (
    <svg ref={ref} className="redstring" aria-hidden="true" focusable="false">
      {shape && (
        <>
          <path className="redstring__shade" d={shape.d} />
          <path className="redstring__line" d={shape.d} />
          <g transform={`translate(${shape.corner[0]} ${shape.corner[1]})`}>
            <circle r="6.6" cy="2.4" fill="rgba(0,0,0,0.45)" />
            <circle r="6.6" fill="#d22b2b" />
            <path d="M-4.8 3.4 A6.6 6.6 0 0 0 6.4 1.6 A7.4 7.4 0 0 1 -4.8 3.4 Z" fill="#8e1a1d" />
            <circle cx="-2.2" cy="-2.4" r="1.8" fill="#ff9c8f" />
          </g>
        </>
      )}
    </svg>
  );
}
