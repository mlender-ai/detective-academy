// C안 · 누아르 카툰 시안의 진입점. 배치(@layer layout)는 픽셀안과 같은 파일을 쓰고, 겉모습만 noir*.css 로 갈아입는다.
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import "@fontsource/noto-serif-kr/700.css";
import "@fontsource/noto-serif-kr/900.css";
import "@fontsource/gothic-a1/500.css";
import "@fontsource/gothic-a1/700.css";
import "@fontsource/gothic-a1/800.css";
import "@fontsource/nanum-pen-script/400.css";

import "./styles/tokens.css";
import "./styles/base.css";
import "./styles/components.css";
import "./styles/art.css";
import "./styles/hall.css";
import "./styles/desk.css";
import "./styles/rooms.css";
import "./styles/noir.css";
import "./styles/noir-rooms.css";

import { App } from "./app/App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
