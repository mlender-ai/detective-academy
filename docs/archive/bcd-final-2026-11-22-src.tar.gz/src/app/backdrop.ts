import corridorDot from "../assets/art/corridor-dot.png";
import corridorPx from "../assets/art/corridor-px.png";
import deskDot from "../assets/art/desk-dot.png";
import deskPx from "../assets/art/desk-px.png";
import examroomDot from "../assets/art/examroom-dot.png";
import examroomPx from "../assets/art/examroom-px.png";
import corridorNoir from "../assets/art/noir/corridor.svg";
import deskNoir from "../assets/art/noir/desk.svg";
import examroomNoir from "../assets/art/noir/examroom.svg";
import corridorMono from "../assets/art/mono/corridor.png";
import deskMono from "../assets/art/mono/desk.png";
import examroomMono from "../assets/art/mono/examroom.png";
import { MONO, NOIR } from "./art";

/**
 * 배경 그림 후보를 고르는 임시 장치 (2026-11-21).
 * - px: 지금의 배경. 수채 원화를 줄이고 색을 줄여 변환한 것.
 * - dot: 격자에 직접 찍은 배경(scripts/pixel-bg.mjs). 점 크기 그대로(2px) 놓는다.
 * 주소에 ?bg=dot 을 붙이면 새 배경으로 열린다. 사용자가 고르면 한쪽을 지우고 이 파일도 정리한다.
 */
export type Backdrop = "px" | "dot";

export const BACKDROP: Backdrop =
  typeof window !== "undefined" && new URLSearchParams(window.location.search).get("bg") === "dot" ? "dot" : "px";

if (typeof document !== "undefined") document.documentElement.dataset.bg = BACKDROP;

const dot = BACKDROP === "dot";

/* C안(누아르 카툰) 시안은 벡터로 그린 밤 배경을 쓴다 (scripts/noir-art.mjs). */
const noirSet = {
  CORRIDOR: { src: corridorNoir, width: 780, height: 600 },
  EXAMROOM: { src: examroomNoir, width: 780, height: 500 },
};

/* D안(1비트 흑백 도트) 시안은 두 색으로만 찍은 배경을 제 크기 그대로 놓는다 (scripts/mono-art.mjs). */
const monoSet = {
  CORRIDOR: { src: corridorMono, width: 480, height: 320 },
  EXAMROOM: { src: examroomMono, width: 480, height: 256 },
};

export const CORRIDOR = MONO ? monoSet.CORRIDOR : NOIR ? noirSet.CORRIDOR : dot ? { src: corridorDot, width: 480, height: 320 } : { src: corridorPx, width: 192, height: 144 };
export const EXAMROOM = MONO ? monoSet.EXAMROOM : NOIR ? noirSet.EXAMROOM : dot ? { src: examroomDot, width: 480, height: 256 } : { src: examroomPx, width: 192, height: 144 };
export const DESK = MONO ? deskMono : NOIR ? deskNoir : dot ? deskDot : deskPx;
/** 책상은 새 배경에서 위아래로 이어 붙여 깐다 */
export const DESK_TILED = dot && !NOIR && !MONO;
