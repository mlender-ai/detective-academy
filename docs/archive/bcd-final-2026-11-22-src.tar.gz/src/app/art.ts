/**
 * 화풍. 확정안은 D안 · 1비트 흑백 도트다(index.html, 2026-11-22 확정).
 * 나머지는 비교용으로 남아 있는 이전 안이다.
 * - pixel: B안 픽셀 아트 (pixel.html, 2026-11-21 의 확정안)
 * - noir: C안 누아르 카툰 (noir.html)
 * 진입 HTML 의 <html data-art="…"> 로 고른다. 아무것도 달지 않으면 픽셀로 그린다.
 */
export type Art = "pixel" | "noir" | "mono";

const tag = typeof document !== "undefined" ? document.documentElement.dataset.art : undefined;

export const ART: Art = tag === "noir" ? "noir" : tag === "mono" ? "mono" : "pixel";

export const NOIR = ART === "noir";
export const MONO = ART === "mono";
