import type { CSSProperties, ReactNode } from "react";
import type { RankId } from "../engine/types";
import type { PortraitSpec, SpriteName } from "./pixel";
import { useBox } from "./useBox";

/**
 * C안 · 누아르 카툰 시안의 물건과 초상 (2026-11-21, 비교용).
 * 픽셀안의 Sprite 와 같은 이름·같은 자리에 놓이고, 면을 평평하게 칠한 벡터로 그린다.
 * - 조작부에 놓이는 것(문장·열쇠·주화·화살표)은 글자색(currentColor) 한 가지로 그려 흑백을 지킨다.
 * - 종이 물건(봉투·학생 사진)은 종이색과 먹색, 그리고 붉은 표시 하나만 쓴다.
 * - 색은 주인공 초상에만 쓴다.
 */

const PAPER = "#eeeae0";
const PAPER_LIT = "#f7f4ec";
const PAPER_DIM = "#d3cdbf";
const INK = "#121212";
const RED = "#d22b2b";
const RED_DARK = "#8e1a1d";

interface NoirSpriteProps {
  name: SpriteName;
  rank?: RankId;
  portrait?: PortraitSpec;
  className?: string;
  style?: CSSProperties;
}

function Svg({ w, h, vb, className, style, children }: { w: number; h: number; vb?: string; className?: string; style?: CSSProperties; children: ReactNode }) {
  return (
    <svg
      className={["sprite nsprite", className].filter(Boolean).join(" ")}
      style={style}
      width={w}
      height={h}
      viewBox={vb ?? `0 0 ${w} ${h}`}
      aria-hidden="true"
      focusable="false"
    >
      {children}
    </svg>
  );
}

/* ───────── 등급 휘장: 색 대신 먹의 짙기로 등급을 가른다 ───────── */

const MEDAL_TONE: Record<RankId, { fill: string; line: string }> = {
  F: { fill: PAPER_LIT, line: INK },
  D: { fill: "#cfcfcf", line: INK },
  C: { fill: "#9c9c9c", line: INK },
  B: { fill: "#5c5c5c", line: INK },
  A: { fill: "#262626", line: INK },
  S: { fill: "#0a0a0a", line: RED },
};

const SHIELD = "M24 2.5 L45 9.5 V28 C45 41 36 49.5 24 53.5 C12 49.5 3 41 3 28 V9.5 Z";
const SHIELD_IN = "M24 8 L40 13.4 V28 C40 37.8 33.4 44.4 24 47.8 C14.6 44.4 8 37.8 8 28 V13.4 Z";

/* ───────── 학생 사진: 흑백 증명사진 ───────── */

const HAIR_TONE = { dark: "#161616", brown: "#383838", auburn: "#565656", sand: "#a6a6a6" } as const;
const CLOTH_TONE = { green: "#303030", brass: "#8a8a8a", wine: "#464646", steel: "#676767", navy: "#1b1b1b" } as const;

function StudentPortrait({ spec }: { spec: PortraitSpec }) {
  const hair = HAIR_TONE[spec.hairTone];
  const cloth = CLOTH_TONE[spec.tone];
  const line = { stroke: INK, strokeWidth: 0.9, strokeLinejoin: "round" as const };
  const back: ReactNode[] = [];
  const front: ReactNode[] = [];

  switch (spec.hair) {
    case "short":
      front.push(<path key="h" d="M12.6 20 C11.5 11 15.5 7.4 22 7.4 C28.5 7.4 32.5 11 31.4 20 C30 15.5 27.5 13.4 22 13.2 C16.5 13.4 14 15.5 12.6 20 Z" fill={hair} {...line} />);
      break;
    case "side":
      front.push(<path key="h" d="M12.4 21 C11 11 16 7.2 22.5 7.2 C29 7.2 33 11.5 31.6 20 C30.5 15 28.5 12.6 25 12.4 C20 15.5 15.5 15.8 12.4 21 Z" fill={hair} {...line} />);
      break;
    case "crop":
      front.push(<path key="h" d="M13.2 17 C13 10.5 17 8.2 22 8.2 C27 8.2 31 10.5 30.8 17 C29 13.2 26 12 22 12 C18 12 15 13.2 13.2 17 Z" fill={hair} {...line} />);
      break;
    case "bob":
      back.push(<path key="b" d="M10.6 31.5 C8.3 16 13 6.4 22 6.4 C31 6.4 35.7 16 33.4 31.5 Z" fill={hair} {...line} />);
      front.push(<path key="h" d="M12.8 19.5 C13.5 12 17 10 22 10 C27 10 30.5 12 31.2 19.5 C27 16 25 14.6 22 14.6 C19 14.6 17 16 12.8 19.5 Z" fill={hair} />);
      break;
    case "long":
      back.push(<path key="b" d="M10.2 45 C7.3 20 12 6.2 22 6.2 C32 6.2 36.7 20 33.8 45 L28 38 L16 38 Z" fill={hair} {...line} />);
      front.push(<path key="h" d="M12.8 20 C13 11.5 17.5 9.8 22 9.8 C26.5 9.8 31 11.5 31.2 20 C29 15.5 25.5 13.4 22 12.6 C18.5 13.4 15 15.5 12.8 20 Z" fill={hair} />);
      break;
    case "pony":
      back.push(<path key="b" d="M30 12 C36 9 40 14 38.6 20 C41 26 39.6 33 35.4 36.5 C36.4 30 34.6 25.5 31 22 Z" fill={hair} {...line} />);
      front.push(<path key="h" d="M12.6 20 C11.6 11 15.6 7.4 22 7.4 C28.4 7.4 32.4 11 31.4 20 C29.6 14.6 26 12.6 22 13.4 C18.6 12.6 14.4 15 12.6 20 Z" fill={hair} {...line} />);
      break;
    case "curly":
      front.push(
        <g key="h" fill={hair} {...line}>
          {[
            [13.4, 17.8, 3.4],
            [14.4, 12.8, 4.2],
            [18.4, 9.4, 4.4],
            [23.2, 8.2, 4.6],
            [27.8, 9.8, 4.4],
            [30.8, 13.6, 4],
            [31.2, 18.2, 3.2],
          ].map(([cx, cy, r]) => (
            <circle key={`${cx}`} cx={cx} cy={cy} r={r} />
          ))}
        </g>,
      );
      break;
    case "braid":
      back.push(
        <g key="b" fill={hair} {...line}>
          <path d="M11 27 C9 15 13.4 6.6 22 6.6 C30.6 6.6 35 15 33 27 Z" />
          {[29.5, 34, 38.5, 43].map((y) => (
            <g key={y}>
              <circle cx="11.2" cy={y} r="2.7" />
              <circle cx="32.8" cy={y} r="2.7" />
            </g>
          ))}
        </g>,
      );
      front.push(<path key="h" d="M12.8 19.5 C13.5 12 17 10 22 10 C27 10 30.5 12 31.2 19.5 C28 15.4 24.5 14 22 15.6 C19.5 14 16 15.4 12.8 19.5 Z" fill={hair} />);
      break;
    default:
      break;
  }

  return (
    <>
      {back}
      <path d="M3 50 C4 40.5 10 37.4 17 36.4 L27 36.4 C34 37.4 40 40.5 41 50 Z" fill={cloth} {...line} />
      <path d="M17.2 36.4 L22 43.5 L26.8 36.4 Z" fill="#f4f4f4" stroke={INK} strokeWidth="0.7" strokeLinejoin="round" />
      <path d="M22 39.4 l-1.5 1.9 l1.5 8.7 l1.5 -8.7 Z" fill={INK} />
      <path d="M18.6 29 h6.8 v7.6 h-6.8 Z" fill="#b9b9b9" />
      <ellipse cx="22" cy="20" rx="9.2" ry="10.8" fill="#eeeeee" {...line} />
      <path d="M22 9.2 A9.2 10.8 0 0 1 22 30.8 Z" fill="#c2c2c2" />
      <ellipse cx="18.5" cy="20.6" rx="1" ry="1.25" fill={INK} />
      <ellipse cx="25.6" cy="20.6" rx="1" ry="1.25" fill={INK} />
      <path d="M16.4 17.8 h4 M23.8 17.8 h3.8" stroke={INK} strokeWidth="0.9" strokeLinecap="round" />
      <path d="M22 21.6 v3 l-1.2 0.5" fill="none" stroke={INK} strokeWidth="0.7" strokeLinecap="round" opacity="0.55" />
      <path d="M19.6 26.7 q2.4 1.1 4.8 0" fill="none" stroke={INK} strokeWidth="0.95" strokeLinecap="round" />
      {front}
      {spec.glasses && (
        <g fill="rgba(255,255,255,0.35)" stroke={INK} strokeWidth="1.05">
          <circle cx="18.4" cy="20.8" r="3.2" />
          <circle cx="25.7" cy="20.8" r="3.2" />
          <path d="M21.6 20.4 h0.9 M15.2 20.2 l-2 -0.8 M28.9 20.2 l2 -0.8" fill="none" />
        </g>
      )}
    </>
  );
}

/** 주인공(견습 탐정): 중절모 그늘에 눈이 묻힌 얼굴. 왼쪽에서 등불이, 뒤에서 블라인드 빛이 든다. */
function HeroPortrait() {
  return (
    <>
      <rect width="60" height="70" fill="#14292a" />
      <g fill="#efdfb1" opacity="0.26">
        <path d="M60 4 L60 10 L0 44 L0 38 Z" />
        <path d="M60 16 L60 22 L0 56 L0 50 Z" />
        <path d="M60 28 L60 34 L0 68 L0 62 Z" />
        <path d="M60 -8 L60 -2 L0 32 L0 26 Z" />
      </g>
      <path d="M1 70 C2 56.5 11 52 21 50 L39 50 C49 52 58 56.5 59 70 Z" fill="#090d0e" />
      <path d="M24 50 L30 61 L36 50 Z" fill="#ece4cf" />
      <path d="M30 54 l-2.3 2.8 l2.3 13.2 l2.3 -13.2 Z" fill={RED} />
      <path d="M25.4 41 h9.2 v10 l-4.6 4 l-4.6 -4 Z" fill="#7a4d2a" />
      <path d="M30 41 h4.6 v10 l-4.6 4 Z" fill="#33251c" />
      <path d="M12.5 56 L22.6 41 L28.4 57.5 Z M47.5 56 L37.4 41 L31.6 57.5 Z" fill="#141c1d" stroke="#2a3839" strokeWidth="0.8" strokeLinejoin="round" />
      <path d="M19.6 25 C19 36 22.2 43.6 30 45.8 C37.8 43.6 41 36 40.4 25 Z" fill="#3a2c23" />
      <path d="M19.6 25 C19 36 22.2 43.6 30 45.8 L28.2 25 Z" fill="#e3a45c" />
      <path d="M28.2 25 L30 45.8 C31.6 45.3 33 44.6 34.2 43.6 L31.6 25 Z" fill="#a8703c" />
      <path d="M19.4 25 h21.2 v6.2 C36 32.6 24 32.6 19.4 31.2 Z" fill="#150f0c" opacity="0.88" />
      <path d="M22.8 29.3 h3.9" stroke="#f6e7bf" strokeWidth="1.3" strokeLinecap="round" />
      <path d="M33.3 29.3 h3.5" stroke="#f6e7bf" strokeWidth="1.3" strokeLinecap="round" opacity="0.55" />
      <path d="M29.6 31.4 L28.3 37 L30.8 37.5" fill="none" stroke="#2a1c14" strokeWidth="0.9" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M26.4 40.6 q3.4 1.1 6.6 -0.3" fill="none" stroke="#2a1c14" strokeWidth="1.1" strokeLinecap="round" />
      <path d="M17 23.4 C16.4 11 21 6.4 30 6.4 C39 6.4 43.6 11 43 23.4 C39 20.8 21 20.8 17 23.4 Z" fill="#0b1011" />
      <path d="M17.1 19.4 C22 17.4 38 17.4 42.9 19.4 L43 23.4 C39 20.8 21 20.8 17 23.4 Z" fill="#2a3a3b" />
      <path d="M26 7.4 C28 9.6 32 9.6 34 7.4" fill="none" stroke="#1b2627" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M8.4 25.6 C16 20.4 44 20.4 51.6 25.6 C44 28.8 16 28.8 8.4 25.6 Z" fill="#050708" />
      <path d="M17.4 21 C17 13 19.6 8.6 24.4 7.2" fill="none" stroke="#f2a93b" strokeWidth="1.2" strokeLinecap="round" opacity="0.85" />
      <path d="M8.8 25.4 C12 23.2 16 22 20 21.4" fill="none" stroke="#f2a93b" strokeWidth="1.1" strokeLinecap="round" opacity="0.8" />
      <path d="M42.8 21 C43.2 14 41 9.6 37 7.6" fill="none" stroke="#efdfb1" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
      <path d="M59 70 C58 56.5 49 52 41.5 50.4" fill="none" stroke="#efdfb1" strokeWidth="1" strokeLinecap="round" opacity="0.45" />
    </>
  );
}

/* ───────── 물건 ───────── */

export function NoirSprite({ name, rank = "F", portrait, className, style }: NoirSpriteProps) {
  switch (name) {
    case "portrait": {
      if (!portrait || portrait.hair === "cap") {
        return (
          <svg className={["sprite nsprite nportrait nportrait--hero", className].filter(Boolean).join(" ")} style={style} viewBox="0 0 60 70" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">
            <HeroPortrait />
          </svg>
        );
      }
      return (
        <svg className={["sprite nsprite nportrait", className].filter(Boolean).join(" ")} style={style} viewBox="0 0 44 50" preserveAspectRatio="xMidYMax slice" aria-hidden="true" focusable="false">
          <StudentPortrait spec={portrait} />
        </svg>
      );
    }

    case "crest":
      return (
        <Svg w={36} h={42} className={className} style={style}>
          <path d="M18 2 L33 7 V20 C33 30 26.5 36.5 18 40 C9.5 36.5 3 30 3 20 V7 Z" fill="var(--art-bg, none)" stroke="currentColor" strokeWidth="2.4" strokeLinejoin="round" />
          <circle cx="16.4" cy="17.4" r="6.4" fill="none" stroke="currentColor" strokeWidth="2.4" />
          <path d="M21.2 22.4 L26.8 28.6" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" />
          <circle cx="16.4" cy="16.2" r="1.7" fill="currentColor" />
          <path d="M16.4 16.6 v4" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
        </Svg>
      );

    case "key":
      return (
        <Svg w={60} h={28} className={className} style={style}>
          <circle cx="12" cy="14" r="9" fill="none" stroke="currentColor" strokeWidth="2.6" />
          <circle cx="12" cy="14" r="3" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M21 14 H57 M45 14 v8.5 M52 14 v6 M26 10.5 v7" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" />
        </Svg>
      );

    case "id":
      return (
        <Svg w={56} h={40} className={className} style={style}>
          <rect x="2" y="2" width="52" height="36" rx="2" fill="none" stroke="currentColor" strokeWidth="2.4" />
          <path d="M2 10 H54" stroke="currentColor" strokeWidth="2.4" />
          <rect x="8" y="15.5" width="13" height="16" fill="currentColor" />
          <path d="M27 18 H47 M27 24 H42 M27 30 H38" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
        </Svg>
      );

    case "coins":
      return (
        <Svg w={44} h={38} className={className} style={style}>
          {[27, 20, 13].map((y) => (
            <g key={y} fill="var(--art-bg, #0a0a0a)" stroke="currentColor" strokeWidth="2.2">
              <path d={`M6 ${y} v5 a16 6 0 0 0 32 0 v-5`} />
              <ellipse cx="22" cy={y} rx="16" ry="6" />
            </g>
          ))}
          <path d="M22 9.6 l1.6 2.4 l-1.6 2.4 l-1.6 -2.4 Z" fill="currentColor" transform="scale(1 0.7) translate(0 5.6)" />
        </Svg>
      );

    case "coin":
      return (
        <Svg w={22} h={22} className={className} style={style}>
          <circle cx="11" cy="11" r="9.6" fill="currentColor" />
          <circle cx="11" cy="11" r="6.4" fill="none" stroke="var(--art-bg, #fff)" strokeWidth="1.4" />
          <path d="M11 6.9 L12.2 9.8 L15.1 11 L12.2 12.2 L11 15.1 L9.8 12.2 L6.9 11 L9.8 9.8 Z" fill="var(--art-bg, #fff)" />
        </Svg>
      );

    case "envelope":
      return (
        <Svg w={84} h={58} className={className} style={style}>
          <rect x="1.5" y="1.5" width="81" height="55" fill={PAPER} stroke={INK} strokeWidth="2" />
          <path d="M1.5 56.5 L31 29 M82.5 56.5 L53 29" stroke={INK} strokeWidth="1.4" opacity="0.6" />
          <path d="M1.5 1.5 L42 35 L82.5 1.5 Z" fill={PAPER_LIT} stroke={INK} strokeWidth="2" strokeLinejoin="round" />
          <circle cx="42" cy="33" r="8" fill={RED} />
          <circle cx="42" cy="33" r="4.2" fill="none" stroke={RED_DARK} strokeWidth="1.4" />
        </Svg>
      );

    case "envelope-open":
      return (
        <Svg w={84} h={74} className={className} style={style}>
          <path d="M1.5 18.5 L42 2 L82.5 18.5 Z" fill={PAPER_DIM} stroke={INK} strokeWidth="2" strokeLinejoin="round" />
          <rect x="1.5" y="18.5" width="81" height="54" fill={PAPER_DIM} stroke={INK} strokeWidth="2" />
          <rect x="11" y="8" width="62" height="48" fill={PAPER_LIT} stroke={INK} strokeWidth="1.6" />
          <path d="M20 19 H64 M20 27 H56 M20 35 H60" stroke={INK} strokeWidth="1.6" opacity="0.5" />
          <path d="M1.5 18.5 L42 50 L82.5 18.5 V72.5 H1.5 Z" fill={PAPER} stroke={INK} strokeWidth="2" strokeLinejoin="round" />
        </Svg>
      );

    case "pin":
      return (
        <Svg w={16} h={24} className={className} style={style}>
          <path d="M8 12 V23" stroke="#8d8d8d" strokeWidth="1.6" strokeLinecap="round" />
          <circle cx="8" cy="8" r="6.8" fill={RED} />
          <path d="M3.2 11.4 A6.8 6.8 0 0 0 14.6 9.6 A7.6 7.6 0 0 1 3.2 11.4 Z" fill={RED_DARK} />
          <circle cx="5.8" cy="5.6" r="1.9" fill="#ff9c8f" />
        </Svg>
      );

    case "shackle":
      return (
        <Svg w={112} h={92} className={className} style={style}>
          <path d="M24 92 V46 a32 32 0 0 1 64 0 V92" fill="none" stroke="#050505" strokeWidth="21" />
          <path d="M24 92 V46 a32 32 0 0 1 64 0 V92" fill="none" stroke="#b9b9b9" strokeWidth="15.5" />
          <path d="M28.5 92 V46 a27.5 27.5 0 0 1 55 0 V92" fill="none" stroke="#7d7d7d" strokeWidth="6.5" />
          <path d="M19.5 90 V46 a36.5 36.5 0 0 1 36.5 -36.5" fill="none" stroke="#f6f6f6" strokeWidth="3" strokeLinecap="round" />
        </Svg>
      );

    case "pencil":
      return (
        <Svg w={108} h={14} className={className} style={style}>
          <rect x="1" y="1.5" width="8" height="11" rx="2" fill={RED} />
          <rect x="8" y="1" width="9" height="12" fill="#9a9a9a" />
          <path d="M11 1 v12 M14 1 v12" stroke="#5c5c5c" strokeWidth="1" />
          <rect x="17" y="1" width="71" height="12" fill="#111111" />
          <rect x="17" y="3.6" width="71" height="2" fill="#4a4a4a" />
          <path d="M88 1 L103 7 L88 13 Z" fill="#d8c8a2" />
          <path d="M98.6 5.2 L103 7 L98.6 8.8 Z" fill="#111111" />
        </Svg>
      );

    case "chevron-up":
      return (
        <Svg w={18} h={10} className={className} style={style}>
          <path d="M9 0.5 L17.5 9.5 H0.5 Z" fill="currentColor" />
        </Svg>
      );

    case "chevron-down":
      return (
        <Svg w={18} h={10} className={className} style={style}>
          <path d="M9 9.5 L17.5 0.5 H0.5 Z" fill="currentColor" />
        </Svg>
      );

    case "arrow-left":
      return (
        <Svg w={22} h={18} className={className} style={style}>
          <path d="M10 2 L3 9 L10 16 M3.4 9 H20" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
      );

    case "sparkle":
      return (
        <Svg w={14} h={14} className={className} style={style}>
          <path d="M7 0 Q7.8 6.2 14 7 Q7.8 7.8 7 14 Q6.2 7.8 0 7 Q6.2 6.2 7 0 Z" fill="currentColor" />
        </Svg>
      );

    case "medal": {
      const tone = MEDAL_TONE[rank];
      return (
        <Svg w={48} h={56} className={className} style={style}>
          <path d={SHIELD} fill={tone.fill} stroke={INK} strokeWidth="2.6" strokeLinejoin="round" />
          <path d={SHIELD_IN} fill="none" stroke={tone.line === RED ? RED : rank === "A" || rank === "B" ? "#f4f4f4" : INK} strokeWidth="1.2" strokeLinejoin="round" opacity={rank === "F" ? 0.5 : 0.85} />
        </Svg>
      );
    }

    case "env-back":
      return (
        <Svg w={220} h={152} className={className} style={style}>
          <rect x="1.5" y="1.5" width="217" height="149" fill="#c4bdae" stroke={INK} strokeWidth="2.6" />
        </Svg>
      );

    case "env-lid":
      return (
        <Svg w={220} h={88} className={className} style={style}>
          <path d="M1.5 88 L110 5 L218.5 88 Z" fill={PAPER_DIM} stroke={INK} strokeWidth="2.6" strokeLinejoin="round" />
          <path d="M22 80 L110 14 L198 80" fill="none" stroke={INK} strokeWidth="1.2" opacity="0.35" />
        </Svg>
      );

    case "env-front":
      return (
        <Svg w={220} h={152} className={className} style={style}>
          <path d="M1.5 1.5 L110 84 L218.5 1.5 V150.5 H1.5 Z" fill={PAPER} stroke={INK} strokeWidth="2.6" strokeLinejoin="round" />
          <path d="M1.5 150.5 L86 66 M218.5 150.5 L134 66" fill="none" stroke={INK} strokeWidth="1.4" opacity="0.45" />
        </Svg>
      );

    case "env-flap":
      return (
        <Svg w={220} h={108} className={className} style={style}>
          <path d="M1.5 1.5 H218.5 L110 86 Z" fill={PAPER_LIT} stroke={INK} strokeWidth="2.6" strokeLinejoin="round" />
          <circle cx="110" cy="82" r="19" fill={RED} />
          <path d="M94 90 A19 19 0 0 0 128.6 86 A21 21 0 0 1 94 90 Z" fill={RED_DARK} />
          <circle cx="108.6" cy="80.4" r="6" fill="none" stroke={RED_DARK} strokeWidth="2.4" />
          <path d="M113 85 L117.6 90" stroke={RED_DARK} strokeWidth="2.8" strokeLinecap="round" />
        </Svg>
      );
  }
}

/* ───────── 표시: 붉은 색연필로 그은 동그라미·체크·가위표·밑줄 ───────── */

interface NoirMarkProps {
  kind: "circle" | "check" | "cross" | "underline";
  tone?: "red" | "dark";
  draw?: boolean;
  delayMs?: number;
  className?: string;
}

function markPath(kind: NoirMarkProps["kind"], w: number, h: number): string {
  const X = (v: number) => Math.round(v * w) / 100;
  const Y = (v: number) => Math.round(v * h) / 100;
  if (kind === "circle") {
    return `M${X(54)},${Y(7)} C${X(22)},${Y(1)} ${X(3)},${Y(24)} ${X(5)},${Y(52)} C${X(7)},${Y(83)} ${X(34)},${Y(98)} ${X(58)},${Y(95)} C${X(85)},${Y(91)} ${X(99)},${Y(66)} ${X(95)},${Y(42)} C${X(91)},${Y(18)} ${X(66)},${Y(3)} ${X(38)},${Y(11)}`;
  }
  if (kind === "check") {
    const m = Math.min(w, h);
    const s = (v: number) => Math.round(v * m) / 100;
    return `M${s(8)},${s(54)} L${s(36)},${s(88)} L${s(96)},${s(8)}`;
  }
  if (kind === "cross") {
    const m = Math.min(w, h);
    const ox = (w - m) / 2;
    const oy = (h - m) / 2;
    const s = (v: number) => Math.round(v * m) / 100;
    return `M${ox + s(12)},${oy + s(10)} L${ox + s(90)},${oy + s(92)} M${ox + s(90)},${oy + s(12)} L${ox + s(10)},${oy + s(88)}`;
  }
  return `M${X(1)},${h - 2} C${X(30)},${h - 4.5} ${X(70)},${h - 0.5} ${X(99)},${h - 3}`;
}

export function NoirMark({ kind, tone = "red", draw = false, delayMs = 0, className }: NoirMarkProps) {
  const [ref, box] = useBox<HTMLSpanElement>();
  const ready = box.w > 6 && box.h > 3;
  return (
    <span
      ref={ref}
      className={["penmark nmark", className].filter(Boolean).join(" ")}
      data-kind={kind}
      data-tone={tone}
      data-draw={draw}
      style={{ "--pen-delay": `${delayMs}ms` } as CSSProperties}
      aria-hidden="true"
    >
      {ready && (
        <svg width={box.w} height={box.h} viewBox={`0 0 ${box.w} ${box.h}`} focusable="false">
          <path d={markPath(kind, box.w, box.h)} pathLength={1} />
        </svg>
      )}
    </span>
  );
}
