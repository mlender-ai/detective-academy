/// <reference types="vitest/config" />
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // 상대 경로 빌드: 정적 호스팅 하위 경로·Capacitor 웹뷰에서도 그대로 열린다.
  base: "./",
  build: {
    // index.html: 확정안(D안 1비트 흑백 도트) · pixel.html: B안 픽셀 아트 · noir.html: C안 누아르 카툰 · compare.html: 나란히 보는 문서
    rollupOptions: { input: ["index.html", "pixel.html", "noir.html", "compare.html"] },
  },
  test: {
    environment: "node",
    include: ["src/tests/**/*.test.ts"],
  },
});
