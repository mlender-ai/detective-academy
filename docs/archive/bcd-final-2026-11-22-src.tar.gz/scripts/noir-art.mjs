// C안 · 누아르 카툰 시안의 배경 세 장을 벡터(SVG)로 그린다.
//   node scripts/noir-art.mjs            → src/assets/art/noir/{corridor,desk,examroom}.svg
// 화풍: 면을 평평하게 칠한 깔끔한 2D 카툰. 어두운 청록빛 그늘, 등불의 호박색, 블라인드 사이로 든 크림색 빛, 붉은 실.
// 조작부(단추·막대)는 흑백이고, 색은 이 그림들과 빛에만 쓴다.
import { mkdirSync, writeFileSync } from "node:fs";

const OUT = new URL("../src/assets/art/noir/", import.meta.url);
mkdirSync(OUT, { recursive: true });

const lerp = (a, b, t) => a + (b - a) * t;
const n = (v) => Math.round(v * 10) / 10;
const pts = (list) => list.map(([x, y]) => `${n(x)},${n(y)}`).join(" ");
const poly = (list, attrs) => `<polygon points="${pts(list)}" ${attrs}/>`;
const line = (a, b, attrs) => `<line x1="${n(a[0])}" y1="${n(a[1])}" x2="${n(b[0])}" y2="${n(b[1])}" ${attrs}/>`;
function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

const C = {
  black: "#060809",
  night: "#0a0e0f",
  wallL: "#101a1b",
  wallR: "#0c1415",
  wains: "#0b1213",
  rail: "#1e2c2d",
  floor: "#111819",
  plank: "#1a2526",
  ceil: "#07090a",
  beam: "#111a1b",
  door: "#0a1011",
  doorEdge: "#1d2a2b",
  glass: "#152122",
  cream: "#efdfb1",
  creamDim: "#c9bb8f",
  amber: "#f2a93b",
  amberLit: "#ffd685",
  amberDeep: "#b9691c",
  red: "#d22b2b",
  coat: "#080b0c",
  coatLine: "#172021",
};

/* ───────── 1. 학원 복도 (밤) ───────── */
function corridor() {
  const W = 780;
  const H = 600;
  const far = { x0: 196, x1: 330, y0: 222, y1: 376 };
  const xl = (t) => lerp(0, far.x0, t);
  const xr = (t) => lerp(W, far.x1, t);
  const yc = (t) => lerp(0, far.y0, t);
  const yf = (t) => lerp(H, far.y1, t);
  const L = (t, h) => [xl(t), lerp(yf(t), yc(t), h)];
  const R = (t, h) => [xr(t), lerp(yf(t), yc(t), h)];
  const F = (t, u) => [lerp(xr(t), xl(t), u), yf(t)];
  const Ce = (t, u) => [lerp(xr(t), xl(t), u), yc(t)];
  const o = [];

  o.push(`<defs>
    <linearGradient id="spill" gradientUnits="userSpaceOnUse" x1="0" y1="${far.y1}" x2="0" y2="${H}">
      <stop offset="0" stop-color="${C.amber}" stop-opacity="0.62"/><stop offset="0.5" stop-color="${C.amber}" stop-opacity="0.2"/><stop offset="1" stop-color="${C.amber}" stop-opacity="0"/>
    </linearGradient>
    <radialGradient id="halo" gradientUnits="userSpaceOnUse" cx="263" cy="318" r="170">
      <stop offset="0" stop-color="${C.amber}" stop-opacity="0.5"/><stop offset="0.45" stop-color="${C.amberDeep}" stop-opacity="0.18"/><stop offset="1" stop-color="${C.amberDeep}" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="pane" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${C.amberLit}"/><stop offset="1" stop-color="${C.amber}"/>
    </linearGradient>
    <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#f6ebc6"/><stop offset="1" stop-color="${C.creamDim}"/>
    </linearGradient>
    <radialGradient id="haze" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0" stop-color="${C.cream}" stop-opacity="0.16"/><stop offset="1" stop-color="${C.cream}" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="vig" cx="0.42" cy="0.52" r="0.78">
      <stop offset="0.5" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.6"/>
    </radialGradient>
    <linearGradient id="topfade" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#000" stop-opacity="0.55"/><stop offset="0.3" stop-color="#000" stop-opacity="0"/>
    </linearGradient>
  </defs>`);

  // 면
  o.push(`<rect width="${W}" height="${H}" fill="${C.night}"/>`);
  o.push(poly([[0, 0], [W, 0], [far.x1, far.y0], [far.x0, far.y0]], `fill="${C.ceil}"`));
  o.push(poly([[0, H], [W, H], [far.x1, far.y1], [far.x0, far.y1]], `fill="${C.floor}"`));
  o.push(poly([[0, 0], [far.x0, far.y0], [far.x0, far.y1], [0, H]], `fill="${C.wallL}"`));
  o.push(poly([[W, 0], [far.x1, far.y0], [far.x1, far.y1], [W, H]], `fill="${C.wallR}"`));

  // 천장 보
  for (const t of [0.14, 0.36, 0.56, 0.72, 0.85, 0.94]) o.push(line(Ce(t, 0), Ce(t, 1), `stroke="${C.beam}" stroke-width="${n(lerp(5, 1, t))}"`));

  // 허리 판자(징두리)
  o.push(poly([L(0, 0), L(1, 0), L(1, 0.3), L(0, 0.3)], `fill="${C.wains}"`));
  o.push(poly([R(0, 0), R(1, 0), R(1, 0.3), R(0, 0.3)], `fill="#080d0e"`));
  o.push(line(L(0, 0.3), L(1, 0.3), `stroke="${C.rail}" stroke-width="2.5"`));
  o.push(line(R(0, 0.3), R(1, 0.3), `stroke="#162021" stroke-width="2.5"`));

  // 마루 널
  for (let u = 0.1; u < 0.95; u += 0.1) o.push(line(F(0, u), F(1, u), `stroke="${C.plank}" stroke-width="1.2"`));

  // 복도 끝 벽과 불 켜진 문
  o.push(`<rect x="${far.x0}" y="${far.y0}" width="${far.x1 - far.x0}" height="${far.y1 - far.y0}" fill="#090d0e"/>`);
  o.push(`<rect x="${far.x0}" y="${far.y0 + 106}" width="${far.x1 - far.x0}" height="${far.y1 - far.y0 - 106}" fill="#070a0b"/>`);
  o.push(`<circle cx="263" cy="318" r="170" fill="url(#halo)"/>`);
  const dx0 = 232;
  const dx1 = 294;
  const dy0 = 262;
  o.push(`<rect x="${dx0 - 5}" y="${dy0 - 5}" width="${dx1 - dx0 + 10}" height="${far.y1 - dy0 + 5}" fill="#141d1e"/>`);
  o.push(`<rect x="${dx0}" y="${dy0}" width="${dx1 - dx0}" height="${far.y1 - dy0}" fill="#050708"/>`);
  o.push(`<rect x="${dx0 + 5}" y="${dy0 + 6}" width="23" height="62" fill="url(#pane)"/>`);
  o.push(`<rect x="${dx1 - 28}" y="${dy0 + 6}" width="23" height="62" fill="url(#pane)"/>`);
  // 유리에 비친 글자 자리(읽히지 않는 선)
  for (let i = 0; i < 3; i++) {
    o.push(`<rect x="${dx0 + 9}" y="${dy0 + 20 + i * 9}" width="${15 - i * 3}" height="2.4" fill="${C.amberDeep}" opacity="0.75"/>`);
    o.push(`<rect x="${dx1 - 24}" y="${dy0 + 20 + i * 9}" width="${15 - i * 4}" height="2.4" fill="${C.amberDeep}" opacity="0.75"/>`);
  }
  o.push(`<rect x="${dx0 + 14}" y="${dy0 - 22}" width="${dx1 - dx0 - 28}" height="10" fill="${C.amberLit}" opacity="0.85"/>`);
  // 문 앞 바닥으로 번진 불빛
  o.push(poly([F(1, 0.2), F(1, 0.8), [40, H], [520, H]], `fill="url(#spill)"`));

  // 왼쪽 벽의 교실 문 세 개. 가운데 교실에는 아직 누가 남아 있다.
  const doors = [
    [0.14, 0.34, false],
    [0.5, 0.64, true],
    [0.75, 0.84, false],
  ];
  for (const [a, b, lit] of doors) {
    o.push(poly([L(a, 0), L(b, 0), L(b, 0.7), L(a, 0.7)], `fill="${C.door}" stroke="${C.doorEdge}" stroke-width="2"`));
    const ga = lerp(a, b, 0.2);
    const gb = lerp(a, b, 0.8);
    o.push(poly([L(ga, 0.38), L(gb, 0.38), L(gb, 0.62), L(ga, 0.62)], lit ? `fill="url(#pane)"` : `fill="${C.glass}"`));
    if (lit) {
      o.push(poly([L(ga, 0.5), L(gb, 0.5), L(gb, 0.51), L(ga, 0.51)], `fill="${C.amberDeep}"`));
      o.push(poly([L(a, 0), L(b, 0), F(b - 0.03, 0.7), F(a - 0.16, 0.66)], `fill="${C.amber}" opacity="0.22"`));
    }
  }

  // 오른쪽 벽의 높은 창과 블라인드
  const wins = [
    [0.06, 0.32, 13],
    [0.45, 0.62, 10],
    [0.73, 0.83, 7],
  ];
  wins.forEach(([a, b, slats], wi) => {
    const h0 = 0.36;
    const h1 = 0.88;
    o.push(poly([R(a, h0), R(b, h0), R(b, h1), R(a, h1)], `fill="url(#sky)"`));
    const dh = (h1 - h0) / slats;
    for (let k = 0; k < slats; k++) {
      const ha = h0 + k * dh;
      o.push(poly([R(a, ha), R(b, ha), R(b, ha + dh * 0.62), R(a, ha + dh * 0.62)], `fill="#070b0c"`));
    }
    const m = lerp(a, b, 0.5);
    o.push(line(R(m, h0), R(m, h1), `stroke="#070b0c" stroke-width="${n(lerp(4, 1.5, a))}"`));
    o.push(poly([R(a, h0), R(b, h0), R(b, h1), R(a, h1)], `fill="none" stroke="#05080a" stroke-width="${n(lerp(6, 2.5, a))}"`));
    o.push(poly([R(a - 0.012, h0 - 0.02), R(b + 0.008, h0 - 0.02), R(b + 0.008, h0), R(a - 0.012, h0)], `fill="#182223"`));

    // 바닥에 떨어진 살 무늬 빛
    const ta = Math.max(0, a - 0.05);
    const tb = b - 0.03;
    const bands = wi === 0 ? 8 : 7;
    for (let i = 0; i < bands; i++) {
      const u = 0.07 + i * 0.07;
      o.push(poly([F(ta, u), F(tb, u), F(tb, u + 0.036), F(ta, u + 0.036)], `fill="${C.cream}" opacity="${n(0.5 - i * 0.045)}"`));
    }
    // 먼 창의 빛은 맞은편 벽까지 닿는다
    if (wi > 0) {
      for (let i = 0; i < 4; i++) {
        const h = 0.04 + i * 0.075;
        o.push(poly([L(ta, h), L(tb, h), L(tb, h + 0.04), L(ta, h + 0.04)], `fill="${C.cream}" opacity="${n(0.12 - i * 0.02)}"`));
      }
    }
  });

  // 꺼진 전등 둘
  for (const t of [0.3, 0.68]) {
    const [cx, cy] = Ce(t, 0.5);
    const drop = lerp(86, 26, t);
    const w = lerp(30, 9, t);
    o.push(line([cx, cy], [cx, cy + drop], `stroke="#1a2526" stroke-width="${n(lerp(2.4, 1, t))}"`));
    o.push(poly([[cx - w * 0.3, cy + drop], [cx + w * 0.3, cy + drop], [cx + w, cy + drop + w * 0.62], [cx - w, cy + drop + w * 0.62]], `fill="#162021"`));
  }

  o.push(`<ellipse cx="470" cy="330" rx="230" ry="250" fill="url(#haze)"/>`);
  // 주인공: 긴 외투와 중절모. 복도 끝의 불 켜진 문을 바라보고 서 있다.
  o.push(`<g id="hero" transform="translate(-176 -50) scale(1.12)">
    <path d="M556,262 C540,262 522,270 512,286 L524,424 L498,600 L682,600 L656,424 L668,286 C658,270 640,262 624,262 Z" fill="${C.coat}"/>
    <path d="M512,286 C500,300 493,352 489,412 C487,452 491,492 501,524 L525,517 C519,482 520,442 526,402 C531,352 531,312 527,290 Z" fill="#0b1011" stroke="${C.coatLine}" stroke-width="1.6"/>
    <path d="M668,286 C680,300 687,352 691,412 C693,452 689,492 679,524 L655,517 C661,482 660,442 654,402 C649,352 649,312 653,290 Z" fill="#0b1011" stroke="${C.coatLine}" stroke-width="1.6"/>
    <path d="M528,302 C560,318 620,318 652,302" fill="none" stroke="${C.coatLine}" stroke-width="1.8"/>
    <rect x="524" y="424" width="132" height="16" fill="#10191a"/>
    <rect x="579" y="420" width="22" height="24" fill="none" stroke="${C.coatLine}" stroke-width="2.4"/>
    <path d="M590,444 L590,600" fill="none" stroke="${C.coatLine}" stroke-width="1.8"/>
    <path d="M569,212 L611,212 L609,244 C604,254 576,254 571,244 Z" fill="#121819"/>
    <path d="M579,244 h22 v16 h-22 Z" fill="#2a1f19"/>
    <path d="M554,270 L566,234 L590,256 L614,234 L626,270 L590,278 Z" fill="#0d1314" stroke="${C.coatLine}" stroke-width="1.6" stroke-linejoin="round"/>
    <path d="M556,213 C555,188 559,171 569,165 C577,160 584,163 590,168 C596,163 603,160 611,165 C621,171 625,188 624,213 Z" fill="#0a0e0f"/>
    <path d="M556,199 C570,205 610,205 624,199 L624,213 C610,218 570,218 556,213 Z" fill="#1e2a2b"/>
    <path d="M590,169 L590,186" fill="none" stroke="#182223" stroke-width="2" stroke-linecap="round"/>
    <ellipse cx="590" cy="215" rx="64" ry="9.5" transform="rotate(-3 590 215)" fill="#050708"/>
    <path d="M623,199 C623,183 619,170 610,165" fill="none" stroke="${C.cream}" stroke-width="3" stroke-linecap="round" opacity="0.9"/>
    <path d="M636,209 C646,208 653,210 653,212" fill="none" stroke="${C.cream}" stroke-width="2.6" stroke-linecap="round" opacity="0.9"/>
    <path d="M611,222 L609,244" fill="none" stroke="${C.cream}" stroke-width="2.2" stroke-linecap="round" opacity="0.55"/>
    <path d="M626,266 C644,264 658,272 668,286 C680,300 687,352 691,412 C693,452 689,492 679,524" fill="none" stroke="${C.cream}" stroke-width="3" stroke-linecap="round" opacity="0.75"/>
    <path d="M512,286 C500,300 493,352 489,412 C487,452 491,492 501,524" fill="none" stroke="${C.amber}" stroke-width="2.2" stroke-linecap="round" opacity="0.45"/>
    <path d="M557,205 C556,187 560,172 569,166" fill="none" stroke="${C.amber}" stroke-width="2" stroke-linecap="round" opacity="0.4"/>
  </g>`);

  o.push(`<rect width="${W}" height="${H}" fill="url(#vig)"/>`);
  o.push(`<rect width="${W}" height="${H}" fill="url(#topfade)"/>`);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${o.join("\n")}</svg>`;
}

/* ───────── 2. 추리 책상 (위에서 본 책상, 등불 하나) ───────── */
function desk() {
  const W = 780;
  const H = 1688;
  const r = rng(7);
  const o = [];
  o.push(`<defs>
    <radialGradient id="pool" gradientUnits="userSpaceOnUse" cx="390" cy="560" r="900" gradientTransform="translate(390 560) scale(1 1.25) translate(-390 -560)">
      <stop offset="0" stop-color="#7a4d27"/><stop offset="0.28" stop-color="#53331c"/><stop offset="0.6" stop-color="#291a11"/><stop offset="1" stop-color="#0d0a08"/>
    </radialGradient>
    <radialGradient id="hot" gradientUnits="userSpaceOnUse" cx="390" cy="520" r="420">
      <stop offset="0" stop-color="${C.amberLit}" stop-opacity="0.26"/><stop offset="1" stop-color="${C.amber}" stop-opacity="0"/>
    </radialGradient>
  </defs>`);
  o.push(`<rect width="${W}" height="${H}" fill="url(#pool)"/>`);
  // 널 이음매: 넓은 널 다섯 장
  const boards = [0, 300, 640, 960, 1310, H];
  for (let b = 0; b < boards.length - 1; b++) {
    const y0 = boards[b];
    const y1 = boards[b + 1];
    if (b > 0) o.push(`<rect x="0" y="${y0 - 2}" width="${W}" height="4" fill="#070504" opacity="0.7"/><rect x="0" y="${y0 + 2}" width="${W}" height="1.5" fill="#a26a36" opacity="0.14"/>`);
    // 나뭇결: 길고 가는 선
    const count = Math.round((y1 - y0) / 13);
    for (let i = 0; i < count; i++) {
      const y = y0 + 8 + r() * (y1 - y0 - 16);
      const x = r() * W * 0.9 - 60;
      const len = 120 + r() * 420;
      const bend = (r() - 0.5) * 9;
      const dark = r() > 0.42;
      o.push(`<path d="M${n(x)},${n(y)} q${n(len / 2)},${n(bend)} ${n(len)},0" fill="none" stroke="${dark ? "#0a0705" : "#b47a42"}" stroke-width="${n(0.8 + r() * 1.4)}" opacity="${n(dark ? 0.22 + r() * 0.2 : 0.06 + r() * 0.07)}" stroke-linecap="round"/>`);
    }
  }
  // 옹이 셋
  for (const [x, y, s] of [[640, 210, 1], [96, 1120, 1.2], [560, 1480, 0.9]]) {
    o.push(`<g transform="translate(${x} ${y}) scale(${s})" fill="none" stroke="#0a0705" opacity="0.4"><ellipse rx="20" ry="8" stroke-width="2"/><ellipse rx="10" ry="3.5" stroke-width="2"/><path d="M-46,0 q20,-14 46,-13 q26,-1 46,13 q-20,14 -46,13 q-26,1 -46,-13Z" stroke-width="1.4"/></g>`);
  }
  // 컵 자국
  o.push(`<circle cx="668" cy="1250" r="42" fill="none" stroke="#070504" stroke-width="3.5" opacity="0.28"/><path d="M633,1228 a42,42 0 0 1 66,-8" fill="none" stroke="#b47a42" stroke-width="1.5" opacity="0.12"/>`);
  o.push(`<rect width="${W}" height="${H}" fill="url(#hot)"/>`);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${o.join("\n")}</svg>`;
}

/* ───────── 3. 시험실 (밤, 내리비추는 전등 하나) ───────── */
function examroom() {
  const W = 780;
  const H = 440;
  const TOP = 60; // 위 막대(조작부) 뒤로 들어가는 천장 여백
  const o = [];
  o.push(`<defs>
    <linearGradient id="cone" gradientUnits="userSpaceOnUse" x1="0" y1="118" x2="0" y2="440">
      <stop offset="0" stop-color="${C.amberLit}" stop-opacity="0.5"/><stop offset="0.55" stop-color="${C.amber}" stop-opacity="0.2"/><stop offset="1" stop-color="${C.amber}" stop-opacity="0.06"/>
    </linearGradient>
    <linearGradient id="sky2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6ebc6"/><stop offset="1" stop-color="${C.creamDim}"/></linearGradient>
    <radialGradient id="vig2" cx="0.5" cy="0.45" r="0.8"><stop offset="0.45" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.62"/></radialGradient>
    <linearGradient id="ray" gradientUnits="userSpaceOnUse" x1="552" y1="0" x2="376" y2="0"><stop offset="0" stop-color="${C.cream}" stop-opacity="0.2"/><stop offset="1" stop-color="${C.cream}" stop-opacity="0"/></linearGradient>
    <clipPath id="wallclip"><rect x="0" y="0" width="${W}" height="352"/></clipPath>
  </defs>`);
  o.push(`<rect width="${W}" height="${H + TOP}" fill="#0f191a"/>`);
  o.push(`<g transform="translate(0 ${TOP})">`);
  o.push(`<rect x="0" y="${-TOP}" width="${W}" height="${TOP + 4}" fill="#0b1314"/><rect x="0" y="-4" width="${W}" height="4" fill="#162223"/>`);
  // 징두리와 바닥
  o.push(`<rect x="0" y="262" width="${W}" height="90" fill="#0a1112"/><rect x="0" y="260" width="${W}" height="3" fill="${C.rail}"/>`);
  for (let x = 40; x < W; x += 74) o.push(`<rect x="${x}" y="263" width="2" height="89" fill="#101a1b"/>`);
  o.push(`<rect x="0" y="352" width="${W}" height="88" fill="#070a0b"/><rect x="0" y="352" width="${W}" height="3" fill="#162021"/>`);

  // 칠판: 풀다 만 추리가 분필로 남아 있다
  o.push(`<rect x="36" y="58" width="322" height="186" fill="#1b2829"/><rect x="44" y="66" width="306" height="170" fill="#0a1415"/>`);
  o.push(`<g fill="none" stroke="#d9dccf" stroke-linecap="round" opacity="0.5">
    <circle cx="92" cy="118" r="15" stroke-width="2.4"/><circle cx="180" cy="100" r="15" stroke-width="2.4"/><circle cx="268" cy="124" r="15" stroke-width="2.4"/><circle cx="180" cy="186" r="15" stroke-width="2.4"/>
    <path d="M107,115 L165,103 M195,104 L254,120 M180,115 L180,171 M104,128 L167,178" stroke-width="2"/>
    <path d="M292,172 q4,-18 20,-14 q14,6 2,20 q-8,8 -8,16 M306,208 v2" stroke-width="3"/>
    <path d="M62,206 h44 M62,218 h30" stroke-width="2"/>
  </g>`);
  o.push(`<path d="M172,92 l16,16 M188,92 l-16,16" stroke="${C.red}" stroke-width="3.2" stroke-linecap="round" opacity="0.9"/>`);
  o.push(`<rect x="36" y="244" width="322" height="8" fill="#243435"/><rect x="230" y="239" width="30" height="5" fill="#d9dccf" opacity="0.7"/>`);

  // 벽시계
  o.push(`<circle cx="470" cy="92" r="30" fill="#05080a"/><circle cx="470" cy="92" r="24" fill="#c8c2a6" opacity="0.82"/><path d="M470,92 L470,74 M470,92 L483,99" stroke="#05080a" stroke-width="3.4" stroke-linecap="round"/>`);

  // 창과 블라인드, 벽에 비낀 살 무늬 빛
  const wx = 566;
  const wy = 40;
  const ww = 168;
  const wh = 210;
  o.push(`<g clip-path="url(#wallclip)">`);
  for (let i = 0; i < 9; i++) {
    const y = 70 + i * 26;
    o.push(poly([[wx - 14, y], [wx - 14, y + 11], [wx - 190, y + 11 + 96], [wx - 190, y + 96]], `fill="url(#ray)"`));
  }
  o.push(`</g>`);
  o.push(`<rect x="${wx - 8}" y="${wy - 8}" width="${ww + 16}" height="${wh + 16}" fill="#05080a"/><rect x="${wx}" y="${wy}" width="${ww}" height="${wh}" fill="url(#sky2)"/>`);
  for (let i = 0; i < 13; i++) o.push(`<rect x="${wx}" y="${n(wy + i * (wh / 13))}" width="${ww}" height="${n((wh / 13) * 0.62)}" fill="#070b0c"/>`);
  o.push(`<rect x="${wx + ww / 2 - 2}" y="${wy}" width="4" height="${wh}" fill="#070b0c"/><rect x="${wx - 14}" y="${wy + wh + 8}" width="${ww + 28}" height="8" fill="#182223"/>`);

  // 전등과 빛
  const lx = 390;
  o.push(`<rect x="${lx - 1.5}" y="${-TOP}" width="3" height="${96 + TOP}" fill="#1a2526"/>`);
  o.push(poly([[lx - 34, 118], [lx + 34, 118], [lx + 238, H], [lx - 238, H]], `fill="url(#cone)"`));
  o.push(poly([[lx - 12, 94], [lx + 12, 94], [lx + 38, 120], [lx - 38, 120]], `fill="#05080a"`));
  o.push(`<rect x="${lx - 34}" y="116" width="68" height="5" fill="${C.amberLit}"/>`);

  // 응시자 책상과 의자: 빛이 닿는 자리
  o.push(`<ellipse cx="${lx}" cy="396" rx="220" ry="34" fill="${C.amber}" opacity="0.16"/>`);
  o.push(`<g fill="#05080a"><rect x="${lx - 40}" y="250" width="7" height="76"/><rect x="${lx + 33}" y="250" width="7" height="76"/><rect x="${lx - 40}" y="254" width="80" height="12"/><rect x="${lx - 40}" y="278" width="80" height="8"/><rect x="${lx - 40}" y="298" width="80" height="8"/></g>`);
  o.push(`<rect x="${lx - 150}" y="322" width="300" height="16" fill="#3a2414"/><rect x="${lx - 150}" y="322" width="300" height="4" fill="#8a5a2c"/>`);
  o.push(`<rect x="${lx - 138}" y="338" width="14" height="80" fill="#1a110a"/><rect x="${lx + 124}" y="338" width="14" height="80" fill="#1a110a"/><rect x="${lx - 150}" y="338" width="300" height="20" fill="#24170d"/>`);
  o.push(poly([[lx - 40, 322], [lx + 28, 322], [lx + 36, 312], [lx - 30, 312]], `fill="#ece6d6"`));
  o.push(`<circle cx="${lx}" cy="317" r="4.5" fill="${C.red}"/>`);

  o.push(`</g>`);
  o.push(`<rect width="${W}" height="${H + TOP}" fill="url(#vig2)"/>`);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H + TOP}" width="${W}" height="${H + TOP}">${o.join("\n")}</svg>`;
}

const SCENES = { corridor, desk, examroom };
const only = process.argv.slice(2).filter((a) => !a.startsWith("--"));
for (const [name, draw] of Object.entries(SCENES)) {
  if (only.length && !only.includes(name)) continue;
  const svg = draw();
  writeFileSync(new URL(`${name}.svg`, OUT), svg);
  console.log("wrote", name, `${(svg.length / 1024).toFixed(1)}KB`);
}
