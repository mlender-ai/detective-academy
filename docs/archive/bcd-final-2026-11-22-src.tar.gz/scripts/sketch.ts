/**
 * 손으로 그은 듯한 펜선을 만드는 작은 도구.
 * 같은 seed 는 항상 같은 선을 만든다(다시 그려도 그림이 바뀌지 않는다).
 * 선은 끝에서 살짝 더 나가고(overshoot), 가운데가 조금 휘고, 두 번 겹쳐 긋는다.
 */

export type Rng = () => number;

/** mulberry32 */
export function rng(seed: number): Rng {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface SketchOptions {
  seed?: number;
  /** 흔들림 크기(px) */
  wobble?: number;
  /** 끝점에서 더 나가는 길이(px) */
  over?: number;
  /** 겹쳐 긋는 횟수 */
  passes?: number;
}

const f = (n: number) => (Math.round(n * 10) / 10).toString();

function stroke(r: Rng, x1: number, y1: number, x2: number, y2: number, wobble: number, over: number): string {
  const len = Math.hypot(x2 - x1, y2 - y1) || 1;
  const ux = (x2 - x1) / len;
  const uy = (y2 - y1) / len;
  const nx = -uy;
  const ny = ux;
  const jitter = () => (r() - 0.5) * 2 * wobble;
  const o1 = over * (0.35 + r() * 0.9);
  const o2 = over * (0.35 + r() * 0.9);
  const sx = x1 - ux * o1 + jitter() * 0.6;
  const sy = y1 - uy * o1 + jitter() * 0.6;
  const ex = x2 + ux * o2 + jitter() * 0.6;
  const ey = y2 + uy * o2 + jitter() * 0.6;
  const bow = (r() - 0.5) * Math.min(len * 0.018, wobble * 2.6);
  const b1 = bow + jitter() * 0.7;
  const b2 = bow + jitter() * 0.7;
  const c1x = sx + (ex - sx) * 0.34 + nx * b1;
  const c1y = sy + (ey - sy) * 0.34 + ny * b1;
  const c2x = sx + (ex - sx) * 0.68 + nx * b2;
  const c2y = sy + (ey - sy) * 0.68 + ny * b2;
  return `M${f(sx)} ${f(sy)}C${f(c1x)} ${f(c1y)} ${f(c2x)} ${f(c2y)} ${f(ex)} ${f(ey)}`;
}

function resolve(options: SketchOptions) {
  return {
    r: rng(options.seed ?? 1),
    wobble: options.wobble ?? 0.9,
    over: options.over ?? 3,
    passes: options.passes ?? 2,
  };
}

/** 직선 하나 */
export function line(x1: number, y1: number, x2: number, y2: number, options: SketchOptions = {}): string {
  const { r, wobble, over, passes } = resolve(options);
  let d = "";
  for (let i = 0; i < passes; i++) d += stroke(r, x1, y1, x2, y2, wobble, over);
  return d;
}

/** 꺾은선. close 면 처음 점으로 돌아온다. 모서리마다 선이 서로 지나친다. */
export function poly(points: [number, number][], options: SketchOptions & { close?: boolean } = {}): string {
  const { r, wobble, over, passes } = resolve(options);
  const pts = options.close ? [...points, points[0]] : points;
  let d = "";
  for (let p = 0; p < passes; p++) {
    for (let i = 0; i < pts.length - 1; i++) {
      d += stroke(r, pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], wobble, over);
    }
  }
  return d;
}

/** 사각형: 네 변을 따로 긋는다 */
export function rect(x: number, y: number, w: number, h: number, options: SketchOptions = {}): string {
  return poly(
    [
      [x, y],
      [x + w, y],
      [x + w, y + h],
      [x, y + h],
    ],
    { ...options, close: true },
  );
}

/** 부드러운 곡선으로 잇는다 (Catmull-Rom → 3차 베지에) */
function smooth(points: [number, number][]): string {
  let d = `M${f(points[0][0])} ${f(points[0][1])}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(0, i - 1)];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[Math.min(points.length - 1, i + 2)];
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += `C${f(c1x)} ${f(c1y)} ${f(c2x)} ${f(c2y)} ${f(p2[0])} ${f(p2[1])}`;
  }
  return d;
}

/**
 * 손으로 돌려 그린 타원. 한 바퀴보다 조금 더 돌아서 시작과 끝이 겹친다.
 * turns: 도는 바퀴 수 (1.08 이면 살짝 겹침)
 */
export function ellipse(
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  options: SketchOptions & { turns?: number; start?: number } = {},
): string {
  const { r, wobble, passes } = resolve(options);
  const turns = options.turns ?? 1.08;
  let d = "";
  for (let p = 0; p < passes; p++) {
    const start = (options.start ?? -2.2) + (r() - 0.5) * 0.5;
    const steps = Math.max(10, Math.round(14 * turns));
    const drift = (r() - 0.5) * 0.08;
    const points: [number, number][] = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const a = start + t * turns * Math.PI * 2;
      const k = 1 + drift * (t - 0.5) * 2 + ((r() - 0.5) * wobble) / Math.max(rx, ry);
      points.push([cx + Math.cos(a) * rx * k, cy + Math.sin(a) * ry * k]);
    }
    d += smooth(points);
  }
  return d;
}

/** 자유 곡선: 주어진 점을 조금씩 흔들어 부드럽게 잇는다 */
export function curve(points: [number, number][], options: SketchOptions = {}): string {
  const { r, wobble, passes } = resolve(options);
  let d = "";
  for (let p = 0; p < passes; p++) {
    d += smooth(points.map(([x, y]) => [x + (r() - 0.5) * wobble, y + (r() - 0.5) * wobble]));
  }
  return d;
}

/** 빗금: 사각형 안을 45도 선으로 채운다. flip 이면 반대 방향. */
export function hatch(
  x: number,
  y: number,
  w: number,
  h: number,
  options: SketchOptions & { gap?: number; flip?: boolean } = {},
): string {
  const { r, wobble } = resolve(options);
  const gap = options.gap ?? 5;
  let d = "";
  for (let o = gap * 0.5; o < w + h; o += gap * (0.8 + r() * 0.4)) {
    // 왼쪽 아래에서 오른쪽 위로 가는 선을 사각형에 맞춰 자른다
    let x1 = x + o - h;
    let y1 = y + h;
    let x2 = x + o;
    let y2 = y;
    if (x1 < x) {
      y1 -= x - x1;
      x1 = x;
    }
    if (x2 > x + w) {
      y2 += x2 - (x + w);
      x2 = x + w;
    }
    if (options.flip) {
      x1 = x + w - (x1 - x);
      x2 = x + w - (x2 - x);
    }
    const shorten = r() * 0.12;
    const mx1 = x1 + (x2 - x1) * shorten;
    const my1 = y1 + (y2 - y1) * shorten;
    d += stroke(r, mx1, my1, x2, y2, wobble * 0.7, 0);
  }
  return d;
}

/** 체크 표시 */
export function check(x: number, y: number, size: number, options: SketchOptions = {}): string {
  return poly(
    [
      [x, y + size * 0.52],
      [x + size * 0.36, y + size * 0.9],
      [x + size, y + size * 0.08],
    ],
    { wobble: 0.6, over: 1.2, passes: 1, ...options },
  );
}

/** 가위표 */
export function cross(x: number, y: number, size: number, options: SketchOptions = {}): string {
  const o = { wobble: 0.7, over: 1.5, passes: 1, ...options };
  return line(x, y, x + size, y + size, o) + line(x + size, y, x, y + size, { ...o, seed: (o.seed ?? 1) + 7 });
}

/** 밑줄: 살짝 물결치는 한 줄 */
export function underline(x: number, y: number, w: number, options: SketchOptions = {}): string {
  const { r, wobble } = resolve(options);
  const points: [number, number][] = [];
  const steps = Math.max(3, Math.round(w / 26));
  for (let i = 0; i <= steps; i++) {
    points.push([x + (w * i) / steps, y + (r() - 0.5) * wobble * 2]);
  }
  return smooth(points);
}
