// 픽셀 배경을 격자에 직접 찍어 PNG 로 굽는다 (원화를 변환하지 않는다).
//   node scripts/pixel-bg.mjs [corridor|desk|examroom ...] [--preview <폴더>]
// 점 하나가 화면의 2px 이 되도록, 결과 PNG 는 점 크기의 두 배로 저장한다(화면에서는 늘이지 않고 그대로 놓는다).
// 색 띠 사이는 4×4 격자 점묘(Bayer)로 잇는다. 난수는 seed 가 고정이라 다시 구워도 같은 그림이 나온다.
import { chromium } from "@playwright/test";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const OUT = resolve(dirname(fileURLToPath(import.meta.url)), "../src/assets/art");

/* ───────── 격자에 그리는 도구 ───────── */

const BAYER = [
  [0, 8, 2, 10],
  [12, 4, 14, 6],
  [3, 11, 1, 9],
  [15, 7, 13, 5],
];
/** 점묘: amount(0~1)만큼의 점이 켜진다 */
const dth = (x, y, amount) => (BAYER[y & 3][x & 3] + 0.5) / 16 < amount;

/** 여러 색을 t(0~1)에 따라 점묘로 잇는 색 고르기 */
const ramp = (colors) => (x, y, t) => {
  const f = Math.max(0, Math.min(0.9999, t)) * (colors.length - 1);
  const i = Math.floor(f);
  return dth(x, y, f - i) ? colors[i + 1] : colors[i];
};

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

class Grid {
  constructor(w, h, fill) {
    this.w = w;
    this.h = h;
    this.px = new Array(w * h).fill(fill);
  }
  set(x, y, c) {
    x = Math.round(x);
    y = Math.round(y);
    if (c == null || x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    this.px[y * this.w + x] = c;
  }
  get(x, y) {
    x = Math.round(x);
    y = Math.round(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return null;
    return this.px[y * this.w + x];
  }
  /** c 는 색, 또는 (x, y) => 색|null */
  rect(x, y, w, h, c) {
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, typeof c === "function" ? c(Math.round(x + i), Math.round(y + j)) : c);
  }
  line(x0, y0, x1, y1, c) {
    x0 = Math.round(x0);
    y0 = Math.round(y0);
    x1 = Math.round(x1);
    y1 = Math.round(y1);
    const dx = Math.abs(x1 - x0);
    const dy = -Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1;
    const sy = y0 < y1 ? 1 : -1;
    let err = dx + dy;
    for (;;) {
      this.set(x0, y0, typeof c === "function" ? c(x0, y0) : c);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 >= dy) {
        err += dy;
        x0 += sx;
      }
      if (e2 <= dx) {
        err += dx;
        y0 += sy;
      }
    }
  }
  poly(points, c) {
    const ys = points.map((p) => p[1]);
    for (let y = Math.floor(Math.min(...ys)); y <= Math.ceil(Math.max(...ys)); y++) {
      const xs = [];
      const sy = y + 0.5;
      for (let i = 0; i < points.length; i++) {
        const [x1, y1] = points[i];
        const [x2, y2] = points[(i + 1) % points.length];
        if (y1 <= sy === y2 <= sy) continue;
        xs.push(x1 + ((sy - y1) / (y2 - y1)) * (x2 - x1));
      }
      xs.sort((a, b) => a - b);
      for (let i = 0; i + 1 < xs.length; i += 2) {
        for (let x = Math.round(xs[i]); x < Math.round(xs[i + 1]); x++) this.set(x, y, typeof c === "function" ? c(x, y) : c);
      }
    }
  }
  oval(cx, cy, rx, ry, c) {
    for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++) {
      for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        const dx = (x + 0.5 - cx) / rx;
        const dy = (y + 0.5 - cy) / ry;
        if (dx * dx + dy * dy <= 1) this.set(x, y, typeof c === "function" ? c(x, y) : c);
      }
    }
  }
  /** 테두리만 있는 타원 */
  ring(cx, cy, rx, ry, c) {
    for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++) {
      for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        const dx = (x + 0.5 - cx) / rx;
        const dy = (y + 0.5 - cy) / ry;
        const v = dx * dx + dy * dy;
        const ix = (x + 0.5 - cx) / (rx - 1);
        const iy = (y + 0.5 - cy) / (ry - 1);
        if (v <= 1 && ix * ix + iy * iy > 1) this.set(x, y, c);
      }
    }
  }
}

/* ───────── 학원 복도: 한 점으로 모이는 긴 복도 ─────────
   왼쪽 벽에 교실 문, 오른쪽 벽에 높은 창, 끝에 양문과 학원 문장. 창으로 든 빛이 마루에 떨어진다. */

function corridor() {
  const W = 240;
  const H = 160;
  const C = {
    ink: "#1c1722",
    dk: "#33262a",
    ceil: ["#5a504d", "#6f6459", "#857968", "#9a8d76"],
    wallL: ["#a4947a", "#bdad8c", "#d3c49f", "#e3d6b2"],
    wallR: ["#665b56", "#7b6f65", "#8f8373", "#a39782"],
    wainL: ["#542732", "#6c343a", "#864744"],
    wainR: ["#3f1c27", "#522630", "#663238"],
    rail: "#3a1a24",
    wood: ["#4a3228", "#63402e", "#86583a", "#a8764a"],
    floor: ["#7c5a38", "#95703f", "#b0854f", "#c9a06a"],
    lit: "#e8cb86",
    hot: "#fbeab0",
    glass: ["#d8c98f", "#f0dfa4", "#fff6d2"],
    pane: "#aebcb2",
    far: "#e9ddb9",
    brass: ["#9a6f2c", "#d9ab4f", "#f6dd92"],
    wine: "#8c2f39",
    paper: "#fff8e7",
  };
  const g = new Grid(W, H, C.ink);
  // 복도 끝의 벽
  const FL = 100;
  const FR = 140;
  const FT = 44;
  const FB = 84;
  // 깊이 z(1 = 화면 가장자리, 커질수록 멀다)에서의 자리
  const k = (z) => 1 - 1 / z;
  const xl = (z) => FL * k(z);
  const xr = (z) => W - FL * k(z);
  const cy = (z) => FT * k(z);
  const fy = (z) => H - (H - FB) * k(z);
  const wy = (z, u) => cy(z) + u * (fy(z) - cy(z));
  const L = (z, u) => [xl(z), wy(z, u)];
  const R = (z, u) => [xr(z), wy(z, u)];
  const F = (z, s) => [xl(z) + s * (xr(z) - xl(z)), fy(z)];
  const Ce = (z, s) => [xl(z) + s * (xr(z) - xl(z)), cy(z)];
  const FAR = 1e6;

  /* 면 */
  const ceil = ramp(C.ceil);
  g.poly([[0, 0], [W, 0], [FR, FT], [FL, FT]], (x, y) => ceil(x, y, y / FT));
  const wallL = ramp(C.wallL);
  g.poly([[0, 0], [FL, FT], [FL, FB], [0, H]], (x, y) => wallL(x, y, x / FL));
  const wallR = ramp(C.wallR);
  g.poly([[W, 0], [FR, FT], [FR, FB], [W, H]], (x, y) => wallR(x, y, (W - x) / FL));
  const floor = ramp(C.floor);
  g.poly([[0, H], [W, H], [FR, FB], [FL, FB]], (x, y) => floor(x, y, 0.15 + (0.85 * (H - y)) / (H - FB)));
  g.rect(FL, FT, FR - FL, FB - FT, C.far);

  /* 징두리 널 */
  const U = 0.62;
  const wainL = ramp(C.wainL);
  g.poly([L(1, U), L(FAR, U), L(FAR, 1), L(1, 1)], (x, y) => wainL(x, y, x / FL));
  const wainR = ramp(C.wainR);
  g.poly([R(1, U), R(FAR, U), R(FAR, 1), R(1, 1)], (x, y) => wainR(x, y, (W - x) / FL));
  g.rect(FL, Math.round(wy(FAR, U)), FR - FL, FB - Math.round(wy(FAR, U)), C.wainL[2]);
  for (const z of [1.18, 1.45, 1.85, 2.4, 3.2, 4.4, 6.2, 9]) {
    g.line(...L(z, U + 0.03), ...L(z, 0.985), C.rail);
    g.line(...R(z, U + 0.03), ...R(z, 0.985), C.rail);
  }
  // 허리 몰딩과 걸레받이
  for (const [P, light] of [[L, C.wainL[2]], [R, C.wainR[2]]]) {
    g.line(...P(1, U), ...P(FAR, U), C.rail);
    g.line(...P(1, U + 0.022), ...P(FAR, U + 0.006), light);
    g.line(...P(1, 0.97), ...P(FAR, 0.99), C.rail);
  }

  /* 왼쪽 벽: 교실 문 */
  for (const [za, zb] of [[1.1, 1.78], [2.3, 3.15], [3.95, 5], [6.1, 7.4], [9, 11]]) {
    const d = (zb - za) * 0.1;
    g.poly([L(za, 0.15), L(zb, 0.15), L(zb, 1), L(za, 1)], C.wood[0]);
    g.poly([L(za + d, 0.2), L(zb - d, 0.2), L(zb - d, 1), L(za + d, 1)], (x, y) => (dth(x, y, 0.3) ? C.wood[1] : C.wood[2]));
    // 유리창과 아래 널
    g.poly([L(za + d * 2.2, 0.26), L(zb - d * 2.2, 0.26), L(zb - d * 2.2, 0.55), L(za + d * 2.2, 0.55)], (x, y) => (dth(x, y, 0.35) ? C.glass[0] : C.pane));
    g.poly([L(za + d * 2.2, 0.66), L(zb - d * 2.2, 0.66), L(zb - d * 2.2, 0.93), L(za + d * 2.2, 0.93)], C.wood[1]);
    g.line(...L(za + d * 2.2, 0.26), ...L(zb - d * 2.2, 0.26), C.wood[0]);
    g.line(...L(za + d * 2.2, 0.405), ...L(zb - d * 2.2, 0.405), C.wood[0]);
    // 문틀 위의 처마와 손잡이
    g.line(...L(za - d * 0.6, 0.14), ...L(zb + d * 0.6, 0.14), C.wood[1]);
    const knob = L(zb - d * 1.6, 0.61);
    g.set(knob[0], knob[1], C.brass[2]);
    if (zb - za > 0.6) g.set(knob[0], knob[1] + 1, C.brass[1]);
  }

  /* 오른쪽 벽: 높은 창 */
  for (const [za, zb] of [[1.06, 1.72], [2.02, 2.9], [3.4, 4.4], [5.2, 6.6], [8, 10]]) {
    const d = (zb - za) * 0.09;
    g.poly([R(za, 0.09), R(zb, 0.09), R(zb, 0.585), R(za, 0.585)], C.wood[0]);
    g.poly([R(za + d, 0.12), R(zb - d, 0.12), R(zb - d, 0.55), R(za + d, 0.55)], (x, y) => {
      const t = (y - wy(za, 0.12)) / Math.max(1, wy(za, 0.55) - wy(za, 0.12));
      return dth(x, y, 0.2 + t * 0.7) ? C.glass[1] : C.glass[2];
    });
    const zm = (za + zb) / 2;
    g.line(...R(zm, 0.12), ...R(zm, 0.55), C.wood[1]);
    g.line(...R(za + d, 0.3), ...R(zb - d, 0.3), C.wood[1]);
    // 창턱
    g.line(...R(za - d * 0.5, 0.59), ...R(zb + d * 0.5, 0.59), C.wallR[3]);
    g.line(...R(za - d * 0.5, 0.605), ...R(zb + d * 0.5, 0.605), C.wallR[0]);
  }

  /* 마루: 창으로 든 빛, 널 이음 */
  for (const [za, zb] of [[1.06, 1.72], [2.02, 2.9], [3.4, 4.4], [5.2, 6.6], [8, 10]]) {
    const lean = 0.2;
    g.poly([F(za * (1 + lean), 0.34), F(za, 0.99), F(zb, 0.99), F(zb * (1 + lean), 0.34)], (x, y) => (dth(x, y, 0.72) ? C.lit : null));
    g.poly([F(za * (1 + lean * 0.5), 0.62), F(za, 0.99), F(zb, 0.99), F(zb * (1 + lean * 0.5), 0.62)], (x, y) => (dth(x, y, 0.45) ? C.hot : C.lit));
  }
  const lit = new Set([C.lit, C.hot]);
  for (let i = 1; i < 12; i++) {
    const s = i / 12;
    g.line(...F(1, s), ...F(FAR, s), (x, y) => (lit.has(g.get(x, y)) ? C.floor[3] : C.floor[0]));
  }
  const r = rng(7);
  for (let i = 0; i < 26; i++) {
    const s = Math.floor(r() * 12) / 12;
    const z = 1 + r() * r() * 5;
    g.line(...F(z, s), ...F(z, s + 1 / 12), (x, y) => (lit.has(g.get(x, y)) ? C.floor[3] : C.floor[0]));
  }

  /* 천장: 가로 들보 */
  for (const z of [1.22, 1.6, 2.3, 3.6, 6]) {
    g.line(...Ce(z, 0), ...Ce(z, 1), C.ceil[0]);
    const [x0, y0] = Ce(z, 0);
    const [x1] = Ce(z, 1);
    g.line(x0, y0 + 1, x1, y0 + 1, C.ceil[3]);
  }

  /* 복도 끝: 양문과 학원 문장 */
  g.rect(FL, FT, FR - FL, 1, C.ceil[1]);
  g.rect(110, 55, 20, 29, C.wood[0]);
  g.rect(112, 57, 7, 27, C.wood[2]);
  g.rect(121, 57, 7, 27, C.wood[2]);
  g.rect(113, 59, 5, 9, C.glass[2]);
  g.rect(122, 59, 5, 9, C.glass[2]);
  g.rect(113, 63, 5, 1, C.wood[1]);
  g.rect(122, 63, 5, 1, C.wood[1]);
  g.set(118, 72, C.brass[2]);
  g.set(121, 72, C.brass[2]);
  g.poly([[117, 46], [123, 46], [123, 50], [120, 53], [117, 50]], C.wine);
  g.set(120, 48, C.paper);
  g.set(119, 48, C.paper);
  g.rect(108, 53, 24, 1, C.wood[1]);
  // 끝 문으로 새는 빛
  g.poly([[112, 84], [128, 84], [134, 90], [106, 90]], (x, y) => (dth(x, y, 0.6) ? C.hot : C.lit));

  /* 모서리 선 */
  g.line(0, 0, FL, FT, C.dk);
  g.line(W - 1, 0, FR - 1, FT, C.dk);
  g.line(0, H - 1, FL, FB, C.dk);
  g.line(W - 1, H - 1, FR - 1, FB, C.dk);
  g.rect(FL, FT, 1, FB - FT, C.dk);
  g.rect(FR - 1, FT, 1, FB - FT, C.dk);
  g.rect(FL, FB, FR - FL, 1, C.dk);

  /* 늘어뜨린 전등 */
  const lamp = (z, cord, top, bottom, tall) => {
    const yc = Math.round(cy(z));
    const x = 120;
    g.rect(x, yc, 1, cord, C.ink);
    const y0 = yc + cord;
    for (let j = 0; j < tall; j++) {
      const w = Math.round(top + ((bottom - top) * j) / Math.max(1, tall - 1));
      const x0 = x - Math.floor(w / 2);
      g.rect(x0, y0 + j, w, 1, C.brass[1]);
      g.set(x0, y0 + j, C.brass[2]);
      g.set(x0 + w - 1, y0 + j, C.brass[0]);
    }
    const wb = bottom + 2;
    g.rect(x - Math.floor(wb / 2), y0 + tall, wb, 1, C.brass[0]);
    g.rect(x - Math.floor(bottom / 4), y0 + tall + 1, Math.max(1, Math.round(bottom / 2)), Math.max(1, Math.round(tall / 3)), C.hot);
    return [x, y0 + tall + 1];
  };
  lamp(2.7, 6, 3, 8, 3);
  lamp(1.2, 11, 5, 15, 6);

  return { name: "corridor-dot", grid: g };
}

/* ───────── 추리 책상: 위에서 내려다본 나무 책상 ─────────
   세로로 긴 널빤지. 위아래로 이어 붙여도 이음매가 보이지 않는다(화면 높이만큼 반복해 깐다). */

function desk() {
  const W = 240;
  const H = 240;
  const C = {
    seam: "#3f2a22",
    edge: "#5a3d2b",
    tone: [
      ["#7a5236", "#8a6040", "#9a6e49"],
      ["#84593a", "#946845", "#a4764f"],
      ["#70492f", "#805739", "#906543"],
    ],
    lit: "#ac7e54",
    knot: "#4a3228",
  };
  const g = new Grid(W, H, C.seam);
  const r = rng(21);
  // 널빤지: 너비가 조금씩 다르다
  const planks = [];
  let x = 0;
  const widths = [34, 30, 38, 32, 36, 30, 40];
  for (let i = 0; x < W; i++) {
    const w = Math.min(widths[i % widths.length], W - x);
    planks.push({ x, w, tone: C.tone[[0, 1, 2, 1, 0, 2, 1][i % 7]] });
    x += w;
  }
  for (const plank of planks) {
    const [dark, mid, light] = plank.tone;
    // 바탕과 은은한 색 띠
    const phase = r() * 6;
    g.rect(plank.x, 0, plank.w, H, (px, py) => {
      const band = Math.sin((py / H) * Math.PI * 2 + phase) * 0.5 + 0.5;
      return dth(px, py, 0.12 + band * 0.2) ? light : mid;
    });
    // 나뭇결: 세로로 긴 줄. 위아래 끝이 이어지도록 감아서 찍는다
    const streaks = 5 + Math.floor(r() * 4);
    for (let i = 0; i < streaks; i++) {
      const sx = plank.x + 2 + Math.floor(r() * (plank.w - 4));
      const sy = Math.floor(r() * H);
      const len = 18 + Math.floor(r() * 70);
      const tone = r() < 0.62 ? dark : C.lit;
      let dx = 0;
      for (let j = 0; j < len; j++) {
        if (r() < 0.06) dx += r() < 0.5 ? -1 : 1;
        dx = Math.max(-2, Math.min(2, dx));
        const px = Math.max(plank.x + 1, Math.min(plank.x + plank.w - 2, sx + dx));
        if (j < 2 || j > len - 3 ? dth(px, (sy + j) % H, 0.5) : true) g.set(px, (sy + j) % H, tone);
      }
    }
    // 이음매: 왼쪽은 어두운 틈, 그 옆은 밝은 모서리
    g.rect(plank.x, 0, 1, H, C.seam);
    g.rect(plank.x + 1, 0, 1, H, (px, py) => (dth(px, py, 0.5) ? light : mid));
    g.rect(plank.x + plank.w - 1, 0, 1, H, C.edge);
    // 널빤지 끝이 맞닿는 가로 이음
    if (r() < 0.75) {
      const jy = 12 + Math.floor(r() * (H - 24));
      g.rect(plank.x + 1, jy, plank.w - 1, 1, C.seam);
      g.rect(plank.x + 1, jy + 1, plank.w - 2, 1, (px, py) => (dth(px, py, 0.6) ? light : mid));
      g.set(plank.x + 4, jy - 3, C.seam);
      g.set(plank.x + plank.w - 5, jy - 3, C.seam);
      g.set(plank.x + 4, jy + 4, C.seam);
      g.set(plank.x + plank.w - 5, jy + 4, C.seam);
    }
  }
  // 옹이
  for (const [kx, ky, kr] of [[52, 58, 4], [171, 142, 5], [118, 176, 3]]) {
    g.ring(kx, ky, kr + 3, kr + 5, C.edge);
    g.ring(kx, ky, kr + 1, kr + 2.5, C.seam);
    g.oval(kx, ky, kr - 1, kr, C.knot);
    g.set(kx - 1, ky - 1, C.edge);
  }
  return { name: "desk-dot", grid: g };
}

/* ───────── 시험실: 응시자 자리에서 올려다본 정면 벽 ─────────
   화면에는 위쪽만 보이므로(아래는 책상에 가려진다) 칠판·시계·창·깃발을 위에 모은다. */

function examroom() {
  const W = 240;
  const H = 128;
  const C = {
    ink: "#1c1722",
    dk: "#33262a",
    wall: ["#8f8373", "#a89b84", "#bfb296", "#d3c7a6"],
    mold: "#6f6458",
    wain: ["#522630", "#6c343a", "#864744"],
    rail: "#3a1a24",
    wood: ["#4a3228", "#63402e", "#86583a", "#a8764a"],
    board: ["#22342e", "#2c443b", "#375348"],
    chalk: "#e9e2c9",
    chalkDim: "#9fb0a2",
    glass: ["#d8c98f", "#f0dfa4", "#fff6d2"],
    sky: "#cfe0d6",
    brass: ["#9a6f2c", "#d9ab4f", "#f6dd92"],
    wine: ["#5c1f2b", "#8c2f39", "#b5454f"],
    paper: "#fff8e7",
    hot: "#fbeab0",
  };
  const g = new Grid(W, H, C.ink);
  const WAIN = 92;

  /* 벽: 위는 어둡고 창 쪽이 밝다 */
  const wall = ramp(C.wall);
  g.rect(0, 0, W, WAIN, (x, y) => {
    const fromWindow = Math.max(0, 1 - Math.hypot(x - 56, (y - 50) * 1.4) / 150);
    return wall(x, y, 0.18 + 0.55 * fromWindow + 0.2 * (y / WAIN));
  });
  // 천장 몰딩
  g.rect(0, 0, W, 3, C.mold);
  g.rect(0, 3, W, 1, C.dk);
  g.rect(0, 4, W, 1, C.wall[3]);

  /* 징두리 널 */
  const wain = ramp(C.wain);
  g.rect(0, WAIN, W, H - WAIN, (x, y) => wain(x, y, 0.75 - (y - WAIN) / (H - WAIN) * 0.6));
  g.rect(0, WAIN, W, 1, C.rail);
  g.rect(0, WAIN + 1, W, 1, C.wain[2]);
  g.rect(0, WAIN + 3, W, 1, C.rail);
  for (let x = 10; x < W; x += 22) {
    g.rect(x, WAIN + 6, 1, H - WAIN - 6, C.rail);
    g.rect(x + 3, WAIN + 8, 16, 1, C.rail);
    g.rect(x + 3, WAIN + 8, 1, H - WAIN - 10, C.rail);
    g.rect(x + 18, WAIN + 8, 1, H - WAIN - 10, C.wain[2]);
  }

  /* 높은 창 (왼쪽). 화면 폭이 좁으면 좌우 25점쯤이 잘리므로 주요 물건은 가운데 180점 안에 둔다. */
  const WX = 32;
  g.rect(WX, 12, 42, 72, C.wood[0]);
  g.rect(WX + 3, 15, 36, 66, (x, y) => (dth(x, y, 0.15 + ((y - 15) / 66) * 0.7) ? C.glass[1] : C.glass[2]));
  g.rect(WX + 3, 15, 36, 20, (x, y) => (dth(x, y, 0.5 - ((y - 15) / 20) * 0.5) ? C.sky : null));
  g.rect(WX + 20, 15, 2, 66, C.wood[1]);
  g.rect(WX + 3, 36, 36, 2, C.wood[1]);
  g.rect(WX + 3, 58, 36, 2, C.wood[1]);
  // 창밖 나뭇가지
  g.line(WX + 5, 54, WX + 15, 40, C.wood[2]);
  g.line(WX + 15, 40, WX + 18, 26, C.wood[2]);
  g.line(WX + 11, 46, WX + 6, 40, C.wood[2]);
  g.line(WX + 25, 50, WX + 36, 44, C.wood[2]);
  // 창턱
  g.rect(WX - 3, 84, 48, 2, C.wall[3]);
  g.rect(WX - 3, 86, 48, 1, C.mold);

  /* 칠판 */
  const BX = 84;
  const BW = 88;
  g.rect(BX, 26, BW, 58, C.wood[0]);
  g.rect(BX + 1, 27, BW - 2, 56, C.wood[2]);
  g.rect(BX + 1, 27, BW - 2, 1, C.wood[3]);
  g.rect(BX + 4, 30, BW - 8, 50, (x, y) => {
    const smear = Math.sin(x * 0.11 + y * 0.07) * 0.5 + 0.5;
    return dth(x, y, smear * 0.55) ? C.board[2] : dth(x, y, 0.3) ? C.board[0] : C.board[1];
  });
  // 분필 글씨 자리: 줄과 도형만 (글자는 넣지 않는다)
  const dash = (x, y, w) => g.rect(x, y, w, 1, (px, py) => (dth(px, py, 0.82) ? C.chalk : C.chalkDim));
  dash(BX + 9, 37, 36);
  dash(BX + 9, 42, 24);
  dash(BX + 9, 47, 40);
  for (const cx of [BX + 16, BX + 36, BX + 56]) g.ring(cx, 64, 6, 5, C.chalk);
  g.rect(BX + 22, 64, 8, 1, C.chalk);
  g.rect(BX + 42, 64, 8, 1, C.chalk);
  g.rect(BX + 58, 36, 20, 1, C.chalk);
  g.rect(BX + 58, 36, 1, 13, C.chalk);
  g.rect(BX + 77, 36, 1, 13, C.chalk);
  g.rect(BX + 58, 48, 20, 1, C.chalk);
  g.rect(BX + 62, 42, 12, 1, C.chalkDim);
  // 분필 받침과 분필, 지우개
  g.rect(BX - 2, 84, BW + 4, 2, C.wood[3]);
  g.rect(BX - 2, 86, BW + 4, 1, C.wood[0]);
  g.rect(BX + 10, 83, 6, 1, C.paper);
  g.rect(BX + 20, 83, 4, 1, C.chalkDim);
  g.rect(BX + 66, 81, 12, 3, C.wood[1]);
  g.rect(BX + 66, 81, 12, 1, C.wall[3]);

  /* 벽시계 (칠판 위) */
  const CX = BX + BW / 2;
  g.oval(CX, 14, 9, 9, C.wood[0]);
  g.oval(CX, 14, 8, 8, C.brass[1]);
  g.oval(CX, 14, 6.5, 6.5, C.paper);
  for (const [dx, dy] of [[0, -5], [5, 0], [0, 5], [-5, 0]]) g.set(CX + dx - 0.5, 14 + dy - 0.5, C.ink);
  g.rect(CX - 1, 9, 1, 5, C.ink);
  g.rect(CX - 1, 13, 4, 1, C.ink);
  g.set(CX - 1, 13, C.wine[1]);

  /* 학원 깃발 (오른쪽) */
  const FX = 180;
  g.rect(FX - 4, 14, 36, 2, C.brass[1]);
  g.rect(FX - 4, 16, 36, 1, C.brass[0]);
  g.set(FX - 5, 14, C.brass[2]);
  g.set(FX + 32, 14, C.brass[2]);
  g.poly([[FX, 17], [FX + 28, 17], [FX + 28, 60], [FX + 14, 72], [FX, 60]], (x) => (x > FX + 23 ? C.wine[0] : x < FX + 3 ? C.wine[2] : C.wine[1]));
  g.poly([[FX + 3, 20], [FX + 25, 20], [FX + 25, 58], [FX + 14, 67], [FX + 3, 58]], (x, y) => (dth(x, y, 0.06) ? C.wine[2] : null));
  g.line(FX, 60, FX + 14, 72, C.wine[0]);
  g.line(FX + 27, 60, FX + 14, 72, C.wine[0]);
  // 문장: 돋보기와 열쇠 구멍
  g.oval(FX + 13, 36, 8, 8, C.ink);
  g.oval(FX + 13, 36, 6.5, 6.5, C.paper);
  g.rect(FX + 12, 33, 2, 3, C.ink);
  g.rect(FX + 11, 36, 4, 3, C.ink);
  for (let i = 0; i < 5; i++) g.rect(FX + 18 + i, 41 + i, 2, 2, C.ink);
  // 술
  g.rect(FX + 13, 72, 2, 4, C.brass[1]);

  /* 양쪽 끝의 문틀 (넓은 화면에서만 보인다) */
  g.rect(226, 20, 14, 72, C.wood[1]);
  g.rect(226, 20, 1, 72, C.wood[0]);
  g.rect(226, 20, 14, 1, C.wood[0]);
  g.rect(230, 26, 10, 30, C.wood[2]);
  g.rect(0, 20, 12, 72, C.wood[1]);
  g.rect(11, 20, 1, 72, C.wood[0]);
  g.rect(0, 20, 12, 1, C.wood[0]);
  g.rect(0, 26, 8, 30, C.wood[2]);

  /* 늘어뜨린 전등 */
  for (const x of [CX - 34, CX + 33]) {
    g.rect(x, 5, 1, 7, C.ink);
    for (let j = 0; j < 4; j++) {
      const w = 4 + j * 3;
      g.rect(x - Math.floor(w / 2), 12 + j, w, 1, C.brass[1]);
      g.set(x - Math.floor(w / 2), 12 + j, C.brass[2]);
      g.set(x - Math.floor(w / 2) + w - 1, 12 + j, C.brass[0]);
    }
    g.rect(x - 7, 16, 15, 1, C.brass[0]);
    g.rect(x - 2, 17, 5, 2, C.hot);
  }

  return { name: "examroom-dot", grid: g };
}

/* ───────── 굽기 ───────── */

const SCENES = { corridor, desk, examroom };

const args = process.argv.slice(2);
const previewAt = args.indexOf("--preview");
const previewDir = previewAt >= 0 ? args[previewAt + 1] : null;
const wanted = args.filter((a, i) => !a.startsWith("--") && i !== previewAt + 1);
const names = wanted.length ? wanted : Object.keys(SCENES);

mkdirSync(OUT, { recursive: true });
if (previewDir) mkdirSync(previewDir, { recursive: true });
const browser = await chromium.launch();
const page = await browser.newPage();

for (const key of names) {
  const make = SCENES[key];
  if (!make) throw new Error(`모르는 배경: ${key}`);
  const { name, grid } = make();
  const colors = new Set(grid.px);
  const render = (scale) =>
    page.evaluate(
      ({ w, h, px, scale }) => {
        const canvas = document.createElement("canvas");
        canvas.width = w * scale;
        canvas.height = h * scale;
        const ctx = canvas.getContext("2d");
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            ctx.fillStyle = px[y * w + x];
            ctx.fillRect(x * scale, y * scale, scale, scale);
          }
        }
        return canvas.toDataURL("image/png").split(",")[1];
      },
      { w: grid.w, h: grid.h, px: grid.px, scale },
    );
  const file = resolve(OUT, `${name}.png`);
  const png = Buffer.from(await render(2), "base64");
  writeFileSync(file, png);
  if (previewDir) writeFileSync(resolve(previewDir, `${name}@4x.png`), Buffer.from(await render(4), "base64"));
  console.log(`${name}.png ${grid.w}×${grid.h}점 · ${colors.size}색 · ${(png.length / 1024).toFixed(1)}KB`);
}

await browser.close();
