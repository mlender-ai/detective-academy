// 그림에서 지정한 지점의 평균색을 뽑는다: node scripts/sample-colors.mjs <image> x,y[,r] ...
import { chromium } from "@playwright/test";
import { readFileSync } from "node:fs";
import { extname } from "node:path";

const [file, ...points] = process.argv.slice(2);
const mime = { ".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg" }[extname(file)];
const dataUrl = `data:${mime};base64,${readFileSync(file).toString("base64")}`;
const browser = await chromium.launch();
const page = await browser.newPage();
const result = await page.evaluate(
  async ({ dataUrl, points }) => {
    const img = new Image();
    img.src = dataUrl;
    await img.decode();
    const canvas = document.createElement("canvas");
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);
    const out = [`size ${canvas.width}x${canvas.height}`];
    for (const p of points) {
      let [x, y, r = 10] = p.split(",").map(Number);
      if (x < 0) x += canvas.width;
      if (y < 0) y += canvas.height;
      const d = ctx.getImageData(Math.max(0, x - r), Math.max(0, y - r), r * 2, r * 2).data;
      const sum = [0, 0, 0];
      for (let i = 0; i < d.length; i += 4) for (let k = 0; k < 3; k++) sum[k] += d[i + k];
      const n = d.length / 4;
      out.push(`${p.padEnd(14)} #${sum.map((v) => Math.round(v / n).toString(16).padStart(2, "0")).join("")}`);
    }
    return out;
  },
  { dataUrl, points },
);
console.log(result.join("\n"));
await browser.close();
