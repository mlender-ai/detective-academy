/**
 * 픽셀 배경의 원화(펜선 + 수채)를 WebP 로 굽는다. 결과는 scripts/art-src/ 에 놓이고,
 * scripts/pixelize.mjs 가 이것을 저해상도 픽셀 배경(src/assets/art/*-px.png)으로 바꾼다.
 *   node scripts/render-art.ts            # 전부
 *   node scripts/render-art.ts desk       # 하나만
 * 그림은 SVG(펜선 + 수채 필터)로 만들고, 크로미움에서 한 번 그려 파일로 남긴다.
 * 실행할 때마다 같은 그림이 나온다(난수 seed 고정).
 */
import { chromium } from "@playwright/test";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { curve, ellipse, hatch, line, rect, rng } from "./sketch.ts";

const OUT = resolve(dirname(fileURLToPath(import.meta.url)), "art-src");
const PAPER = "#e8dec6";
const INK = "#2a221e";

interface Asset {
  name: string;
  width: number;
  height: number;
  quality: number;
  svg: string;
}

/* ───────── 추리 책상: 위에서 내려다본 나무 책상 ───────── */

function desk(): Asset {
  const W = 900;
  const H = 1800;
  const r = rng(42);
  const x0 = 20;
  const y0 = 24;
  const x1 = W - 20;
  const y1 = H - 26;
  const seams = [176, 352, 534, 716];
  const planks = [x0, ...seams, x1];
  const tints = ["#8a6149", "#a0765a", "#7d5843", "#96694c", "#86604a"];

  const plankRects = planks
    .slice(0, -1)
    .map(
      (x, i) =>
        `<rect x="${x}" y="${y0}" width="${planks[i + 1] - x}" height="${y1 - y0}" fill="${tints[i]}" opacity=".26" style="mix-blend-mode:multiply"/>`,
    )
    .join("");

  // 널빤지 이음선: 길게 이어지다 군데군데 끊긴다
  let seamInk = "";
  let seamThin = "";
  seams.forEach((x, i) => {
    let y = y0 - 10;
    while (y < y1) {
      const len = 260 + r() * 420;
      const end = Math.min(y1 + 12, y + len);
      const points: [number, number][] = [];
      for (let t = y; t <= end; t += 90) points.push([x + (r() - 0.5) * 3.4, t]);
      points.push([x + (r() - 0.5) * 3.4, end]);
      seamInk += curve(points, { seed: 100 + i * 17 + Math.round(y), wobble: 1.6, passes: 1 });
      if (r() > 0.35) {
        const off = (r() > 0.5 ? 1 : -1) * (3 + r() * 3);
        const a = y + r() * 60;
        const b = Math.min(end, a + 120 + r() * 240);
        seamThin += line(x + off, a, x + off + (r() - 0.5) * 2, b, { seed: 300 + i * 13 + Math.round(y), wobble: 1.2, over: 0, passes: 1 });
      }
      y = end + 14 + r() * 46;
    }
  });

  // 나뭇결: 가늘고 긴 선
  let grain = "";
  for (let i = 0; i < 70; i++) {
    const x = x0 + 14 + r() * (x1 - x0 - 28);
    const a = y0 + r() * (y1 - y0 - 200);
    const len = 90 + r() * 420;
    const drift = (r() - 0.5) * 9;
    grain += curve(
      [
        [x, a],
        [x + drift * 0.4, a + len * 0.35],
        [x + drift, a + len * 0.7],
        [x + drift * 0.8, a + len],
      ],
      { seed: 500 + i, wobble: 1.4, passes: 1 },
    );
  }

  // 옹이
  const knots: [number, number, number][] = [
    [612, 392, 1],
    [248, 1012, 0.8],
    [806, 1378, 0.9],
  ];
  let knotInk = "";
  let knotWash = "";
  knots.forEach(([cx, cy, k], i) => {
    for (let ring = 0; ring < 4; ring++) {
      knotInk += ellipse(cx, cy, (7 + ring * 7) * k, (11 + ring * 12) * k, { seed: 700 + i * 9 + ring, wobble: 2.2, passes: 1, turns: 0.82 + r() * 0.3 });
    }
    knotWash += `<ellipse cx="${cx}" cy="${cy}" rx="${15 * k}" ry="${24 * k}" fill="#4f372d" opacity=".5" filter="url(#soft)" style="mix-blend-mode:multiply"/>`;
  });

  // 긁힌 자국과 그늘 빗금
  let scratches = "";
  for (let i = 0; i < 9; i++) {
    const x = x0 + 60 + r() * (x1 - x0 - 160);
    const y = y0 + 80 + r() * (y1 - y0 - 200);
    const len = 18 + r() * 60;
    const ang = -0.5 + r() * 1.0;
    scratches += line(x, y, x + Math.cos(ang) * len, y + Math.sin(ang) * len, { seed: 900 + i, wobble: 0.8, over: 0, passes: 1 });
  }
  const shadeHatch = hatch(560, 1480, 300, 270, { seed: 61, gap: 13, wobble: 1.6 }) + hatch(40, 1620, 220, 140, { seed: 63, gap: 15, wobble: 1.6, flip: true });

  // 덧칠한 물감 자리: 서로 겹치며 가장자리에 물감이 고인다
  const glazes: [string, string, number][] = [
    ["M40 60 C260 20 520 60 640 220 C700 330 560 470 380 450 C200 430 60 330 40 60Z", "#c79a5e", 0.34],
    ["M420 520 C640 470 900 560 880 820 C866 1010 640 1060 470 980 C320 910 300 600 420 520Z", "#7d543d", 0.4],
    ["M20 820 C200 760 380 860 370 1080 C362 1250 180 1330 40 1250Z", "#8a5f45", 0.34],
    ["M300 1240 C520 1180 800 1250 870 1480 C910 1640 760 1780 540 1770 C340 1760 220 1420 300 1240Z", "#6b4634", 0.42],
    ["M30 1420 C150 1380 300 1450 310 1620 C316 1740 180 1790 30 1770Z", "#7a513b", 0.36],
    ["M560 30 C700 10 880 60 880 260 C880 420 720 440 640 330 C590 250 520 80 560 30Z", "#8f6247", 0.3],
  ];
  const glazeShapes = glazes
    .map(([d, fill, o], i) => `<path d="${d}" fill="${fill}" opacity="${o}" filter="url(#glaze${i % 2})" style="mix-blend-mode:multiply"/>`)
    .join("");

  // 물감이 닿지 않은 종이 자리 (마스크에서 검게 뺀다)
  const bare = [
    "M-30 1600 C40 1610 78 1670 56 1730 C44 1770 90 1800 60 1860 L-30 1860Z",
    "M930 640 C884 660 870 720 886 770 C896 810 884 850 930 870Z",
    "M330 -30 C350 26 430 40 520 28 C566 22 596 32 630 -30Z",
    "M690 1840 C716 1786 790 1770 850 1780 C888 1786 916 1764 930 1840Z",
    "M-30 300 C24 310 34 360 26 410 C20 450 30 480 -30 500Z",
  ]
    .map((d) => `<path d="${d}" fill="#000" filter="url(#edge)"/>`)
    .join("");

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<defs>
  <filter id="edge" x="-10%" y="-10%" width="120%" height="120%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.0046 0.0052" numOctaves="2" seed="8" result="n"/>
    <feDisplacementMap in="SourceGraphic" in2="n" scale="62" xChannelSelector="R" yChannelSelector="G" result="d1"/>
    <feTurbulence type="fractalNoise" baseFrequency="0.045" numOctaves="2" seed="2" result="f"/>
    <feDisplacementMap in="d1" in2="f" scale="7" xChannelSelector="G" yChannelSelector="R"/>
  </filter>
  <filter id="rim" x="-10%" y="-10%" width="120%" height="120%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.0046 0.0052" numOctaves="2" seed="8" result="n"/>
    <feDisplacementMap in="SourceGraphic" in2="n" scale="62" xChannelSelector="R" yChannelSelector="G" result="d1"/>
    <feTurbulence type="fractalNoise" baseFrequency="0.045" numOctaves="2" seed="2" result="f"/>
    <feDisplacementMap in="d1" in2="f" scale="7" xChannelSelector="G" yChannelSelector="R" result="d2"/>
    <feGaussianBlur in="d2" stdDeviation="3.2"/>
  </filter>
  ${[0, 1]
    .map(
      (i) => `<filter id="glaze${i}" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="${i ? "0.007 0.005" : "0.005 0.008"}" numOctaves="3" seed="${31 + i * 12}" result="warp"/>
    <feDisplacementMap in="SourceGraphic" in2="warp" scale="84" xChannelSelector="R" yChannelSelector="G" result="shape"/>
    <feGaussianBlur in="shape" stdDeviation="9" result="soft"/>
    <feComponentTransfer in="soft" result="core"><feFuncA type="linear" slope="2.8" intercept="-1.62"/></feComponentTransfer>
    <feComposite in="shape" in2="core" operator="out" result="rim"/>
    <feTurbulence type="fractalNoise" baseFrequency="0.004 0.007" numOctaves="3" seed="${57 + i * 9}" result="blot"/>
    <feColorMatrix in="blot" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  2 0 0 0 -0.3" result="blotA"/>
    <feComposite in="shape" in2="blotA" operator="in" result="body"/>
    <feComponentTransfer in="rim" result="rimA"><feFuncA type="linear" slope=".62"/></feComponentTransfer>
    <feMerge><feMergeNode in="body"/><feMergeNode in="rimA"/></feMerge>
  </filter>`,
    )
    .join("")}
  <filter id="soft" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="6"/></filter>
  <filter id="woodgrain" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.06 0.0014" numOctaves="3" seed="3" result="n"/>
    <feColorMatrix in="n" type="matrix" values="0 0 0 0 0.42  0 0 0 0 0.27  0 0 0 0 0.18  3 0 0 0 -1.3"/>
  </filter>
  <filter id="thin" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.003 0.004" numOctaves="3" seed="19" result="n"/>
    <feColorMatrix in="n" type="matrix" values="0 0 0 0 0.91  0 0 0 0 0.87  0 0 0 0 0.78  2.4 0 0 0 -1.05"/>
  </filter>
  <filter id="speck" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="2" seed="5" result="n"/>
    <feColorMatrix in="n" type="matrix" values="0 0 0 0 0.25  0 0 0 0 0.18  0 0 0 0 0.12  0 0 0 0.2 0"/>
  </filter>
  <radialGradient id="lamp" cx="18%" cy="10%" r="70%">
    <stop offset="0" stop-color="#fff0c4" stop-opacity=".7"/>
    <stop offset=".4" stop-color="#f6dca4" stop-opacity=".3"/>
    <stop offset="1" stop-color="#f6dca4" stop-opacity="0"/>
  </radialGradient>
  <radialGradient id="shade" cx="90%" cy="96%" r="80%">
    <stop offset="0" stop-color="#3a2620" stop-opacity=".5"/>
    <stop offset=".55" stop-color="#3a2620" stop-opacity=".14"/>
    <stop offset="1" stop-color="#3a2620" stop-opacity="0"/>
  </radialGradient>
  <mask id="wood" maskUnits="userSpaceOnUse" x="-100" y="-100" width="${W + 200}" height="${H + 200}">
    <rect x="${x0}" y="${y0}" width="${x1 - x0}" height="${y1 - y0}" fill="#fff" filter="url(#edge)"/>
    ${bare}
  </mask>
</defs>
<rect width="100%" height="100%" fill="${PAPER}"/>
<g mask="url(#wood)">
  <rect width="100%" height="100%" fill="#c9a57a"/>
  ${plankRects}
  ${glazeShapes}
  <rect width="100%" height="100%" filter="url(#woodgrain)" style="mix-blend-mode:multiply" opacity=".5"/>
  <rect width="100%" height="100%" filter="url(#thin)" opacity=".5"/>
  <rect width="100%" height="100%" fill="url(#lamp)"/>
  <rect width="100%" height="100%" fill="url(#shade)" style="mix-blend-mode:multiply"/>
  ${knotWash}
  <rect x="${x0}" y="${y0}" width="${x1 - x0}" height="${y1 - y0}" fill="none" stroke="#5f4030" stroke-width="20" opacity=".5" filter="url(#rim)" style="mix-blend-mode:multiply"/>
</g>
<g fill="none" stroke="${INK}" stroke-linecap="round" mask="url(#wood)">
  <path d="${seamInk}" stroke-width="2.6" opacity=".82"/>
  <path d="${seamThin}" stroke-width="1.3" opacity=".55"/>
  <path d="${grain}" stroke-width="1.1" opacity=".36"/>
  <path d="${knotInk}" stroke-width="1.6" opacity=".66"/>
  <path d="${scratches}" stroke-width="1.2" opacity=".42"/>
  <path d="${shadeHatch}" stroke-width="1.3" opacity=".36"/>
</g>
<rect width="100%" height="100%" filter="url(#speck)" style="mix-blend-mode:multiply"/>
</svg>`;

  return { name: "desk", width: W, height: H, quality: 0.86, svg };
}

/* ───────── 시험실: 응시자 자리에서 올려다본 교실 ─────────
   칠판과 벽시계, 높은 창, 학원 깃발. 아래쪽은 화면에서 책상에 가려진다. */

function examroom(): Asset {
  const W = 1152;
  const H = 896;
  const r = rng(77);
  let seed = 1000;
  const o = (wobble = 2.2, over = 9, passes = 2) => ({ seed: seed++, wobble, over, passes });
  const L = (x1: number, y1: number, x2: number, y2: number, w = 2.2, ov = 9, p = 2) => line(x1, y1, x2, y2, o(w, ov, p));
  const R = (x: number, y: number, w: number, h: number, wob = 2, ov = 7, p = 2) => rect(x, y, w, h, o(wob, ov, p));

  let ink = "";
  let thin = "";
  let faint = "";
  let chalk = "";
  let wash = "";
  let light = "";
  const glaze = (d: string, fill: string, opacity: number, i = 0) => {
    wash += `<path d="${d}" fill="${fill}" opacity="${opacity}" filter="url(#g${i % 3})" style="mix-blend-mode:multiply"/>`;
  };
  const box = (x: number, y: number, w: number, h: number) => `M${x} ${y}H${x + w}V${y + h}H${x}Z`;

  /* 벽과 바닥 */
  glaze(box(24, 36, 1104, 430), "#a89a8a", 0.62, 0);
  glaze("M30 60 C300 30 520 80 700 60 C900 40 1060 70 1126 50 V250 C900 290 700 230 480 270 C300 300 120 260 30 280Z", "#7f7268", 0.42, 1);
  glaze("M300 250 C460 220 700 260 860 240 C980 230 1080 260 1126 250 V466 H300Z", "#cdb38a", 0.34, 2);
  glaze(box(24, 478, 1104, 172), "#7b4a45", 0.72, 1);
  glaze("M24 560 C300 540 700 600 1128 560 V652 H24Z", "#4f2f30", 0.42, 2);
  glaze(box(24, 652, 1104, 230), "#b98f5e", 0.55, 2);
  glaze("M24 760 C400 720 800 790 1128 740 V884 H24Z", "#7a5a44", 0.36, 0);
  glaze("M250 660 C380 650 560 668 640 700 C700 760 640 860 520 880 H330 C300 800 280 720 250 660Z", "#e8c074", 0.5, 1);

  ink += L(14, 66, 1138, 66, 2.6, 12);
  thin += L(18, 84, 1134, 84, 2.2, 10, 1);
  ink += L(14, 470, 1138, 470, 2.4, 12);
  thin += L(18, 486, 1134, 486, 2, 10, 1);
  ink += L(14, 650, 1138, 650, 2.6, 12);

  // 징두리 널: 세로 이음과 안쪽 테
  for (let x = 58; x < 1120; x += 98) {
    thin += L(x, 492, x + (r() - 0.5) * 3, 644, 2, 4, 1);
    if (x + 98 < 1120) faint += R(x + 14, 506, 70, 124, 1.8, 3, 1);
  }
  // 마루: 소실점으로 모이는 널
  for (let i = -7; i <= 7; i++) {
    thin += L(576 + i * 92, 654, 576 + i * 168, 884, 2.4, 4, 1);
  }
  for (let i = 0; i < 14; i++) {
    const y = 672 + r() * 200;
    const x = 60 + r() * 1000;
    faint += L(x, y, x + 40 + r() * 90, y + (r() - 0.5) * 3, 1.6, 0, 1);
  }

  /* 칠판 */
  glaze(box(338, 172, 476, 290), "#6b4634", 0.75, 1);
  wash += `<rect x="364" y="196" width="424" height="236" fill="#2f3f39" opacity=".9" filter="url(#g2)"/>`;
  wash += `<path d="M380 210 C500 200 640 240 770 214 V330 C640 360 520 320 380 350Z" fill="#40544c" opacity=".55" filter="url(#g0)"/>`;
  ink += R(338, 172, 476, 290, 2.4, 9);
  ink += R(364, 196, 424, 236, 2, 5);
  ink += R(330, 462, 492, 14, 1.8, 6);
  // 분필 글씨 자리: 줄과 도형만 (글자는 넣지 않는다)
  chalk += L(404, 238, 610, 238, 2.4, 2, 1) + L(404, 270, 560, 270, 2.4, 2, 1) + L(404, 302, 640, 302, 2.4, 2, 1);
  chalk += R(660, 226, 92, 62, 2.2, 3, 1) + L(676, 257, 736, 257, 2, 0, 1);
  chalk += ellipse(452, 372, 26, 22, o(2.4, 0, 1)) + ellipse(560, 372, 26, 22, o(2.4, 0, 1)) + ellipse(668, 372, 26, 22, o(2.4, 0, 1));
  chalk += L(480, 372, 532, 372, 2, 0, 1) + L(588, 372, 640, 372, 2, 0, 1);
  // 분필과 지우개
  wash += `<rect x="408" y="454" width="34" height="8" fill="#f1e8d6" opacity=".9"/><rect x="452" y="455" width="22" height="7" fill="#e5c0a8" opacity=".9"/>`;
  wash += `<rect x="704" y="448" width="62" height="15" fill="#5a3b33" opacity=".85" filter="url(#g2)" style="mix-blend-mode:multiply"/>`;
  ink += R(704, 448, 62, 15, 1.4, 3, 1);

  /* 벽시계 */
  wash += `<circle cx="576" cy="120" r="41" fill="#f3e9d2" opacity=".95"/>`;
  glaze("M535 120a41 41 0 1 0 82 0a41 41 0 1 0-82 0Z", "#b9954f", 0.34, 2);
  ink += ellipse(576, 120, 43, 43, { ...o(2.4, 0, 2), turns: 1.08 } as never);
  thin += ellipse(576, 120, 35, 35, { ...o(1.8, 0, 1), turns: 1.04 } as never);
  for (let k = 0; k < 12; k++) {
    const a = (k / 12) * Math.PI * 2;
    const r1 = k % 3 === 0 ? 26 : 30;
    thin += L(576 + Math.cos(a) * r1, 120 + Math.sin(a) * r1, 576 + Math.cos(a) * 33, 120 + Math.sin(a) * 33, 0.8, 0, 1);
  }
  ink += L(576, 120, 576, 94, 1, 0, 2) + L(576, 120, 596, 132, 1, 0, 2);

  /* 높은 창 */
  wash += `<rect x="84" y="132" width="184" height="300" fill="#f2ead6" opacity=".9"/>`;
  glaze(box(84, 132, 184, 300), "#9db7bd", 0.62, 0);
  glaze("M84 132 H268 V250 C200 290 140 240 84 280Z", "#c7d6d4", 0.5, 1);
  glaze(box(64, 112, 224, 340), "#7d543d", 0.34, 2);
  ink += R(66, 114, 220, 336, 2.4, 9);
  ink += R(84, 132, 184, 300, 2, 5);
  ink += L(176, 132, 176, 432, 1.8, 3) + L(84, 232, 268, 232, 1.8, 3) + L(84, 332, 268, 332, 1.8, 3);
  ink += R(52, 450, 248, 16, 1.8, 7);
  // 창밖 나뭇가지
  thin += curve(
    [
      [96, 330],
      [128, 290],
      [150, 240],
      [166, 190],
    ],
    o(3, 0, 1),
  );
  thin += curve(
    [
      [138, 270],
      [176, 250],
      [214, 262],
      [250, 236],
    ],
    o(3, 0, 1),
  );
  thin += curve(
    [
      [150, 236],
      [132, 204],
      [124, 172],
    ],
    o(3, 0, 1),
  );
  // 창으로 드는 빛
  light += `<path d="M90 140 L266 140 L620 700 L250 700Z" fill="#fff1c2" opacity=".62" filter="url(#blur)"/>`;

  /* 학원 깃발 */
  ink += L(872, 126, 1064, 126, 1.8, 8);
  thin += L(886, 126, 904, 142, 1.2, 0, 1) + L(1050, 126, 1032, 142, 1.2, 0, 1);
  const banner = "M900 140 H1036 V352 L968 404 L900 352Z";
  wash += `<path d="${banner}" fill="#f2ead6" opacity=".9"/>`;
  glaze(banner, "#8e3a42", 0.92, 1);
  glaze("M900 140 H1036 V230 C990 250 940 220 900 244Z", "#5c1e27", 0.4, 0);
  ink += L(900, 140, 1036, 140, 1.8, 5) + L(900, 140, 900, 352, 1.8, 5) + L(1036, 140, 1036, 352, 1.8, 5) + L(900, 352, 968, 404, 1.8, 5) + L(1036, 352, 968, 404, 1.8, 5);
  thin += L(914, 154, 1022, 154, 1.4, 2, 1) + L(914, 154, 914, 346, 1.4, 2, 1) + L(1022, 154, 1022, 346, 1.4, 2, 1) + L(914, 346, 968, 386, 1.4, 2, 1) + L(1022, 346, 968, 386, 1.4, 2, 1);
  wash += `<circle cx="962" cy="238" r="33" fill="#f3e9d2" opacity=".96"/>`;
  ink += ellipse(962, 238, 34, 34, { ...o(2, 0, 2), turns: 1.06 } as never);
  wash += `<path d="M986 264 L1010 290" stroke="${INK}" stroke-width="11" stroke-linecap="round" fill="none"/>`;
  wash += `<circle cx="962" cy="230" r="9" fill="${INK}"/><path d="M957 236 H967 L971 256 H953Z" fill="${INK}"/>`;

  /* 오른쪽 문 */
  glaze(box(1076, 150, 60, 500), "#6b4634", 0.55, 2);
  ink += L(1076, 148, 1076, 650, 2.2, 6) + L(1076, 148, 1140, 148, 2, 6);
  thin += R(1092, 176, 60, 190, 1.8, 3, 1) + R(1092, 392, 60, 220, 1.8, 3, 1);

  /* 늘어뜨린 전등 */
  for (const x of [318, 836]) {
    thin += L(x, -6, x, 90, 0.8, 0, 2);
    const shade = `M${x - 38} 124 L${x - 13} 90 H${x + 13} L${x + 38} 124Z`;
    wash += `<path d="${shade}" fill="#f2ead6" opacity=".9"/>`;
    glaze(shade, "#b98a2e", 0.95, 1);
    ink += L(x - 38, 124, x - 13, 90, 1.2, 3) + L(x + 38, 124, x + 13, 90, 1.2, 3) + L(x - 13, 90, x + 13, 90, 1, 2) + L(x - 40, 124, x + 40, 124, 1.2, 4);
    light += `<ellipse cx="${x}" cy="150" rx="120" ry="78" fill="#ffe7a6" opacity=".6" filter="url(#blur)"/>`;
    light += `<ellipse cx="${x}" cy="128" rx="20" ry="9" fill="#fff6d6" opacity=".9"/>`;
  }

  /* 그늘 빗금 */
  faint += hatch(24, 90, 150, 60, { seed: seed++, gap: 13, wobble: 2 });
  faint += hatch(1000, 400, 70, 66, { seed: seed++, gap: 12, wobble: 2 });
  faint += hatch(338, 478, 476, 34, { seed: seed++, gap: 12, wobble: 2, flip: true });
  faint += hatch(280, 300, 54, 160, { seed: seed++, gap: 13, wobble: 2 });
  faint += hatch(820, 190, 66, 120, { seed: seed++, gap: 14, wobble: 2, flip: true });
  faint += hatch(40, 780, 300, 100, { seed: seed++, gap: 16, wobble: 2.4 });
  faint += hatch(860, 800, 260, 80, { seed: seed++, gap: 16, wobble: 2.4, flip: true });

  // 물감이 닿지 않은 종이 자리
  const bare = [
    "M-30 -30 H210 C150 20 70 30 40 80 C20 120 30 150 -30 170Z",
    "M1182 -30 V200 C1150 150 1140 100 1090 70 C1040 44 1010 40 980 -30Z",
    "M-30 926 V700 C20 740 30 800 80 830 C140 866 200 860 240 926Z",
    "M1182 926 H930 C980 880 1050 880 1090 840 C1130 800 1130 760 1182 730Z",
    "M470 -30 C500 20 560 34 640 26 C690 20 720 0 730 -30Z",
  ]
    .map((d) => `<path d="${d}" fill="#000" filter="url(#edge)"/>`)
    .join("");

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<defs>
  <filter id="edge" x="-10%" y="-10%" width="120%" height="120%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.006 0.007" numOctaves="2" seed="5" result="n"/>
    <feDisplacementMap in="SourceGraphic" in2="n" scale="54" xChannelSelector="R" yChannelSelector="G" result="d1"/>
    <feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="2" seed="2" result="f"/>
    <feDisplacementMap in="d1" in2="f" scale="7" xChannelSelector="G" yChannelSelector="R"/>
  </filter>
  ${[0, 1, 2]
    .map(
      (i) => `<filter id="g${i}" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="${["0.012 0.018", "0.02 0.012", "0.016 0.016"][i]}" numOctaves="3" seed="${21 + i * 14}" result="warp"/>
    <feDisplacementMap in="SourceGraphic" in2="warp" scale="${[26, 20, 16][i]}" xChannelSelector="R" yChannelSelector="G" result="shape"/>
    <feGaussianBlur in="shape" stdDeviation="4" result="soft"/>
    <feComponentTransfer in="soft" result="core"><feFuncA type="linear" slope="2.8" intercept="-1.62"/></feComponentTransfer>
    <feComposite in="shape" in2="core" operator="out" result="rim"/>
    <feTurbulence type="fractalNoise" baseFrequency="${["0.007 0.011", "0.012 0.008", "0.01 0.01"][i]}" numOctaves="3" seed="${47 + i * 9}" result="blot"/>
    <feColorMatrix in="blot" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  1.9 0 0 0 -0.16" result="blotA"/>
    <feComposite in="shape" in2="blotA" operator="in" result="body"/>
    <feComponentTransfer in="rim" result="rimA"><feFuncA type="linear" slope=".6"/></feComponentTransfer>
    <feMerge><feMergeNode in="body"/><feMergeNode in="rimA"/></feMerge>
  </filter>`,
    )
    .join("")}
  <filter id="blur" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="16"/></filter>
  <filter id="speck" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="2" seed="5" result="n"/>
    <feColorMatrix in="n" type="matrix" values="0 0 0 0 0.25  0 0 0 0 0.18  0 0 0 0 0.12  0 0 0 0.2 0"/>
  </filter>
  <filter id="thin" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.004 0.005" numOctaves="3" seed="19" result="n"/>
    <feColorMatrix in="n" type="matrix" values="0 0 0 0 0.91  0 0 0 0 0.87  0 0 0 0 0.78  2.4 0 0 0 -1.1"/>
  </filter>
  <filter id="dryline" x="-5%" y="-5%" width="110%" height="110%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.5" numOctaves="2" seed="3" result="n"/>
    <feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  2.6 0 0 0 -0.5" result="mask"/>
    <feComposite in="SourceGraphic" in2="mask" operator="in"/>
  </filter>
  <mask id="scene" maskUnits="userSpaceOnUse" x="-100" y="-100" width="${W + 200}" height="${H + 200}">
    <rect x="14" y="18" width="${W - 28}" height="${H - 36}" fill="#fff" filter="url(#edge)"/>
    ${bare}
  </mask>
</defs>
<rect width="100%" height="100%" fill="${PAPER}"/>
<g mask="url(#scene)">
  ${wash}
  <rect width="100%" height="100%" filter="url(#thin)" opacity=".45"/>
  ${light}
</g>
<g fill="none" stroke="#33261f" stroke-linecap="round" stroke-linejoin="round">
  <path d="${ink}" stroke-width="2.3" opacity=".88"/>
  <path d="${thin}" stroke-width="1.4" opacity=".64"/>
  <path d="${faint}" stroke-width="1.2" opacity=".4"/>
  <path d="${chalk}" stroke="#f3ead7" stroke-width="3.4" opacity=".8" filter="url(#dryline)"/>
</g>
<rect width="100%" height="100%" filter="url(#speck)" style="mix-blend-mode:multiply"/>
</svg>`;

  return { name: "examroom", width: W, height: H, quality: 0.86, svg };
}

/* ───────── 굽기 ───────── */

const ASSETS: Record<string, () => Asset> = { desk, examroom };

const wanted = process.argv.slice(2);
const names = wanted.length ? wanted : Object.keys(ASSETS);

mkdirSync(OUT, { recursive: true });
const browser = await chromium.launch();
const page = await browser.newPage();

for (const name of names) {
  const make = ASSETS[name];
  if (!make) throw new Error(`모르는 그림: ${name}`);
  const asset = make();
  const base64 = await page.evaluate(
    async ({ svg, width, height, quality }) => {
      const img = new Image();
      img.src = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" }));
      await img.decode();
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      canvas.getContext("2d")!.drawImage(img, 0, 0, width, height);
      return canvas.toDataURL("image/webp", quality).split(",")[1];
    },
    { svg: asset.svg, width: asset.width, height: asset.height, quality: asset.quality },
  );
  const file = resolve(OUT, `${asset.name}.webp`);
  writeFileSync(file, Buffer.from(base64, "base64"));
  console.log(`${asset.name}.webp ${asset.width}x${asset.height} ${(Buffer.from(base64, "base64").length / 1024).toFixed(0)}KB`);
}

await browser.close();
