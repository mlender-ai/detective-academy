// D안 · 1비트 흑백 도트 시안의 진입점.
// 배치(@layer layout)와 픽셀안의 격자 규칙(pixel*.css: 2px 점, 끊어지는 움직임)을 한 층(skin)으로 깔고,
// 그 위에 mono*.css 로 색을 두 가지(검정·흰색)로 줄이고 화면 구성을 텍스트 어드벤처처럼 바꾼다.
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import "./styles/tokens.css";
import "./styles/base.css";
import "./styles/components.css";
import "./styles/art.css";
import "./styles/hall.css";
import "./styles/desk.css";
import "./styles/rooms.css";
import "./styles/mono-pixel.css";
import "./styles/mono.css";
import "./styles/mono-rooms.css";

import { App } from "./app/App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
