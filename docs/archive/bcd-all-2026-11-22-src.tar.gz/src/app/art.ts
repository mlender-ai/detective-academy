/**
 * 화풍. 확정안은 픽셀 아트(index.html)이고, 나머지는 비교용 시안이다(2026-11-21).
 * - noir: C안 누아르 카툰 (noir.html)
 * - mono: D안 1비트 흑백 도트 (mono.html)
 * 진입 HTML 이 <html data-art="…"> 를 달고 오면 그 화풍으로 그린다. 픽셀 쪽은 아무것도 달지 않는다.
 */
export type Art = "pixel" | "noir" | "mono";

const tag = typeof document !== "undefined" ? document.documentElement.dataset.art : undefined;

export const ART: Art = tag === "noir" ? "noir" : tag === "mono" ? "mono" : "pixel";

export const NOIR = ART === "noir";
export const MONO = ART === "mono";
